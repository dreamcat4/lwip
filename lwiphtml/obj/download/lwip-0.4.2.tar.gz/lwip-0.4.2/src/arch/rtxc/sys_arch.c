/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: sys_arch.c,v 1.10 2001/10/08 08:52:19 adam Exp $
 */

#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/sys.h"
#include "lwip/mem.h"

#include "arch/dlist.h"

#include "rtxcapi.h"
#include "csema.h"
#include "cclock.h"
#include "cqueue.h"
#include "cres.h"
#include "cpart.h"
#include "ctask.h"

static struct sys_thread *threads = NULL;

struct timeoutlist {
  struct timeoutlist *next;
  struct dlist *timeouts;
  TASK pid;
};

static struct timeoutlist *timeoutlist = NULL;

struct timeout_s {
  sys_timeout_handler h;
  void *data;
};

struct irq_s {
  struct irq_s *next;
  sys_irq_handler h;
  int fd;
  void *data;
};

/*-----------------------------------------------------------------------------------*/
sys_mbox_t
sys_mbox_new(void)
{
  QUEUE mbox;  
  KS_dequeuew(IP_MBOXQ, &mbox);
  KS_purgequeue(mbox);
  return mbox;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(sys_mbox_t mbox)
{
  KS_enqueue(IP_MBOXQ, &mbox);
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(sys_mbox_t mbox, void *data)
{
  if(KS_enqueue(mbox, &data) != RC_GOOD) {
  }
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_fetch(sys_mbox_t mbox, void **data)
{
  unsigned int ticks;
  struct dlist *timeouts;
  struct timeout_s *timeout_s;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;
  
  timeouts = NULL;      
     
  if(timeoutlist != NULL) {
    DEBUGF(SYS_DEBUG, ("PID: %d sys_mbox_fetch: timeoutlist not empty\n",KS_inqtask()));
    pid = KS_inqtask();
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	DEBUGF(SYS_DEBUG, ("PID: %d sys_mbox_fetch: corresponding pid found!\n",KS_inqtask()));
	break;
      }
    }
  }
  else{
    DEBUGF(SYS_DEBUG, ("PID: %d sys_mbox_fetch: timeoutlist empty..\n",KS_inqtask()));
  }
  
again:
  if(timeouts == NULL || dlist_is_empty(timeouts)) {
    DEBUGF(SYS_DEBUG, ("PID: %d sys_mbox_fetch: without timeouts\n",KS_inqtask()));
    KS_dequeuew(mbox, data);
    
  } else { 
  
    ticks = dlist_first(timeouts, (void **)&timeout_s);
    ret = KS_dequeuet(mbox, data, (TICKS)ticks/CLKTICK);
    if(ret == RC_TIMEOUT) {
      do {
	timeout_s = dlist_remove_first(timeouts);
	timeout_s->h(timeout_s->data);  /* Call timeout handler with its argument. */
	KS_free(MAP8, timeout_s);
	if(!dlist_is_empty(timeouts)) {
	  ticks = dlist_first(timeouts, (void **)&timeout_s);
	}
      } while(!dlist_is_empty(timeouts) && ticks == 0);
      goto again; /* XXX: Ugly! */
    }
  }
}
/*-----------------------------------------------------------------------------------*/
sys_sem_t
sys_sem_new(int count)
{
  SEMA sem;
  KS_dequeuew(IP_SEMQ, &sem);
  KS_pend(sem);
  if(count > 0) {
    KS_signal(sem);
  }
  return sem;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_wait(sys_sem_t sem)
{
  unsigned int ticks;
  struct dlist *timeouts;
  struct timeout_s *timeout_s;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;
  
  timeouts = NULL;    
  if(timeoutlist != NULL) {
    pid = KS_inqtask();
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
    
again:  
  if(timeouts == NULL || dlist_is_empty(timeouts)) {
    KS_wait(sem);
  } else {
    ticks = dlist_first(timeouts, (void **)&timeout_s);
    ret = KS_waitt(sem, (TICKS)ticks/CLKTICK);
    
    if(ret == RC_TIMEOUT) {
      do {
	timeout_s = dlist_remove_first(timeouts);
	timeout_s->h(timeout_s->data);
	KS_free(MAP8, timeout_s);
	if(!dlist_is_empty(timeouts)) {
	  ticks = dlist_first(timeouts, (void **)&timeout_s);
	}
      } while(!dlist_is_empty(timeouts) && ticks == 0);
      goto again; /* XXX: Ugly! */
    }
  }
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(sys_sem_t sem)
{
  KS_signal(sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(sys_sem_t sem)
{
  KS_enqueue(IP_SEMQ, &sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_timeout(u16_t msecs, sys_timeout_handler h, void *data)
{
  struct dlist *timeouts;
  struct timeout_s *t;
  struct timeoutlist *tl;
  TASK pid;
  
  pid = KS_inqtask();
  
  timeouts = NULL;
  if(timeoutlist != NULL) {
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
      
  if(timeouts == NULL) {
    timeouts = dlist_new();
    tl = (struct timeoutlist *)KS_allocw(MAP10);
    tl->pid = pid;
    tl->timeouts = timeouts;
    
    tl->next = timeoutlist;    
    timeoutlist = tl;
  }
  
  t = (struct timeout_s *)KS_allocw(MAP8);

  t->h = h;
  t->data = data;
  dlist_insert(timeouts, t, msecs);
   
}
/*-----------------------------------------------------------------------------------*/
void
sys_init(void)
{
  /* posta in alla semaforer i IP_SEMQ, posta in alla mboxar i
     IP_MBOXQ */
  QUEUE mbox;
  SEMA  sem;
  
  mbox = IP_Q_01; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_02; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_03; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_04; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_05; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_06; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_07; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_08; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_09; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_10; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_11; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_12; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_13; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_14; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_15; KS_enqueue(IP_MBOXQ, &mbox);
  sem  = IP_S_01; KS_enqueue(IP_SEMQ,  &sem);
  sem  = IP_S_02; KS_enqueue(IP_SEMQ,  &sem);
  sem  = IP_S_03; KS_enqueue(IP_SEMQ,  &sem);
}

/*-----------------------------------------------------------------------------------*/
struct sys_thread_arg {
  void (* thread)(void *);
  void *threadarg;
  SEMA sem;
};
/*-----------------------------------------------------------------------------------*/
static void
sys_thread(void)
{
  struct sys_thread_arg *arg;
  void (* thread)(void *);
  void *threadarg;
  
  arg = KS_inqtask_arg(0);
  if(arg != NULL) {
    thread = arg->thread;
    threadarg = arg->threadarg;
    KS_signal(arg->sem);
    thread(threadarg);
  }
  KS_terminate(0);
}
/*-----------------------------------------------------------------------------------*/
sys_thread_t 
sys_thread_new(void *(* function)(void *arg), void *arg) 
{
  TASK newtask;
  PRIORITY pri = 2;       /* This may have to be changed. */
  char *stack;
  int stacksize = 512;   /* This may have to be changed. */
  struct sys_thread_arg threadarg;
  
  
  newtask = KS_alloc_task();
  stack = KS_allocw(MAP512);
  
  KS_deftask(newtask, pri, (char ks_stk *)stack, (size_t)stacksize, (void (*)(void))sys_thread);
  
  threadarg.thread = function;
  threadarg.threadarg = arg;
  threadarg.sem = THRDSYNC;
  KS_deftask_arg(newtask, &threadarg);    
  KS_execute(newtask);
  KS_wait(THRDSYNC);
   
  return newtask;
}






