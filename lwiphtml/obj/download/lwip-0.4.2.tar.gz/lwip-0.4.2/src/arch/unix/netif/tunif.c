/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tunif.c,v 1.17 2001/11/07 10:03:58 adam Exp $
 */

#include "lwip/debug.h"

#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#ifndef linux
#include <net/if_tun.h>
#endif /* linux */

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
/*#include "lwip/ip.h"*/
#include "lwip/pbuf.h"
#include "netif/tunif.h"
#include "lwip/sys.h"
#include "lwip/err.h"

/*efine TUNIF_DROP*/

struct tunif {
  int fd;
};
static char buf[4096];

/*-----------------------------------------------------------------------------------*/
static void
tunif_irq_handler(int fd, void *data)
{
  struct netif *netif;
  struct tunif *tun;
  char *bufp;
  int len;
  struct pbuf *p, *q;

  netif = data;
  tun = netif->state;

  len = sizeof(buf);
  len = read(tun->fd, buf, len);  
#ifdef TUNIF_DROP  
  if(((double)rand()/(double)RAND_MAX) < 0.10) {
    DEBUGF(TUNIF_DEBUG, ("+++tunif_irq_handler: Packet dropped\n"));
    return;
  }
#endif /* TUNIF_DROP */
    
  p = pbuf_alloc(PBUF_LINK, len, PBUF_POOL);
  bufp = &buf[0];
  for(q = p; q != NULL; q = q->next) {
    bcopy(bufp, q->payload, q->len);
    bufp += q->len;
  }
  if(p != NULL) {
#ifdef IPv6        
    pbuf_header(p, -4);
#endif /* IPv6 */
    netif->input(p, netif);
  }
  

}
/*-----------------------------------------------------------------------------------*/
static err_t
tunif_output(struct netif *netif, struct pbuf *p, struct ip_addr *ipaddr)
{
  struct tunif *tunif;
  char *data;
  struct pbuf *q;
  int i, j, ret;

  
#ifdef TUNIF_DROP
  if(((double)rand()/(double)RAND_MAX) < 0.1) {
    DEBUGF(TUNIF_DEBUG, ("+++tunif_output: Packet dropped\n"));
    return 1;
  }
#endif /* TUNIF_DROP */

  tunif = netif->state;
  data = malloc(p->tot_len);

  i = 0;
  for(q = p; q != NULL; q = q->next) {
    for(j = 0; j < q->len; j++) {
      data[i] = ((char *)q->payload)[j];
      i++;
    }
  }

  DEBUGF(TUNIF_DEBUG, ("tunif: Sending len %d\n", p->tot_len));

#ifdef IPv4
  ret = write(tunif->fd, data, p->tot_len);
#else
  {
    struct iovec iov[2];
    int af;

    printf("hahaha\n");
    af = AF_INET6;
    iov[0].iov_base = (char *)&af;
    iov[0].iov_len  = sizeof(af);
    iov[1].iov_base = data;
    iov[1].iov_len  = p->tot_len;
    
    ret = writev(tunif->fd, iov, 2);
  }
#endif /* IPv4 */
  
  if(ret == -1) {
    perror("tunif_output: write");
  }
  free(data);
  return 1;

}
/*-----------------------------------------------------------------------------------*/
static void *
tunif_thread(void *arg)
{
  struct netif *netif;
  struct tunif *tunif;

  DEBUGF(TUNIF_DEBUG, ("tunif_thread: started.\n"));

  netif = arg;
  tunif = netif->state;
  
  sys_irq(tunif->fd, tunif_irq_handler, netif);
  sys_main();
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
void
tunif_init_thread(struct netif *netif)
{
  struct tunif *tun;
  int val;
  
  tun = malloc(sizeof(struct tunif));
  netif->state = tun;
  netif->name[0] = 't';
  netif->name[1] = 'n';
  netif->output = tunif_output;

  tun = netif->state;
  tun->fd = open("/dev/tun0", O_RDWR);
  if(tun->fd == -1) {
    perror("tunif_init");
    exit(1);
  }
#ifdef linux
  /*  system("ifconfig tun0 10.0.0.1 pointopoint 10.0.0.2");
      system("route add -net 10.0.0.0 netmask 255.0.0.0 tun0");*/
  snprintf(buf, sizeof(buf), "ifconfig tun0 inet %d.%d.%d.%d %d.%d.%d.%d",
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)),
	   ip4_addr1(&(netif->gw)),
	   ip4_addr2(&(netif->gw)),
	   ip4_addr3(&(netif->gw)),
	   ip4_addr4(&(netif->gw)));
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);

  snprintf(buf, sizeof(buf), "route add -net %d.%d.0.0 netmask 255.255.0.0 dev tun0",
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)));  
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);
#else
#ifdef IPv4  
  snprintf(buf, sizeof(buf), "ifconfig tun0 inet %d.%d.%d.%d %d.%d.%d.%d",
	   ip4_addr1(&(netif->gw)),
	   ip4_addr2(&(netif->gw)),
	   ip4_addr3(&(netif->gw)),
	   ip4_addr4(&(netif->gw)),
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)));
  val = 0;
  ioctl(tun->fd, TUNSIFHEAD, &val);
#else
  snprintf(buf, sizeof(buf), "ifconfig tun0 inet6 fec0:0:0:1:2c0:6cff:fe00:f043");
  val = 1;
  ioctl(tun->fd, TUNSIFHEAD, &val);
#endif /* IPv4 */  
  DEBUGF(TUNIF_DEBUG, ("tunif_init: system(\"%s\");\n", buf));
  system(buf);
#endif /* linux */

   
  sys_thread_new(tunif_thread, netif);
}
/*-----------------------------------------------------------------------------------*/

