/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: sys_c64.c,v 1.7 2001/10/15 15:29:11 adam Exp $
 */

#include <c64.h>

#include "lwip/sys.h"
#include "arch/dlist.h"
#include "lwip/def.h"

static struct dlist *timeouts;

struct timeout_s {
  struct timeout_s *next;
  sys_timeout_handler h;
  void *data;
};

#define TIMEOUT_SS 10
static struct timeout_s timeout_ss[TIMEOUT_SS];
static struct timeous_s *timeout_s_freelist = NULL;


static void setup_timer_irq(void);
static u16_t timer;

#define printf(x)

/*-----------------------------------------------------------------------------------*/
sys_mbox_t
sys_mbox_new(void)
{
  return SYS_MBOX_NULL;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(sys_mbox_t mbox)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(sys_mbox_t mbox, void *data)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_fetch(sys_mbox_t mbox, void **data)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
sys_sem_t
sys_sem_new(int count)
{
  return 0;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_wait(sys_sem_t sem)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(sys_sem_t sem)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(sys_sem_t sem)
{
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_timeout(u16_t msecs, sys_timeout_handler h, void *data)
{
  struct timeout_s *t;
  


  t = timeout_s_freelist;
  if(t == NULL) {
    return;
  }

  timeout_s_freelist = t->next;
  
  t->h = h;
  t->data = data;
  dlist_insert(timeouts, t, msecs);
  return;
}
/*-----------------------------------------------------------------------------------*/
void
sys_init(void)
{
  s16_t i;

  
  timeout_s_freelist = &timeout_ss[0];
  for(i = 0; i < TIMEOUT_SS; ++i) {
    timeout_ss[i].next = &(timeout_ss[i + 1]);
  }
  timeout_ss[i - 1].next = NULL;
  
  dlist_init();
  
  timeouts = dlist_new();
  
  
  /* Set up timer IRQ to fire every 10 msec. */
  timer = 0;
  setup_timer_irq();
  return;
}
/*-----------------------------------------------------------------------------------*/
sys_thread_t
sys_thread_new(void *(* function)(void *arg), void *arg)
{
  return 0;
}
/*-----------------------------------------------------------------------------------*/
void
sys_main(void)
{
  struct timeout_s *timeout_s;
  u16_t time;

  if(!dlist_is_empty(timeouts)) {
    asm("sei");
    timer = dlist_first(timeouts, (void **)&timeout_s) / 10;
    asm("cli");
  }
    
  while(1) {
    /* Loop and check if a timer should be called. The timer IRQ is
       decreasing the "timer" variable every 10 ms. */
    while(timer != 0) {};
    if(!dlist_is_empty(timeouts)) {
      time = 0;
      do {
        timeout_s = dlist_remove_first(timeouts);
	timeout_s->h(timeout_s->data);
	
	timeout_s->next = timeout_s_freelist;
	timeout_s_freelist = timeout_s;
	
	if(!dlist_is_empty(timeouts)) {
	  time = dlist_first(timeouts, (void **)&timeout_s) / 10;
	}
      } while(time == 0 && !dlist_is_empty(timeouts));
      asm("sei");
      timer = time;
      asm("cli");    
    }
  }
}
/*-----------------------------------------------------------------------------------*/
static void
irq_handler(void)
{
  if(timer != 0) {
    --timer;
  }
  /*  asm("inc $07e7");*/
  asm("jmp $ea7e");  /* Exit the IRQ handler. */
}
/*-----------------------------------------------------------------------------------*/
static void
setup_timer_irq(void)
{
  asm("sei");   /* Disable interrupts. */
  CIA1.cra &= 0xfe;  /* Stop timer A. */

  /* This should be approximately 100 Hz == one irq every 10 ms. */
  CIA1.ta_lo = 0x00;
  CIA1.ta_hi = 0x25;

  VIC.imr = 0x00;   /* Disable VIC irqs. */

  /* Load irq handler. */
  *(u16_t *)0x314 = (u16_t)irq_handler;

  CIA1.cra |= 1;  /* Start timer A. */

  /*  asm("cli");*/   /* Enable interrupts. */
}
