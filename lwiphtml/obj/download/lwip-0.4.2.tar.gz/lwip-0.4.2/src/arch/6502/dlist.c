/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: dlist.c,v 1.4 2001/10/15 15:29:11 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* dlist.c
 *
 * Implements a delta list.
 *
 */
/*-----------------------------------------------------------------------------------*/


#include "arch/dlist.h"
#include "lwip/def.h"
#include "lwip/mem.h"

struct dlist_item {
  struct dlist_item *next;
  u16_t dvalue;  /* delta value */
  void *item;
};

#define ITEMS 30
static struct dlist_item items[ITEMS];
static struct dlist_item *item_freelist = NULL;

struct dlist {
  struct dlist *next;
  struct dlist_item *first;
};

#define LISTS 2
static struct dlist lists[LISTS];
static struct dlist *list_freelist = NULL;

/*-----------------------------------------------------------------------------------*/
void
dlist_init(void)
{
  s16_t i;

  list_freelist = &lists[0];
  for(i = 0; i < LISTS; ++i) {
    lists[i].next = &(lists[i + 1]);
  }
  lists[i - 1].next = NULL;

  item_freelist = &items[0];
  for(i = 0; i < ITEMS; ++i) {
    items[i].next = &(items[i + 1]);
  }
  items[i - 1].next = NULL;
}
/*-----------------------------------------------------------------------------------*/
struct dlist *
dlist_new(void)
{
  struct dlist *dl;

  dl = list_freelist;
  if(dl == NULL) {
    return NULL;
  }
  list_freelist = dl->next;
  dl->first = NULL;
  return dl;
}
/*-----------------------------------------------------------------------------------*/
u8_t
dlist_is_empty(struct dlist *dl)
{
  return dl->first == NULL;
}
/*-----------------------------------------------------------------------------------*/
u16_t
dlist_first(struct dlist *dl, void **item)
{
  struct dlist_item *di;
  di = dl->first;
  *item = di->item;
  return di->dvalue;
}
/*-----------------------------------------------------------------------------------*/
void
dlist_insert(struct dlist *dl, void *item, u16_t value)
{
  struct dlist_item *di, *ni;
  u16_t acc;

  ni = item_freelist;
  if(ni == NULL) {
    return;
  }
  item_freelist = ni->next;
  
  ni->next = NULL;
  ni->item = item;
  
  if(dl->first == NULL) {
    ni->dvalue = value;
    dl->first = ni;
    return;
  }

  if(value <= dl->first->dvalue) {
    ni->next = dl->first;
    dl->first->dvalue -= value;
    dl->first = ni;
    ni->dvalue = value;
    return;
  }
  
  acc = 0;
  for(di = dl->first; di != NULL; di = di->next) {
    acc += di->dvalue;
    if(value >= acc && di->next == NULL) {
      di->next = ni;
      ni->dvalue = value - acc;
      return;
    } else if(value >= acc && value <= acc + di->next->dvalue) {
      ni->dvalue = value - acc;
      di->next->dvalue -= value - acc;
      ni->next = di->next;
      di->next = ni;
      return;
    }
  }
  
  return;
}
/*-----------------------------------------------------------------------------------*/
void
dlist_update_first(struct dlist *dl, u16_t newvalue)
{
  dl->first->dvalue = newvalue;
}
/*-----------------------------------------------------------------------------------*/
void *
dlist_remove_first(struct dlist *dl)
{
  struct dlist_item *di;
  if(dl->first == NULL) {
    return NULL;
  }
  di = dl->first;
  dl->first = di->next;
  
  di->next = item_freelist;
  item_freelist = di;
  return di->item;
}
/*-----------------------------------------------------------------------------------*/

