/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: httpd.c,v 1.12 2001/10/08 05:26:32 adam Exp $
 */

#include "lwip/debug.h"

#include "lwip/stats.h"

#include "httpd.h"

#include "lwip/tcp.h"

#include "fs.h"
#include "dynpages.c"
static const char httphtmlheader[] = "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n";
static char statsbuf[631];

#define printf(x)

/*-----------------------------------------------------------------------------------*/
static u8_t
httpd_strncmp(char *str1, char *str2, u8_t n)
{
  u8_t i;
  i = 0;
 loop:

  if(i == n) {
    return 0;
  }
  if(str1[i] != str2[i]) {
    return 1;
  }

  if(str1[i] == 0) {
    return 0;
  }
  i++;
  goto loop;
}
/*-----------------------------------------------------------------------------------*/
void
hexprint(u16_t *databytes, u16_t num, char *buf)
{
  static u8_t space;
  static u16_t i, j;
  static u16_t a;
  static const char hextab[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
			        'a', 'b', 'c', 'd', 'e', 'f'};

  for(i = 0, j = 0; i < num; i++, j += 5) {
    a = databytes[i];
    if(((a >> 12) & 0x0f) != 0) {
      buf[j + 0] = hextab[(a >> 12) & 0x0f];
      space = 0;      
    } else {
      buf[j + 0] = ' ';
      space = 1;      
    }
    if(((a >> 8) & 0x0f) != 0 || !space) {
      buf[j + 1] = hextab[(a >> 8) & 0x0f];
      space = 0;      
    } else {
      buf[j + 1] = ' ';
      space = 1;      
    }    
    if(((a >> 4) & 0x0f) != 0 || !space) {
      buf[j + 2] = hextab[(a >> 4) & 0x0f];
      space = 0;      
    } else {
      buf[j + 2] = ' ';
      space = 1;      
    }    
    if(((a >> 0) & 0x0f) != 0 || !space) {
      buf[j + 3] = hextab[(a >> 0) & 0x0f];
    } else {
      buf[j + 3] = ' ';
    }    

        
    buf[j + 4] = '\n';
  }
  
}
/*-----------------------------------------------------------------------------------*/
static err_t
http_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err)
{
  static u16_t i, j;
  static char *data;
  static char fname[40];
  static struct fs_file file;

  
  if(err == ERR_OK && p != NULL) {
    data = p->payload;
    
    if(*data == 'G' &&
       *(data + 1) == 'E' &&
       *(data + 2) == 'T' &&
       *(data + 3) == ' ') {
      for(i = 0; i < 40; i++) {
        if(((char *)data + 4)[i] == ' ' ||
           ((char *)data + 4)[i] == '\r' ||
           ((char *)data + 4)[i] == '\n') {
          ((char *)data + 4)[i] = 0;
        }
      }
      i = 0;
      do {
        fname[i] = "/http"[i];
        i++;
      } while(fname[i - 1] != 0 && i < 40);
      i--;
      j = 0;
      do {
        fname[i] = ((char *)data + 4)[j];
        j++;
        i++;
      } while(fname[i - 1] != 0 && i < 40);

      printf("request for file ");
      printf(fname);
      printf("\r");
      if(fs_open(fname, &file)) {
        tcp_write(pcb, file.data, file.len, 0);
      } else if(httpd_strncmp(fname, "/http/stats.html", 15) == 0) {
	tcp_write(pcb, (void *)httphtmlheader,
		  sizeof(httphtmlheader) - 1, 0);
	tcp_write(pcb, (void *)statshtmlheader,
		  sizeof(statshtmlheader) - 1, 0);
#ifdef STATS	  
	hexprint((u16_t *)&stats,
		 (u16_t)(sizeof(struct stats_) / sizeof(u16_t)),
		 statsbuf);
	tcp_write(pcb, (void *)statsbuf, sizeof(statsbuf) - 1, 0);
#endif 
	tcp_write(pcb, (void *)statshtmlfooter,
		  sizeof(statshtmlfooter), 0);
      } else if(fs_open("/http/index.html", &file)) {
	tcp_write(pcb, file.data, file.len, 0);
      }
    }
    if(tcp_close(pcb) != ERR_OK) {      
      tcp_abort(pcb);
      return ERR_RST;
    }
  } 

  if(p != NULL) {
    pbuf_free(p);
  }

  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
static err_t
http_accept(void *arg, struct tcp_pcb *pcb, err_t err)
{
  tcp_recv(pcb, (err_t (*)(void *, struct tcp_pcb *, struct pbuf *, err_t))http_recv, NULL);
  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
void
httpd_init(void)
{
  struct tcp_pcb *pcb;

  pcb = tcp_pcb_new();
  tcp_bind(pcb, NULL, 80);
  pcb = tcp_listen(pcb);
  tcp_accept(pcb, http_accept, NULL);
}
/*-----------------------------------------------------------------------------------*/

