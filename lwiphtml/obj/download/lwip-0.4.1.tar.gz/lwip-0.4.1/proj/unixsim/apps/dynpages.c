/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: dynpages.c,v 1.2 2001/09/26 10:07:25 adam Exp $
 *
 */

static const char statshtmlheader[]="<html>\
<head><title>lwIP - A Lightweight TCP/IP Stack - Statistics</title></head>\
<body bgcolor=\"white\" text=\"black\">\
<table width=640><tr>\
<td width=\"15%\">\
<a href=\"http://www.sics.se/\"><img src=\"http://www.sics.se/~adam/lwip/img/sics.gif\" border=\"0\"></a>\
</td>\
<td width=\"70%\">\
<center><h1>lwIP - A Lightweight TCP/IP Stack <br> Statistics</h1></center>\
</td>\
<td width=\"15%\">\
&nbsp;\
</td>\
<br>\
</tr></td></table>\
<table width=\"640\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>\
<td width=\"100\">&nbsp;</td>\
<td width=\"530\" bgcolor=\"#e0e0e0\">\
<div align=\"right\"><b>Statistics</b></div>\
</td>\
<td width=\"10\">&nbsp;</td>\
</tr>\
<tr valign=\"top\">\
<td width=\"100\">\
&nbsp;\
</td> \
<td bgcolor=\"#e0e0e0\" width=\"530\">\
<table cellpadding=\"10\" border=\"0\" width=\"60%\"><tr><td>\
<pre>Link level * transmitted\n\
             retransmitted\n\
           * received\n\
             forwarded\n\
           * dropped\n\
           * checksum errors\n\
           * length errors\n\
           * memory errors\n\
             routing errors\n\
             protocol errors\n\
             option errors\n\
           * misc errors\n\
IP         * transmitted\n\
             retransmitted\n\
           * received\n\
           * forwarded\n\
           * dropped\n\
           * checksum errors\n\
           * length errors\n\
           * memory errors\n\
           * routing errors\n\
           * protocol errors\n\
           * option errors\n\
           * misc errors\n\
ICMP       * transmitted\n\
             retransmitted\n\
           * received\n\
             forwarded\n\
           * dropped\n\
           * checksum errors\n\
             length errors\n\
           * memory errors\n\
             routing errors\n\
           * protocol errors\n\
             option errors\n\
           * misc errors\n\
UDP        * transmitted\n\
             retransmitted\n\
           * received\n\
             forwarded\n\
           * dropped\n\
           * checksum errors\n\
           * length errors\n\
           * memory errors\n\
           * routing errors\n\
           * protocol errors\n\
             option errors\n\
           * misc errors\n\
TCP        * transmitted\n\
           * retransmitted\n\
           * received\n\
             forwarded\n\
           * dropped\n\
           * checksum errors\n\
           * length errors\n\
           * memory errors\n\
           * routing errors\n\
           * protocol errors\n\
           * option errors\n\
           * misc errors\n\
Pbufs      * avaiable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
             reclaimed\n\
Memory     * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
Memp PBUF  * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
UDP PCB    * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
TCP PCB    * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
TCP LISTEN * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
TCP TW     * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
TCP SEG    * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
Netbufs    * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
Netconns   * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
API msgs   * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
TCPIP msgs * avaliable\n\
           * used\n\
           * high water mark\n\
           * errors\n\
           * reclaimed\n\
Semaphores * used\n\
           * high water mark\n\
           * errors\n\
Mailboxes  * used\n\
           * high water mark\n\
           * errors\n\
</pre></td><td><pre>";

static const char statshtmlfooter[] = "</pre>\
</td></tr></table>\
</td>\
<td width=\"10\" bgcolor=\"#808080\">&nbsp;</td>\
</tr></table>\
<table width=\"640\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\
<tr>\
<td width=\"110\">\
<a href=\"http://www.sics.se/~adam/\">Adam Dunkels</a>\
</td>\
<td width=\"530\" bgcolor=\"#808080\">&nbsp;</td>\
</tr>\
</table>\
</body>\
</html>";

static const char stackshtmlheader[] = "<html>\
<head><title>lwIP - A Lightweight TCP/IP Stack - Statistics</title></head>\
<body bgcolor=\"white\" text=\"black\">\
<table width=640><tr>\
<td width=\"15%\">\
<a href=\"http://www.sics.se/\"><img src=\"http://www.sics.se/~adam/lwip/img/sics.gif\" border=\"0\"></a>\
</td>\
<td width=\"70%\">\
<center><h1>lwIP - A Lightweight TCP/IP Stack <br> Stack usage</h1></center>\
</td>\
<td width=\"15%\">\
&nbsp;\
</td>\
<br>\
</tr></td></table>\
<table width=\"640\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>\
<td width=\"100\">&nbsp;</td>\
<td width=\"530\" bgcolor=\"#e0e0e0\">\
<div align=\"right\"><b>Stack usage</b></div>\
</td>\
<td width=\"10\">&nbsp;</td>\
</tr>\
<tr valign=\"top\">\
<td width=\"100\">\
&nbsp;\
</td> \
<td bgcolor=\"#e0e0e0\" width=\"530\">\
<table cellpadding=\"10\" border=\"0\" width=\"100%\"><tr><td>\
<pre>";
