/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: test_pbuf.c,v 1.10 2001/10/07 18:15:17 adam Exp $
 */

#include "lwip/memp.h"
#include "lwip/pbuf.h"
#include "lwip/stats.h"

/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 1:
 ***
 **
 *
 * Purpose: 
 *   To test chaining of pbufs from the pool.
 *
 * Summary: 
 *   Allocate pbufs from the pool and chain them together. Deallocate
 *   the pbuf chain and verify that all are deallocated.
 *
 * Entry state:
 *   No pbufs allocated.
 *
 * Exit state: 
 *   No pbufs allocated.
 *
 * Plan: 
 *   1) Allocate three pbufs.
 *   2) Chain them together.
 *   3) Deallocate the chain.
 *   4) Check that no pbufs are allocated.
 *
 */
void
test_case_1(void)     
{
  struct pbuf *p1, *p2, *p3;

  /* 1) Allocate three pbufs. */
  p1 = pbuf_alloc(PBUF_RAW, PBUF_POOL_BUFSIZE, PBUF_POOL);
  p2 = pbuf_alloc(PBUF_RAW, PBUF_POOL_BUFSIZE, PBUF_POOL);
  p3 = pbuf_alloc(PBUF_RAW, PBUF_POOL_BUFSIZE, PBUF_POOL);

  /* 2) Chain them together. */
  pbuf_chain(p1, p2);
  pbuf_chain(p1, p3);

  /* 3) Deallocate the chain. */
  pbuf_free(p1);
  
  /* 4) Check that no pbufs are allocated. */
  if(stats.pbuf.used != 0) {
    printf("Test case 1 failed: pbufs are still allocated.\n");
    abort();
  }

  printf("Test case 1 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 2:
 ***
 **
 *
 * Purpose: 
 *   To test reallocation of pbufs from the pool.
 * 
 * Summary: 
 *   Allocate a number of pbufs from the pool, reallocate down to one
 *   pbuf. Verify that only one pbuf is allocated.
 *
 * Entry state:
 *   No pbufs allocated.
 *
 * Exit state: 
 *   One pbuf allocated.
 *
 * Plan: 
 *   1) Allocate a pbuf chain from the pool.
 *   2) Reallocate the chain into less than one pbuf.
 *   3) Check that only one pbuf is allocated.
 *
 */
void
test_case_2(void)     
{
  struct pbuf *p;

  /* 1) Allocate a pbuf chain from the pool. */
  p = pbuf_alloc(PBUF_RAW, PBUF_POOL_BUFSIZE * 10, PBUF_POOL);

  /* 2) Reallocate the chain into less than one pbuf. */
  pbuf_realloc(p, PBUF_POOL_BUFSIZE / 2);

  /* 3) Check that only one pbuf is allocated. */
  if(stats.pbuf.used > 1) {
    printf("Test case 2 failed: more than one pbuf is still allocated.\n");
    abort();
  }
  
  if(stats.pbuf.used < 1) {
    printf("Test case 2 failed: less than one pbuf is still allocated.\n");
    abort();
  }

  printf("Test case 2 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
void
reset(void)
{
  mem_init();
  memp_init();
  pbuf_init();
}
/*-----------------------------------------------------------------------------------*/
int
main(int argc, char **argv)
{
  reset();
  test_case_1();
  reset();
  test_case_2();
  reset();
  
  return 0;
}
/*-----------------------------------------------------------------------------------*/


