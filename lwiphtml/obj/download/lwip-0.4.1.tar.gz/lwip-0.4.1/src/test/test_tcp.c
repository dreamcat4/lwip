/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: test_tcp.c,v 1.13 2001/10/06 18:04:18 adam Exp $
 */

#include "lwip/tcp.h"
#include "lwip/memp.h"
#include "lwip/pbuf.h"

/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 1:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming out-of-sequence TCP segments.
 *
 * Summary: 
 *   Inject one out-of-sequence segment to see if it ends up on
 *   ->ooseq.
 *
 * Entry state:
 *   A TCP PCB in the ESTABLISHED state with no out-of-sequence data
 *   queued.
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with the out-of-sequence data
 *   queued on the ->ooseq queue. 
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
 *      1000 and an empty ->ooseq. 
 *   2) Set up a TCP segment with sequence number 1100. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_1(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000 and an empty ->ooseq. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 60;

  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq == NULL) {
    printf("Test case 1 failed. No segment on ->ooseq.\n");
    abort();
  }

  if(pcb->ooseq->tcphdr->seqno != 1100) {
    printf("Test case 1 failed. Sequence number != 1100.\n");
    abort();
  }
  printf("Test case 1 succeeded.\n");
    
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 2:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming out-of-sequence TCP segments.
 *
 * Summary: 
 *   Inject one out-of-sequence segment to see if it ends up on
 *   the right place in ->ooseq.
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with one segment of
 *   out-of-sequence data queued.
 *
 * Exit state:
 *   A TCP PCB in the ESTABLISHED state with two out-of-sequence
 *   segments queued on the ->ooseq queue in the correct order.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to 1000
 *      and one segment with sequence number 1050 and length 50 on the
 *      ->ooseq queue.
 *   2) Set up a TCP segment with sequence number 1100. 
 *   3) Run the tcp_recieve() function.
 * */
void
test_case_2(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000 and one segment with sequence number 1050 an length 50 on
     the ->ooseq queue. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1050;
  seg->len = 50;

  pcb->ooseq = seg;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 50;

  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq == NULL) {
    printf("Test case 2 failed. No segment on ->ooseq.\n");
    abort();
  }

  if(pcb->ooseq->tcphdr->seqno != 1050) {
    printf("Test case 2 failed. Sequence number of first segment != 1050.\n");
    abort();
  }

  if(pcb->ooseq->next == NULL) {
    printf("Test case 2 failed. Only one segment on ->ooseq.\n");
    abort();
  }
  
  if(pcb->ooseq->next->tcphdr->seqno != 1100) {
    printf("Test case 2 failed. Sequence number of second segment != 1100.\n");
    abort();
  }
  
  printf("Test case 2 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 3:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming out-of-sequence TCP segments.
 *
 * Summary: 
 *   Inject one out-of-sequence segment that partially covers a
 *   segment that is on ->ooseq, and see that the segments are trimmed
 *   in the right way and that the segment ends up on the right place
 *   in ->ooseq. 
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with one segment of
 *   out-of-sequence data queued.
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with two out-of-sequence
 *   segments queued on the ->ooseq queue in the correct order and
 *   with the right sizes.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to 1000
 *      and one segment with sequence number 1050 and length 60 on the
 *      ->ooseq queue.
 *   2) Set up a TCP segment with sequence number 1100. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_3(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000 and one segment with sequence number 1050 an length 60 on
     the ->ooseq queue. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1050;
  seg->len = 60;

  pcb->ooseq = seg;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 50;

  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq == NULL) {
    printf("Test case 3 failed. No segment on ->ooseq.\n");
    abort();
  }

  if(pcb->ooseq->tcphdr->seqno != 1050) {
    printf("Test case 3 failed. Sequence number of first segment != 1050.\n");
    abort();
  }

  if(pcb->ooseq->len != 50) {
    printf("Test case 3 failed. Segment length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->p->tot_len != 50) {
    printf("Test case 3 failed. Pbuf length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->next == NULL) {
    printf("Test case 3 failed. Only one segment on ->ooseq.\n");
    abort();
  }
  
  if(pcb->ooseq->next->tcphdr->seqno != 1100) {
    printf("Test case 3 failed. Sequence number of second segment != 1100.\n");
    abort();
  }
  
  printf("Test case 3 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 4:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming out-of-sequence TCP segments.
 *
 * Summary: 
 *   Inject one out-of-sequence segment that partially covers a
 *   segment that is on ->ooseq, and see that the segments are trimmed
 *   in the right way and that the segment ends up on the right place
 *   in ->ooseq. 
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with one segment of
 *   out-of-sequence data queued.
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with two out-of-sequence
 *   segments queued on the ->ooseq queue in the correct order and
 *   with the right sizes.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to 1000
 *      and one segment with sequence number 1100 on the ->ooseq queue. 
 *   2) Set up a TCP segment with sequence number 1050 and lendth 60. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_4(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000 and one segment with sequence number 1050 an length 60 on
     the ->ooseq queue. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 60;

  pcb->ooseq = seg;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1050;
  seg->len = 60;

  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq == NULL) {
    printf("Test case 4 failed. No segment on ->ooseq.\n");
    abort();
  }

  if(pcb->ooseq->tcphdr->seqno != 1050) {
    printf("Test case 4 failed. Sequence number of first segment != 1050.\n");
    abort();
  }

  if(pcb->ooseq->len != 50) {
    printf("Test case 4 failed. Segment length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->p->tot_len != 50) {
    printf("Test case 4 failed. Pbuf length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->next == NULL) {
    printf("Test case 4 failed. Only one segment on ->ooseq.\n");
    abort();
  }
  
  if(pcb->ooseq->next->tcphdr->seqno != 1100) {
    printf("Test case 4 failed. Sequence number of second segment != 1100.\n");
    abort();
  }
  
  printf("Test case 4 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 5:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming out-of-sequence TCP segments.
 *
 * Summary: 
 *   Inject one out-of-sequence segment that partially covers two
 *   segments that are on ->ooseq, and see that the segments are trimmed
 *   in the right way and that the segment ends up on the right place
 *   in ->ooseq. 
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with two segments of
 *   out-of-sequence data queued.
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with three out-of-sequence
 *   segments queued on the ->ooseq queue in the correct order and
 *   with the right sizes.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to 1000,
 *      one segment with sequence number 1050 and length 60, and * one
 *      segment with sequence number 1150 on the ->ooseq queue. 
 *   2) Set up a TCP segment with sequence number 1100 and lendth 60. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_5(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000 and one segment with sequence number 1050 an length 60 on
     the ->ooseq queue. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1050;
  seg->len = 60;

  pcb->ooseq = seg;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1150;
  seg->len = 60;

  pcb->ooseq->next = seg;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 100, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 600;

  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq == NULL) {
    printf("Test case 5 failed. No segment on ->ooseq.\n");
    abort();
  }

  if(pcb->ooseq->tcphdr->seqno != 1050) {
    printf("Test case 5 failed. Sequence number of first segment != 1050.\n");
    abort();
  }

  if(pcb->ooseq->len != 50) {
    printf("Test case 5 failed. Segment length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->p->tot_len != 50) {
    printf("Test case 5 failed. Pbuf length of first segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->next == NULL) {
    printf("Test case 5 failed. Only one segment on ->ooseq.\n");
    abort();
  }
  
  if(pcb->ooseq->next->tcphdr->seqno != 1100) {
    printf("Test case 5 failed. Sequence number of second segment != 1100.\n");
    abort();
  }

  if(pcb->ooseq->next->len != 50) {
    printf("Test case 5 failed. Segment length of second segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->next->p->tot_len != 50) {
    printf("Test case 5 failed. Pbuf length of second segment != 50.\n");
    abort();
  }

  if(pcb->ooseq->next->next == NULL) {
    printf("Test case 5 failed. Only two segments on ->ooseq.\n");
    abort();
  }
  
  if(pcb->ooseq->next->next->tcphdr->seqno != 1150) {
    printf("Test case 5 failed. Sequence number of third segment != 1150.\n");
    abort();
  }
  
  printf("Test case 5 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 6:
 ***
 **
 *
 * Purpose:
 *   To test processing of incoming TCP segments that are have
 *   sequence numbers that are slightly lower that expected.
 * 
 * Summary: 
 *   Inject a segment that has a sequence number that is a few bytes
 *   lower than the next expected. See that the correct number of
 *   bytes are trimmed off.
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with 1000 as the next expected
 *   sequence number. 
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with 1000 as the next expected
 *   sequence number. The ->recv_data pointer should point to a pbuf
 *   with the correct number of bytes removed from the data.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
 *      1000.
 *   2) Set up a TCP segment with sequence number 960 and length 100. The
 *      data in the associated pbuf consists of 100 bytes with values
 *      increasing from 0. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_6(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;
  int i;

    
  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000. Add a receiver function. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  /* Step 2: Set up a TCP segment with sequence number 960 and length
       100. The data in the associated pbuf is set up to consist of 100
       bytes with values increasing from 0. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 220, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 860;
  seg->len = 200;

  for(i = 0; i < 72; i++) {    
    ((char *)seg->p->payload)[i] = i;
  }
  
  for(i = 72; i < 200; i++) {    
    ((char *)seg->p->next->payload)[i - 72] = i;
  }
  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit conditions. */
  if(pcb->recv_data == NULL) {
    printf("Test case 6 failed. No pbuf on ->recv_data.\n");
    abort();
  }

  if(*((unsigned char *)pcb->recv_data->next->payload) != 140) {
    printf("Test case 6 failed. First data byte != 140 (%d).\n",
	   *((unsigned char *)pcb->recv_data->payload));
    abort();
  }

  printf("Test case 6 succeeded.\n");
  

}
/*-----------------------------------------------------------------------------------*/
/*
 **
 ***
 **** Test case 7:
 ***
 **
 *
 * Purpose: 
 *   To test processing of incoming in-sequence segments when
 *   out-of-sequence TCP segments are present that become in-sequence
 *   when the new segment arrives.
 *
 * Summary: 
 *   Inject one in-sequence segment that makes a segment on ->ooseq
 *   become in sequence. Verify that the two segments are chained and
 *   passed to the application.
 *
 * Entry state: 
 *   A TCP PCB in the ESTABLISHED state with one segment of
 *   out-of-sequence data with sequence number 1100 queued.
 *
 * Exit state: 
 *   A TCP PCB in the ESTABLISHED state with a chanined pbuf of the
 *   correct length on ->recv_data.
 *
 * Plan: 
 *   1) Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to 1000,
 *      one segment with sequence number 1100 and length 100 on the
 *      ->ooseq queue. 
 *   2) Set up a TCP segment with sequence number 1000 and length 100. 
 *   3) Run the tcp_recieve() function.
 *
 */
void
test_case_7(void)
{
  struct tcp_pcb *pcb;
  struct tcp_seg *seg;


  /* Step 1: Set up a TCP PCB in ESTABLISHED state with rcv_nxt set to
     1000, one segment with sequence number 1100 and length 100 on the
     ->ooseq queue. */
  pcb = tcp_pcb_new();
  pcb->state = ESTABLISHED;
  pcb->rcv_nxt = 1000;

  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 120, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1100;
  seg->len = 100;
  pcb->ooseq = seg;

  /* Step 2: Set up a TCP segment with sequence number 1100. */
  seg = memp_malloc(MEMP_TCP_SEG);
  seg->p = pbuf_alloc(PBUF_IP, 120, PBUF_POOL);
  seg->next = NULL;
  seg->tcphdr = seg->p->payload;
  pbuf_header(seg->p, -TCP_HLEN);
  seg->data = seg->p->payload;
  seg->tcphdr->seqno = 1000;
  seg->len = 100;

  
  /* Step 3: Run tcp_receive(). */
  tcp_receive(seg, pcb);

  /* Check exit condition. */
  if(pcb->ooseq != NULL) {
    printf("Test case 7 failed. Segments still on ->ooseq.\n");
    abort();
  }

  if(pcb->recv_data == NULL) {
    printf("Test case 7 failed. No data on ->recv_data.\n");
    abort();
  }

  if(pcb->recv_data->tot_len != 200) {
    printf("Test case 7 failed. Too much data on ->recv_data (%d).\n",
	   pcb->recv_data->tot_len);
    abort();
  }
  
  printf("Test case 7 succeeded.\n");
}
/*-----------------------------------------------------------------------------------*/
void
reset(void)
{
  mem_init();
  memp_init();
  pbuf_init();
}
/*-----------------------------------------------------------------------------------*/
int
main(int argc, char **argv)
{
  reset();
  test_case_1();
  reset();
  test_case_2();
  reset();
  test_case_3();
  reset();
  test_case_4();
  reset();
  test_case_5();
  reset();
  test_case_6();
  reset();
  test_case_7();
  reset();
  
  return 0;
}
/*-----------------------------------------------------------------------------------*/


