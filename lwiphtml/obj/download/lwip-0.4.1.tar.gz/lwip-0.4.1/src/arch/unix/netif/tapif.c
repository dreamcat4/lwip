/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tapif.c,v 1.6 2001/09/26 10:07:45 adam Exp $
 */
#ifdef linux

#include "lwip/debug.h"

#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/in.h>

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
/*#include "lwip/ip.h"*/
#include "lwip/pbuf.h"
#include "netif/tapif.h"
#include "lwip/sys.h"

#ifdef TAPIF_DROP
static int dropper = 0;
#endif /* TAPIF_DROP */

struct tapif_hdr {
  unsigned short xx;  /* ??? */
  unsigned char dest[6];
  unsigned char source[6];
  unsigned short proto;
};

struct tapif {
  int fd;
  int s;
  struct sockaddr_pkt pkt;
};


/*-----------------------------------------------------------------------------------*/
static void
tapif_irq_handler(int fd, void *data)
{
  struct netif *netif;
  struct tapif *tap;
  char buf[4096], *bufptr;
  int len, rlen;
  struct pbuf *p, *q;

  netif = data;
  tap = netif->state;

  len = sizeof(buf);
  len = read(tap->fd, buf, len);  
  p = pbuf_alloc(PBUF_LINK, PBUF_MAX_SIZE, PBUF_POOL);
  if(p != NULL) {
    rlen = len;
    bufptr = buf;
    q = p;
    while(rlen > 0) {
      DEBUGF(TAPIF_DEBUG, ("tapif_irq_handler: bcopy(0x%lx, 0x%lx, len %d)\n",
			   (long)bufptr, (long)q->payload, rlen > q->len? q->len: rlen));

      bcopy(bufptr, q->payload, rlen > q->len? q->len: rlen);
      rlen -= q->len;
      bufptr += q->len;
      q = q->next;
    }

    pbuf_realloc(p, len);
    p->payload = (void *)((char *)p->payload + 16);
    p->len -= 16;
    p->tot_len -= 16;

    /*    DEBUGF("tapif_irq_handler: read %d bytes\n", len); */
#ifdef TAPIF_DROP  
    /*    if((dropper++ > 7) && (dropper % 5 == 0)) {*/
    if(((double)rand()/(double)RAND_MAX) < 0.00005) {
      DEBUGF("+++tapif_irq_handler: Packet dropped\n");
      pbuf_free(p);
      return;
    }
#endif /* TAPIF_DROP */
    netif->input(p, netif);
  }

}
/*-----------------------------------------------------------------------------------*/
static int
tapif_output(struct netif *netif, struct pbuf *p,
	     struct ip_addr *ipaddr)
{
  struct tapif *tapif;
  char *data;
  struct pbuf *q;
  int i, j;
  struct sockaddr_in sin;                 /* socket protocol structure */

  sin.sin_family      = AF_INET;
  /*  sin.sin_port        = 0;*/
  sin.sin_addr.s_addr = ipaddr->addr;

  
#ifdef TAPIF_DROP
  /*  if((dropper++ > 7) && (dropper % 4 == 0)) {*/
  if(((double)rand()/(double)RAND_MAX) < 0.1) {
    DEBUGF("+++tapif_output: Packet dropped\n");
    return 1;
  }
#endif /* TAPIF_DROP */
  
  tapif = netif->state;
  data = malloc(p->tot_len);

  i = 0;
  for(q = p; q != NULL; q = q->next) {
    for(j = 0; j < q->len; j++) {
      data[i] = ((char *)q->payload)[j];
      i++;
    }
  }

  DEBUGF(TAPIF_DEBUG, ("tapif: Sending len %d\n", p->tot_len));

  /*  if(sendto(tapif->s, data, p->tot_len, MSG_DONTROUTE,
      (struct sockaddr *)&sin, sizeof(sin)) == -1) {*/
    if(sendto(tapif->s, data, p->tot_len, 0,
	      (struct sockaddr *)&sin, sizeof(sin)) == -1) {
    perror("tapif_output: sendto");
  }
  free(data);
  return 1;

}
/*-----------------------------------------------------------------------------------*/
void
tapif_init(struct netif *netif)
{
  struct tapif *tap;
  int one = 1;
  char buf[200];
  
  tap = malloc(sizeof(struct tapif));  
  netif->state = tap;
  netif->name[0] = 't';
  netif->name[1] = 'p';
  netif->output = tapif_output;
    
  tap->fd = open("/dev/tap0", O_RDONLY);
  DEBUGF(TAPIF_DEBUG, ("tapif_init: fd %d\n", tap->fd));
  if(tap->fd == -1) {
    perror("tapif_init");
    exit(1);
  }
  snprintf(buf, sizeof(buf), "ifconfig tap0 inet %d.%d.%d.%d",
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)));
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);
  sys_irq(tap->fd, tapif_irq_handler, netif);

  tap->s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
  if(tap->s == -1) {
    perror("tapif_init: socket");
  }
  if(setsockopt(tap->s, IPPROTO_IP, IP_HDRINCL,
		(char *)&one, sizeof(one)) < 0) {
    perror("tapif_init: setsockopt");
  }
}
/*-----------------------------------------------------------------------------------*/
static void *
tapif_thread(void *arg)
{
  struct netif *netif;
  struct tapif *tapif;

  netif = arg;
  tapif = netif->state;
  
  sys_irq(tapif->fd, tapif_irq_handler, netif);
  sys_main();
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
void
tapif_init_thread(struct netif *netif)
{
  struct tapif *tap;
  int one = 1;
  char buf[200];
    
  tap = malloc(sizeof(struct tapif));
  netif->state = tap;
  netif->name[0] = 't';
  netif->name[1] = 'p';
  netif->output = tapif_output;

  tap = netif->state;
  tap->fd = open("/dev/tap0", O_RDONLY);
  if(tap->fd == -1) {
    perror("tapif_init");
    exit(1);
  }
  DEBUGF(TAPIF_DEBUG, ("tapif_init: fd %d\n", tap->fd));
  snprintf(buf, sizeof(buf), "ifconfig tap0 inet %d.%d.%d.%d",
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)));
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);
  sys_irq(tap->fd, tapif_irq_handler, netif);

  tap->s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
  if(tap->s == -1) {
    perror("tapif_init: socket");
  }
  if(setsockopt(tap->s, IPPROTO_IP, IP_HDRINCL,
		(char *)&one, sizeof(one)) < 0) {
    perror("tapif_init: setsockopt");
  }
  sys_thread_new(tapif_thread, netif);
}
/*-----------------------------------------------------------------------------------*/
#endif /* linux */






