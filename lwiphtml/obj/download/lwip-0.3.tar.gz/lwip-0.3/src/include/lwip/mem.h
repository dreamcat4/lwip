/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: mem.h,v 1.7 2001/02/21 19:52:26 adam Exp $
 */
#ifndef __LWIP_MEM_H__
#define __LWIP_MEM_H__


void mem_init(void);

#include "lwip/debug.h"
#include "lwip/opt.h"

#ifdef MEM_TRACKING
#define mem_malloc(x) _mem_malloc(x, __FILE__, __LINE__)
void *_mem_malloc(unsigned int size, char *file, int line);
#define mem_malloc2(x) _mem_malloc(x, __FILE__, __LINE__)
void *_mem_malloc2(unsigned int size, char *file, int line);
#define mem_free(x) _mem_free(x, __FILE__, __LINE__)
void _mem_free(void *mem, char *file, int line);
#define mem_realloc(x, y) _mem_realloc(x, y, __FILE__, __LINE__)
void *_mem_realloc(void *mem, unsigned int size, char *file, int line);
#define mem_reallocm(x, y) _mem_realloc(x, y, __FILE__, __LINE__)
void *_mem_reallocm(void *mem, unsigned int size, char *file, int line);
#else /* MEM_TRACKING */
void *mem_malloc(unsigned int size);
void *mem_malloc2(unsigned int size);
void mem_free(void *mem);
void *mem_realloc(void *mem, unsigned int size);
void *mem_reallocm(void *mem, unsigned int size);
#endif /* MEM_TRACKING */

#if MEM_DEBUG
void mem_debug_print(void);
void mem_debug_print_more(void);
#endif /* MEM_DEBUG */

#ifdef LWIP_DEBUG
int mem_debug_print_more_buf(char *buf, int len);
#endif /* LWIP_DEBUG */

#ifdef MEM_PERF
void mem_perf_start(void);
void mem_perf_init(char *fname);
#endif /* MEM_PERF */

#ifdef MEM_RECLAIM
typedef unsigned int (*mem_reclaim_func)(void *data, unsigned int size);
void mem_register_reclaim(mem_reclaim_func f, void *data);
void mem_reclaim(unsigned int size);
#else
#define mem_reclaim(x)
#endif /* MEM_RECLAIM */


#endif /* __LWIP_MEM_H__ */

