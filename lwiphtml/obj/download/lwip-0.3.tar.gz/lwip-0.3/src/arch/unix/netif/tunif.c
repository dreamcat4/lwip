/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tunif.c,v 1.3 2001/02/21 20:21:32 adam Exp $
 */

#include "lwip/debug.h"

#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#ifndef linux
#include <net/if_tun.h>
#endif /* linux */

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
/*#include "lwip/ip.h"*/
#include "lwip/pbuf.h"
#include "netif/tunif.h"
#include "lwip/sys.h"

#ifdef TUNIF_DROP
static int dropper = 0;
#endif /* TUNIF_DROP */

struct tunif {
  int fd;
};


/*-----------------------------------------------------------------------------------*/
static void
tunif_irq_handler(int fd, void *data)
{
  struct netif *netif;
  struct tunif *tun;
  char buf[4096], *bufptr;
  int len, rlen;
  struct pbuf *p, *q;

  netif = data;
  tun = netif->state;

  len = sizeof(buf);
  len = read(tun->fd, buf, len);  
  p = pbuf_alloc(PBUF_LINK, PBUF_MAX_SIZE, PBUF_POOL);
  if(p != NULL) {
    rlen = len;
    bufptr = buf;
    q = p;
    while(rlen > 0) {
      DEBUGF(TUNIF_DEBUG, ("tunif_irq_handler: bcopy(0x%lx, 0x%lx, len %d)\n",
            (long)bufptr, (long)q->payload, rlen > q->len? q->len: rlen));
      bcopy(bufptr, q->payload, rlen > q->len? q->len: rlen);
      rlen -= q->len;
      bufptr += q->len;
      q = q->next;
    }
    
    pbuf_realloc(p, len);
    /*    DEBUGF("tunif_irq_handler: read %d bytes\n", len); */
#ifdef TUNIF_DROP  
    /*    if((dropper++ > 7) && (dropper % 5 == 0)) {*/
    if(((double)rand()/(double)RAND_MAX) < 0.00005) {
      DEBUGF("+++tunif_irq_handler: Packet dropped\n");
      pbuf_free(p);
      return;
    }
#endif /* TUNIF_DROP */
    netif->input(p, netif);
  }

}
/*-----------------------------------------------------------------------------------*/
static int
tunif_output(struct netif *netif, struct pbuf *p, struct ip_addr *ipaddr)
{
  struct tunif *tunif;
  char *data;
  struct pbuf *q;
  int i, j, ret;
  
#ifdef TUNIF_DROP
  /*  if((dropper++ > 7) && (dropper % 4 == 0)) {*/
  if(((double)rand()/(double)RAND_MAX) < 0.1) {
    DEBUGF("+++tunif_output: Packet dropped\n");
    return 1;
  }
#endif /* TUNIF_DROP */

  if((((char *)p->payload)[0] & 0xf0) != 0x40) {
    printf("tunif_output: ip v != 4\n");
    abort();
  }
  
  tunif = netif->state;
  data = malloc(p->tot_len);

  i = 0;
  for(q = p; q != NULL; q = q->next) {
    for(j = 0; j < q->len; j++) {
      data[i] = ((char *)q->payload)[j];
      i++;
    }
  }

  DEBUGF(TUNIF_DEBUG, ("tunif: Sending len %d\n", p->tot_len));

/*  if (af == AF_INET) {
         ret = write (fd, ptr, len);
         if (ret != len)
            abort ();
            } else {*/
  if(1) {
    ret = write(tunif->fd, data, p->tot_len);
  } else {
    struct iovec iov[2];
    int af;

    af = AF_INET;
    iov[0].iov_base = (char *)&af;
    iov[0].iov_len  = sizeof(af);
    iov[1].iov_base = data;
    iov[1].iov_len  = p->tot_len;
    
    ret = writev(tunif->fd, iov, 2);
  }
  if(ret == -1) {
    perror("tunif_output: write");
  }
  free(data);
  return 1;

}
/*-----------------------------------------------------------------------------------*/
void
tunif_init(struct netif *netif)
{
  struct tunif *tun;
  char buf[200];
  
  tun = malloc(sizeof(struct tunif));
  netif->state = tun;
  netif->name[0] = 't';
  netif->name[1] = 'n';
  netif->output = tunif_output;

  tun->fd = open("/dev/tun0", O_RDWR);
  if(tun->fd == -1) {
    perror("tunif_init");
    exit(1);
  }
#ifdef linux
  /*  system("ifconfig tun0 10.0.0.1 pointopoint 10.0.0.2");
      system("route add -net 10.0.0.0 netmask 255.0.0.0 tun0");*/
  abort(); /* XXX error! */
#else
  snprintf(buf, sizeof(buf), "ifconfig tun0 inet %d.%d.%d.%d %d.%d.%d.%d",
	   ip4_addr1(&(netif->gw)),
	   ip4_addr2(&(netif->gw)),
	   ip4_addr3(&(netif->gw)),
	   ip4_addr4(&(netif->gw)),
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)));
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);
#endif /* linux */
  sys_irq(tun->fd, tunif_irq_handler, netif);
}
/*-----------------------------------------------------------------------------------*/
static void *
tunif_thread(void *arg)
{
  struct netif *netif;
  struct tunif *tunif;

  DEBUGF(UNIXIF_DEBUG, ("unixif_thread: started.\n"));

  netif = arg;
  tunif = netif->state;
  
  sys_irq(tunif->fd, tunif_irq_handler, netif);
  sys_main();
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
void
tunif_init_thread(struct netif *netif)
{
  struct tunif *tun;
  int data;
  char buf[200];
  
  tun = malloc(sizeof(struct tunif));
  netif->state = tun;
  netif->name[0] = 't';
  netif->name[1] = 'n';
  netif->output = tunif_output;

  tun = netif->state;
  tun->fd = open("/dev/tun0", O_RDWR);
  if(tun->fd == -1) {
    perror("tunif_init");
    exit(1);
  }
#ifdef linux
  /*  system("ifconfig tun0 10.0.0.1 pointopoint 10.0.0.2");
      system("route add -net 10.0.0.0 netmask 255.0.0.0 tun0");*/
  abort(); /* XXX error! */
#else
  snprintf(buf, sizeof(buf), "ifconfig tun0 inet %d.%d.%d.%d %d.%d.%d.%d",
	   ip4_addr1(&(netif->gw)),
	   ip4_addr2(&(netif->gw)),
	   ip4_addr3(&(netif->gw)),
	   ip4_addr4(&(netif->gw)),
	   ip4_addr1(&(netif->ip_addr)),
	   ip4_addr2(&(netif->ip_addr)),
	   ip4_addr3(&(netif->ip_addr)),
	   ip4_addr4(&(netif->ip_addr)));
  DEBUGF(TAPIF_DEBUG, ("tapif_init: system(\"%s\");\n", buf));
  system(buf);
  /*  system("ifconfig tun0 inet 10.0.0.1 10.0.0.2");*/
#endif /* linux */

  /*  system("ifconfig tun0 inet6 fec0:0:0:1:2c0:6cff:fe00:f043 fec0:0:0:1:2c0:6cff:fe00:f044");*/
   
  sys_thread_new(tunif_thread, netif);
}
/*-----------------------------------------------------------------------------------*/

