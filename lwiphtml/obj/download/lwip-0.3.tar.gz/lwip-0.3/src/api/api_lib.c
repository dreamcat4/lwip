/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: api_lib.c,v 1.11 2001/02/26 17:56:38 adam Exp $
 */

/* This is the part of the API that is linked with
   the application */

#include "lwip/debug.h"
#include "lwip/api.h"
#include "lwip/api_msg.h"
#include "lwip/mem.h"

#include "lwip/debug.h"

/*-----------------------------------------------------------------------------------*/
struct
netbuf *netbuf_new(void)
{
  struct netbuf *buf;

  buf = mem_malloc(sizeof(struct netbuf));
  if(buf != NULL) {
    buf->p = NULL;
    buf->ptr = NULL;
    return buf;
  } else {
    return NULL;
  }
}
/*-----------------------------------------------------------------------------------*/
void
netbuf_delete(struct netbuf *buf)
{
  if(buf != NULL) {
    if(buf->p != NULL) {
      pbuf_free(buf->p);
      buf->p = buf->ptr = NULL;
    }
    mem_free(buf);
  }
}
/*-----------------------------------------------------------------------------------*/
void *
netbuf_alloc(struct netbuf *buf, int size)
{
  /* Deallocate any previously allocated memory. */
  if(buf->p != NULL) {
    pbuf_free(buf->p);
  }
  buf->p = pbuf_alloc(size, PBUF_TRANSPORT, PBUF_RAM);
  buf->ptr = buf->p;
  return buf->p->payload;
}
/*-----------------------------------------------------------------------------------*/
int
netbuf_free(struct netbuf *buf)
{
  if(buf->p != NULL) {
    pbuf_free(buf->p);
  }
  buf->p = buf->ptr = NULL;
  return 0;
}
/*-----------------------------------------------------------------------------------*/
int
netbuf_ref(struct netbuf *buf, void *data, int size)
{
  if(buf->p != NULL) {
    pbuf_free(buf->p);
  }
  buf->p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_ROM);
  buf->p->payload = data;
  buf->p->len = buf->p->tot_len = size;
  buf->ptr = buf->p;
  return 0;
}
/*-----------------------------------------------------------------------------------*/
void
netbuf_chain(struct netbuf *head, struct netbuf *tail)
{
  pbuf_chain(head->p, tail->p);
  head->ptr = head->p;
  mem_free(tail);
}
/*-----------------------------------------------------------------------------------*/
int
netbuf_len(struct netbuf *buf)
{
  return buf->p->tot_len;
}
/*-----------------------------------------------------------------------------------*/
int
netbuf_data(struct netbuf *buf, void **data, int *len)
{
  if(buf->ptr == NULL) {
    return -1;
  }
  *data = buf->ptr->payload;
  *len = buf->ptr->len;
  return 0;
}
/*-----------------------------------------------------------------------------------*/
int
netbuf_next(struct netbuf *buf)
{
  if(buf->ptr->next == NULL) {
    return -1;
  }
  buf->ptr = buf->ptr->next;
  if(buf->ptr->next == NULL) {
    return 1;
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/
void
netbuf_first(struct netbuf *buf)
{
  buf->ptr = buf->p;
}
/*-----------------------------------------------------------------------------------*/
void
netbuf_copy(struct netbuf *buf, void *data, int len)
{
  struct pbuf *p;
  int i, left;

  left = 0;

  /* This implementation is bad. It should use bcopy
     instead. */
  for(p = buf->p; left < len && p != NULL; p = p->next) {
    for(i = 0; i < p->len; i++) {
      ((char *)data)[left] = ((char *)p->payload)[i];
      if(++left >= len) {
	return;
      }
    }
  }
  return;
}
/*-----------------------------------------------------------------------------------*/
struct ip_addr *
netbuf_fromaddr(struct netbuf *buf)
{
  return buf->fromaddr;
}
/*-----------------------------------------------------------------------------------*/
unsigned short
netbuf_fromport(struct netbuf *buf)
{
  return buf->fromport;
}
/*-----------------------------------------------------------------------------------*/
struct
netconn *netconn_new(enum netconn_type t)
{
  struct netconn *conn;
  struct api_msg *msg;
  sys_mbox_t mbox;
  
  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return NULL;
  }
  msg->type = API_MSG_NEWCONN;
  msg->msg.conntype = t;
  if((mbox = sys_mbox_new()) == SYS_MBOX_NULL) {
    mem_free(msg);    
    return NULL;
  }
  msg->msg.msg.mbox = mbox;
  api_msg_post(msg);
  sys_mbox_fetch(mbox, (void **)&conn);
  sys_mbox_free(mbox);

  conn->err = ERR_OK;
  return conn;
}
/*-----------------------------------------------------------------------------------*/
void
netconn_delete(struct netconn *conn)
{
  struct api_msg *msg;

  if(conn == NULL) {
    return;
  }
  
  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return;
  }
  msg->type = API_MSG_DELCONN;
  msg->msg.conn = conn;
  api_msg_post(msg);
}
/*-----------------------------------------------------------------------------------*/
enum netconn_type
netconn_type(struct netconn *conn)
{
  return conn->type;
}
/*-----------------------------------------------------------------------------------*/
int
netconn_peer(struct netconn *conn, struct ip_addr **addr,
	     unsigned short *port)
{
  switch(conn->type) {
  case NETCONN_UDPLITE:
  case NETCONN_UDPNOCHKSUM:
  case NETCONN_UDP:
    *addr = &(conn->pcb.udp->dest_ip);
    *port = conn->pcb.udp->dest_port;
    break;
  case NETCONN_TCP:
    *addr = &(conn->pcb.tcp->dest_ip);
    *port = conn->pcb.tcp->dest_port;
    break;
  }
  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_addr(struct netconn *conn, struct ip_addr **addr,
	     unsigned short *port)
{
  switch(conn->type) {
  case NETCONN_UDPLITE:
  case NETCONN_UDPNOCHKSUM:
  case NETCONN_UDP:
    *addr = &(conn->pcb.udp->local_ip);
    *port = conn->pcb.udp->local_port;
    break;
  case NETCONN_TCP:
    *addr = &(conn->pcb.tcp->local_ip);
    *port = conn->pcb.tcp->local_port;
    break;
  }
  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_bind(struct netconn *conn, struct ip_addr *addr,
	    unsigned short port)
{
  struct api_msg *msg;

  if(conn == NULL) {
    return ERR_VAL;
  }
  
  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return (conn->err = ERR_MEM);
  }
  msg->type = API_MSG_BIND;
  msg->msg.conn = conn;
  msg->msg.msg.bc.ipaddr = addr;
  msg->msg.msg.bc.port = port;
  api_msg_post(msg);

  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_connect(struct netconn *conn, struct ip_addr *addr,
		   unsigned short port)
{
  struct api_msg *msg;
  sys_mbox_t mbox;
  int *errptr;
  
  if(conn == NULL) {
    return ERR_VAL;
  }

  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return ERR_MEM;
  }
  mbox = sys_mbox_new();
  if(mbox == SYS_MBOX_NULL) {
    mem_free(msg);
    return ERR_MEM;
  }
  conn->connmbox = mbox;
  msg->type = API_MSG_CONNECT;
  msg->msg.conn = conn;  
  msg->msg.msg.bc.ipaddr = addr;
  msg->msg.msg.bc.port = port;
  api_msg_post(msg);
  sys_mbox_fetch(mbox, (void **)&errptr);
  sys_mbox_free(mbox);
  conn->err = *errptr;
  mem_free(errptr);
  return conn->err;
}
/*-----------------------------------------------------------------------------------*/
int
netconn_listen(struct netconn *conn)
{
  struct api_msg *msg;

  if(conn == NULL) {
    return ERR_VAL;
  }

  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return (conn->err = ERR_MEM);
  }
  msg->type = API_MSG_LISTEN;
  msg->msg.conn = conn;
  api_msg_post(msg);  
  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
struct netconn *
netconn_accept(struct netconn *conn)
{
  struct api_msg *msg;
  struct netconn *newconn;
  
  if(conn == NULL) {
    return NULL;
  }

  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    conn->err = ERR_MEM;
    return NULL;
  }
  if(conn->acceptmbox == SYS_MBOX_NULL) {
    if((conn->acceptmbox = sys_mbox_new()) == SYS_MBOX_NULL) {
      conn->err = ERR_MEM;
      return NULL;
    }
  }
  msg->type = API_MSG_ACCEPT;
  msg->msg.conn = conn;
  msg->msg.msg.mbox = conn->acceptmbox;
  api_msg_post(msg);
  sys_mbox_fetch(conn->acceptmbox, (void **)&newconn);
  conn->err = ERR_OK;
  newconn->err = ERR_OK;
  return newconn;
}
/*-----------------------------------------------------------------------------------*/
struct netbuf *
netconn_recv(struct netconn *conn)
{
  struct api_msg *msg;
  struct netbuf *buf;
    
  if(conn == NULL) {
    return NULL;
  }
  
  sys_mbox_fetch(conn->recvmbox, (void **)&buf);
  
  if(buf != NULL && buf->err != ERR_OK) {
    netbuf_delete(buf);
    return NULL;
  }
  /* Let the stack know that we have taken the data. */

  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    conn->err = ERR_MEM;
    return NULL;
  }
  msg->type = API_MSG_RECV;
  msg->msg.conn = conn;
  if(buf != NULL) {
    msg->msg.msg.len = buf->p->tot_len;
  } else {
    msg->msg.msg.len = 1;
  }
  api_msg_post(msg);
  conn->err = ERR_OK;
  return buf;
}
/*-----------------------------------------------------------------------------------*/
int
netconn_send(struct netconn *conn, struct netbuf *buf)
{
  struct api_msg *msg;

  if(conn == NULL) {
    return ERR_VAL;
  }


  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return (conn->err = ERR_MEM);
  }
  msg->type = API_MSG_SEND;
  msg->msg.conn = conn;
  msg->msg.msg.p = buf->p;
  api_msg_post(msg);

  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_write(struct netconn *conn, void *data, int size, unsigned char copy)
{
  struct api_msg *msg;
  sys_sem_t sem;

  if(conn == NULL) {
    return ERR_VAL;
  }
  
  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return (conn->err = ERR_MEM);
  }
  msg->type = API_MSG_WRITE;
  msg->msg.conn = conn;
  sem = sys_sem_new(0);
  msg->msg.msg.w.sem = sem;
  msg->msg.msg.w.data = data;
  msg->msg.msg.w.len = size;
  msg->msg.msg.w.copy = copy;
  api_msg_post(msg);
  sys_sem_wait(sem);
  sys_sem_free(sem);
  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_close(struct netconn *conn)
{
  struct api_msg *msg;

  if(conn == NULL) {
    return ERR_VAL;
  }

  
  if((msg = mem_malloc2(sizeof(struct api_msg))) == NULL) {
    return (conn->err = ERR_MEM);
  }
  msg->type = API_MSG_CLOSE;
  msg->msg.conn = conn;
  api_msg_post(msg);
  return (conn->err = ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
int
netconn_err(struct netconn *conn)
{
  return conn->err;
}
/*-----------------------------------------------------------------------------------*/




