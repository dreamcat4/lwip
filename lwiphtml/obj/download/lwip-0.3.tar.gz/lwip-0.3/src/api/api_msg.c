/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: api_msg.c,v 1.14 2001/02/23 18:32:08 adam Exp $
 */

#include "lwip/debug.h"
#include "lwip/arch.h"
#include "lwip/api_msg.h"
#include "lwip/mem.h"
#include "lwip/sys.h"
#include "lwip/tcpip.h"

/*-----------------------------------------------------------------------------------*/
static void
recv_buf(struct netconn *conn, struct pbuf *p,
	 struct ip_addr *addr, u16_t port, int err)
{
  struct netbuf *buf;
  
  if(conn == NULL) {
    pbuf_free(p);
    return;
  }
  DEBUGF(API_MSG_DEBUG, ("api_msg: recv_buf == %p err %d\n", (void *)p, err));
  if(p == NULL) {
    /* A NULL pbuf indicates that the remote end has closed
       the connection, we indicate this to the user by
       returning a NULL netbuf. */
    DEBUGF(API_MSG_DEBUG, ("api_msg: recv_buf == NULL, EOF\n"));
    buf = NULL;
  } else {
    buf = mem_malloc2(sizeof(struct netbuf));
    if(buf == NULL) {
      conn->err = ERR_MEM;
      sys_mbox_post(conn->recvmbox, buf);
      return;
    }
    buf->p = p;
    buf->ptr = p;
    buf->fromaddr = addr;
    buf->fromport = port;
    buf->err = err;
  }
  conn->err = err;
  sys_mbox_post(conn->recvmbox, buf);
}
/*-----------------------------------------------------------------------------------*/
static void
recv_tcp(void *arg, struct tcp_pcb *pcb, struct pbuf *p, int err)     
{
  recv_buf((struct netconn *)arg, p,
	   &(pcb->dest_ip), pcb->dest_port, err);
}
/*-----------------------------------------------------------------------------------*/
static void
recv_udp(void *arg, struct udp_pcb *pcb, struct pbuf *p,
	 struct ip_addr *addr, u16_t port)
{
  if(0){pcb++;} /* To avoid warning messages about unused variable "pcb". */
  recv_buf((struct netconn *)arg, p, addr, port, ERR_OK);
}
/*-----------------------------------------------------------------------------------*/
static void
accept_function(void *arg, struct tcp_pcb *newpcb, int err)
{
  sys_mbox_t *mbox;
  struct netconn *newconn;
  
#if API_MSG_DEBUG
#if TCP_DEBUG
  tcp_debug_print_state(newpcb->state);
#endif /* TCP_DEBUG */
#endif /* API_MSG_DEBUG */
  mbox = (sys_mbox_t *)arg;

  newconn = mem_malloc2(sizeof(struct netconn));
  if(newconn == NULL) {
    return;
  }
  newconn->type = NETCONN_TCP;
  newconn->pcb.tcp = newpcb;
  tcp_recv(newpcb, recv_tcp, newconn);
  newconn->recvmbox = sys_mbox_new();
  newconn->acceptmbox = SYS_MBOX_NULL;
  newpcb->recv_arg = newconn;
  newconn->err = err;
  sys_mbox_post(*mbox, newconn);  
}
/*-----------------------------------------------------------------------------------*/
static void
do_newconn(struct api_msg_msg *msg)
{
  msg->conn = mem_malloc2(sizeof(struct netconn));
  if(msg->conn == NULL) {
    sys_mbox_post(msg->msg.mbox, msg->conn);
  }
  msg->conn->type = msg->conntype;
  msg->conn->pcb.tcp = NULL;
  msg->conn->acceptmbox = SYS_MBOX_NULL;
  msg->conn->recvmbox = sys_mbox_new();

  sys_mbox_post(msg->msg.mbox, msg->conn);
}
/*-----------------------------------------------------------------------------------*/
static void
do_delconn(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      msg->conn->pcb.udp->recv_arg = NULL;
      udp_pcb_remove(msg->conn->pcb.udp);
      break;
    case NETCONN_TCP:
      msg->conn->pcb.tcp->recv_arg = NULL;
      tcp_close(msg->conn->pcb.tcp);
    break;
    }
  }
  sys_mbox_free(msg->conn->acceptmbox);
  

  sys_mbox_free(msg->conn->recvmbox);
  mem_free(msg->conn);
}
/*-----------------------------------------------------------------------------------*/
static void
do_bind(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp == NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      msg->conn->pcb.udp = udp_pcb_new();
      udp_recv(msg->conn->pcb.udp, recv_udp, msg->conn);
      break;
    case NETCONN_TCP:
      msg->conn->pcb.tcp = tcp_pcb_new();
      tcp_recv(msg->conn->pcb.tcp, recv_tcp, msg->conn);
      break;
    }
  }
  switch(msg->conn->type) {
  case NETCONN_UDPLITE:
  case NETCONN_UDPNOCHKSUM:
  case NETCONN_UDP:
    udp_bind(msg->conn->pcb.udp, msg->msg.bc.ipaddr, msg->msg.bc.port);
    break;
  case NETCONN_TCP:
    tcp_bind(msg->conn->pcb.tcp, msg->msg.bc.ipaddr, msg->msg.bc.port);
    break;
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_connected(void *arg, struct tcp_pcb *pcb, int err)
{
  sys_mbox_t *mbox;
  int *errptr;

  errptr = mem_malloc(sizeof(int));
  *errptr = err;
  mbox = arg;
  sys_mbox_post(*mbox, errptr);
}
/*-----------------------------------------------------------------------------------*/
static void
do_connect(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp == NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      msg->conn->pcb.udp = udp_pcb_new();
      udp_recv(msg->conn->pcb.udp, recv_udp, msg->conn);
      break;
    case NETCONN_TCP:
      msg->conn->pcb.tcp = tcp_pcb_new();
      tcp_recv(msg->conn->pcb.tcp, recv_tcp, msg->conn);
      break;
    }
  }
  switch(msg->conn->type) {
  case NETCONN_UDPLITE:
  case NETCONN_UDPNOCHKSUM:
  case NETCONN_UDP:
    udp_connect(msg->conn->pcb.udp, msg->msg.bc.ipaddr, msg->msg.bc.port);
    break;
  case NETCONN_TCP:
    tcp_connect(msg->conn->pcb.tcp, msg->msg.bc.ipaddr, msg->msg.bc.port,
		do_connected, &(msg->conn->connmbox));
    break;
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_listen(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      DEBUGF(API_MSG_DEBUG, ("api_msg: listen UDP: cannot listen for UDP.\n"));
      break;
    case NETCONN_TCP:
      tcp_listen(msg->conn->pcb.tcp);
      break;
    }
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_accept(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:    
      DEBUGF(API_MSG_DEBUG, ("api_msg: accept UDP: cannot accept for UDP.\n"));
      break;
    case NETCONN_TCP:
      tcp_accept(msg->conn->pcb.tcp,
                 accept_function,
                 (void *)&(msg->conn->acceptmbox));
      break;
    }
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_send(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      udp_send(msg->conn->pcb.udp, msg->msg.p);
      break;
    case NETCONN_TCP:
      break;
    }
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_recv(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    if(msg->conn->type == NETCONN_TCP) {
      tcp_recved(msg->conn->pcb.tcp, msg->msg.len);
    }
  }
}
/*-----------------------------------------------------------------------------------*/
static void
do_write(struct api_msg_msg *msg)
{
  int ret;
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      break;
    case NETCONN_TCP:
      ret = tcp_write(msg->conn->pcb.tcp, msg->msg.w.data,
                      msg->msg.w.len, msg->msg.w.copy);
      msg->conn->err = ret;
      break;
    }
  }
  sys_sem_signal(msg->msg.w.sem);
}
/*-----------------------------------------------------------------------------------*/
static void
do_close(struct api_msg_msg *msg)
{
  if(msg->conn->pcb.tcp != NULL) {
    switch(msg->conn->type) {
    case NETCONN_UDPLITE:
    case NETCONN_UDPNOCHKSUM:
    case NETCONN_UDP:
      break;
    case NETCONN_TCP:
      tcp_close(msg->conn->pcb.tcp);
      break;
    }
  }
}
/*-----------------------------------------------------------------------------------*/
typedef void (* api_msg_decode)(struct api_msg_msg *msg);
static api_msg_decode decode[API_MSG_MAX] = {
  do_newconn,
  do_delconn,
  do_bind,
  do_connect,
  do_listen,
  do_accept,
  do_send,
  do_recv,
  do_write,
  do_close
  };
void
api_msg_input(struct api_msg *msg)
{  
  decode[msg->type](&(msg->msg));
}
/*-----------------------------------------------------------------------------------*/
void
api_msg_post(struct api_msg *msg)
{
  tcpip_apimsg(msg);
}
/*-----------------------------------------------------------------------------------*/


