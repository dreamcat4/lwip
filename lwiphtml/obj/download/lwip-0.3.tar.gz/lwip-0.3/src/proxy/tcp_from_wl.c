/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_from_wl.c,v 1.9 2001/02/06 10:48:19 adam Exp $
 */
#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/mem.h"

#include "lwip/stats.h"

#include "lwip/inet.h"
#include "ip_proxy.h"
#include "tcp_proxy.h"

#include "lwip/sys.h"

static int tcp_receive(struct tcp_seg *seg, struct tcp_pcb *pcb);
static int tcp_process(struct tcp_seg *seg, struct tcp_pcb *pcb);
static void tcp_ack(struct tcp_pcb *pcb);


/*-----------------------------------------------------------------------------------*/
void
tcp_input_from_wl(struct pbuf *p)
{
  struct ip_hdr *iphdr;
  struct tcp_hdr *tcphdr;
  struct tcp_pcb *pcb, *pcbmatch;
  struct tcp_seg *seg;
  int ret;
    
#ifdef TCP_STATS
  stats.tcp.recv++;
#endif /* TCP_STATS */

  tcphdr = p->payload;
  iphdr = (struct ip_hdr *)((int)p->payload - IP_HLEN);
  
  /* verify checksum */
  if(inet_chksum_pseudo(p, (struct ip_addr *)&(iphdr->src),
                        (struct ip_addr *)&(iphdr->dest),
			IP_PROTO_TCP, p->tot_len) != 0) {
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_input: packet discarded due to failing checksum\n"));
    return;
  }

  /* p->payload = (void *)((int)p->payload + tcphdr->offset * 4);*/

  /* set up a tcp_seg structure */
  seg = mem_malloc(sizeof(struct tcp_seg));
  seg->next = NULL;
  seg->seqno = ntohl(tcphdr->seqno);
  seg->ackno = ntohl(tcphdr->ackno);
  seg->wnd = ntohs(tcphdr->wnd);
  seg->urgp = ntohs(tcphdr->urgp);
  seg->len = p->tot_len - tcphdr->offset * 4;
  /*  seg->src_port = ntohs(tcphdr->src);*/
  /*  seg->src_ip.addr = iphdr->src;*/
  /*  seg->data = (void *)((int)p->payload + tcphdr->offset * 4);*/
  seg->tcphdr = p->payload;
  seg->iphdr = (struct ip_hdr *)((char *)p->payload - IP_HLEN);
  seg->plen = p->len;
  seg->ptot_len = p->tot_len;
  seg->p = p;
  seg->flags = tcphdr->flags;

  if(tcphdr->flags & TCP_FIN || tcphdr->flags & TCP_SYN) {
    seg->len++;
  }

  pcbmatch = NULL;
  
  /* demultiplex */
  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {    
    if(pcb->wl.ip.addr == iphdr->src.addr &&
       pcb->wl.port == ntohs(tcphdr->src) &&
       pcb->net.ip.addr == iphdr->dest.addr &&
       pcb->net.port == ntohs(tcphdr->dest)) {      
      pcbmatch = pcb;
      break;
    }    
  }
  if(pcbmatch == NULL) {
    DEBUGF(TCP_PROXY_DEBUG, ("pcbmatch == NULL\n"));
  }
  
#if TCP_PROXY_DEBUG
  DEBUGF(TCP_PROXY_DEBUG, ("+-+-+-+-+-+-+-+-+-+-+-+-+-+- tcp_process: flags "));
  tcp_debug_print_flags(tcphdr->flags);
  DEBUGF(TCP_PROXY_DEBUG, ("-+-+-+-+-+-+-+-+-+-+-+-+-+-+ (from wl)\n"));
  /*  DEBUGF("tcp_input_from_wl: seqno %lu acko %lu ", seg->seqno, seg->ackno);
      tcp_debug_print_pcb(pcbmatch);*/
#endif /* TCP_PROXY_DEBUG */

  ret = 0;
  if(pcbmatch) {
#if TCP_PROXY_DEBUG
    ASSERT("tcp_input_from_wl: pcbmatch deadbeef",
	   pcbmatch->deadbeef[0] == 'p' &&
	   pcbmatch->deadbeef[1] == 'c' &&
	   pcbmatch->deadbeef[2] == 'b');
#endif /* TCP_PROXY_DEBUG */

    if(pcbmatch->wl.received == 0) {
      pcbmatch->wl.snd = seg->seqno;
      pcbmatch->wl.rcv = seg->ackno;
      pcbmatch->wl.received = 1;
#ifdef TCP_PROXY_DEBUG
      /*      DEBUGF("tcp_input_from_wl: pcb->wl.snd %lu, pcb->wl.rcv %lu\n",
	      pcbmatch->wl.snd, pcbmatch->wl.rcv);*/
#endif /* TCP_PROXY_DEBUG */
    }
    
    /*    DEBUGF("tcp_process: pcbmatch ");
    tcp_debug_print_flags(tcphdr->flags);
    DEBUGF("\n");*/
#if TCP_PROXY_DEBUG
    tcp_debug_print_state(pcbmatch->state); 
#endif /* TCP_PROXY_DEBUG */
    ret = tcp_process(seg, pcbmatch);
#if TCP_PROXY_DEBUG
    tcp_debug_print_state(pcbmatch->state); 
#endif /* TCP_PROXY_DEBUG */
    /*    ret = 0;*/
    /*    tcp_debug_print_pcb(pcbmatch);*/
  } else {
    struct tcp_pcb *pcb;
    /* create a new PCB for this connection */
    if(tcphdr->flags == TCP_SYN) {
      pcb = tcp_pcb_new();
      pcb->net.ip.addr = iphdr->dest.addr;
      pcb->net.port = ntohs(tcphdr->dest);
      pcb->wl.wnd = seg->wnd;
      pcb->net.wnd = 0;
      pcb->wl.ip.addr = iphdr->src.addr;
      pcb->wl.port = ntohs(tcphdr->src);
      pcb->state = SYN_RCVD_1;
      pcb->wl.snd = seg->seqno + 1;
      pcb->wl.iss = seg->seqno;
      pcb->wl.rcv = seg->seqno;
      pcb->net.snd = 0;
      pcb->net.rcv = 0;
      pcb->net.rcv = 0;
      ret = 0;
    }
  }

  if(ret == 0) {
    ip_output_if(seg->p, NULL, IP_HDRINCL, 0, 0, ip_route(&(iphdr->dest)));
  }

}
/*-----------------------------------------------------------------------------------*/
/* the TCP state machine */
static int
tcp_process(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  struct tcp_hdr *tcphdr;
  char fin, syn, rst, psh, ack, urg;
  int ret;

  tcphdr = seg->p->payload;  

  fin = tcphdr->flags & TCP_FIN;
  syn = tcphdr->flags & TCP_SYN;
  rst = tcphdr->flags & TCP_RST;
  psh = tcphdr->flags & TCP_PSH;
  ack = tcphdr->flags & TCP_ACK;
  urg = tcphdr->flags & TCP_URG;

  if(rst) {
    int acceptable = 0;
    if(seg->seqno >= pcb->net.rcv &&
       seg->seqno <= pcb->net.rcv + pcb->net.wnd) {
      acceptable = 1;	
    }    
    if(acceptable) {
      DEBUGF(TCP_PROXY_DEBUG, ("tcp_process: Connection RESET\n"));

      tcp_pcb_remove(pcb);
      return 0;
    }
  }

  ret = 0;
  
  switch(pcb->state) {
  case CLOSED:
    break;
  case SYN_SENT_2:
    if(ack && seg->ackno == pcb->net.snd) {
      /* ACK of SYNACK */
      tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0);
      pcb->state = ESTABLISHED;
    }
    break;
  case SYN_RCVD_1:
    if(syn && ack && seg->ackno == pcb->net.snd) {
      tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0); 
      pcb->state = SYN_RCVD_2;
      pcb->wl.snd++;
    }
    break;
  case SYN_RCVD_3:
    DEBUGF(TCP_PROXY_DEBUG, ("SYN_RCVD_3 (from wl): seqno %lu, pcb->wl.snd %lu\n",
			     seg->seqno, pcb->wl.snd));

    if(ack && seg->ackno == pcb->net.snd + 1) {
      tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0); 
      pcb->state = ESTABLISHED;
    } else if(seg->seqno == pcb->wl.snd) {
      pcb->state = ESTABLISHED;
    } else {
      break;
    }
    /* FALLTHROUGH */
  case ESTABLISHED:
    ret = tcp_receive(seg, pcb);
    if(fin) {
      pcb->state = FIN_WAIT_1;
    }
    break;
  case FIN_WAIT_3:
    DEBUGF(TCP_PROXY_DEBUG, ("FIN_WAIT_3 (from wl): ackno %lu pcb->net.snd %lu\n",
			     seg->ackno, pcb->net.snd));
    if(ack && seg->ackno == pcb->net.snd) {
      tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0); 
      tcp_time_wait_kill(pcb);
      tcp_pcb_purge(pcb);
      pcb->timer_tw = 1;
      pcb->state = TIME_WAIT;
    }
    break;
  case CLOSING_1:
    if(ack && seg->ackno == pcb->net.snd) {
      tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0); 
      pcb->state = CLOSING_2;
    }
    break;
  case CLOSE_WAIT:
    ret = tcp_receive(seg, pcb);
    if(fin) {
      pcb->state = CLOSED;
      tcp_pcb_remove(pcb);
    }
    break;
  case TIME_WAIT:
    tcp_rst(seg->ackno + 1, seg->seqno + seg->len,
	    &(pcb->net.ip), &(pcb->wl.ip),
	    pcb->net.port,
	    pcb->wl.port);
    pcb->timer_tw = 1;
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_process_from_wl: TIME-WAIT dropping\n"));

    return 1;
  default:
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_process_from_wl: should not be in %s\n",
			     tcp_states[pcb->state]));
  }
  return ret;
}
/*-----------------------------------------------------------------------------------*/
static int
tcp_receive(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  if(seg->flags & TCP_ACK) {
    tcp_receive_ack(seg, &(pcb->wl), &(pcb->net), 0); 
  }

  if(seg->len > 0) {
    if(seg->flags & TCP_SYN || seg->flags & TCP_FIN) {
      tcp_receive_seg(seg, &(pcb->wl), 0, 0);
    } else {
      tcp_receive_seg(seg, &(pcb->wl), 1, 0);
      tcp_ack(pcb);
    }
    if(pcb->net.rttest == 0 && TCP_SEQ_LT(pcb->net.rtseq, seg->seqno)) {
      DEBUGF(TCP_PROXY_DEBUG, ("pcb->net.rtseq %lu\n", seg->seqno));

      pcb->net.rtseq = seg->seqno;
      pcb->net.rttest = tcp_ticks;
      DEBUGF(TCP_PROXY_RTO_DEBUG, ("tcp_from_wl: receive: seqno %lu\n",
				   seg->seqno));
    } else if(pcb->net.rtseq == seg->seqno) {
      /* No RTT estimations on retransmissions. */
      pcb->net.rttest = 0;
    }
  } else {
    /*    if(seg->flags & TCP_ACK) {
      DEBUGF(TCP_PROXY_DEBUG, ("wl: tcp_receive not forwarding ACK\n"));
      return 1;
      }*/
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/
static void
tcp_ack(struct tcp_pcb *pcb)
{
  struct pbuf *p;

  p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
  DEBUGF(TCP_PROXY_DEBUG, ("tcp_ack_wl: ackno %lu\n", pcb->wl.snd));
  tcp_output_packet(p, &(pcb->net.ip), &(pcb->wl.ip),
                    pcb->net.port, pcb->wl.port,
                    TCP_ACK, pcb->net.snd, pcb->wl.snd,
                    pcb->net.wnd, 0);
}
/*-----------------------------------------------------------------------------------*/

