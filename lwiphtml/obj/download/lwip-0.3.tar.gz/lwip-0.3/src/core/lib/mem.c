/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: mem.c,v 1.26 2001/02/23 18:55:30 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* mem.c
 *
 * Memory manager.
 *
 */
/*-----------------------------------------------------------------------------------*/
#ifdef MEM_PERF

#include <fcntl.h>
#include <unistd.h>

static unsigned long start_time;
static int memfile = 0;
static void mem_perf_output(void);
static int mem_perf_started = 0;

#endif /* MEM_PERF */

#include "lwip/debug.h"

#include "lwip/arch.h"
#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"

#include "lwip/sys.h"

#include "lwip/stats.h"

#ifdef MEM_RECLAIM

struct mem_reclaim {
  struct mem_reclaim *next;
  mem_reclaim_func f;
  void *data;  
};
#endif /* MEM_RECLAIM */

struct mem {
  u16_t next, prev;
  u8_t used;
#if MEM_DEBUG
  char deadbeef[3];
#endif /* MEM_DEBUG */
#ifdef MEM_TRACKING
  unsigned int size;
  char *file;
  unsigned int line;
  unsigned int allocno;
#endif /* MEM_TRACKING */
};

#ifdef MEM_TRACKING
unsigned int allocno = 0;
#endif /* MEM_TRACKING */

static char ram[MEM_SIZE];
static struct mem ram_end;

static struct mem *lfree = NULL;   /* pointer to the lowest free block */

#ifdef MEM_RECLAIM
static struct mem_reclaim *mrlist = NULL;
#endif /* MEM_RECLAIM */

static sys_sem_t mem_sem;

/*-----------------------------------------------------------------------------------*/
#if MEM_DEBUG
static int
mem_sanity(void)
{
  int i;
  struct mem *mem, *prev;

  mem = (struct mem *)ram;
  prev = mem;
  i = 0;
  
  while((char *)mem < (char *)&ram_end) {
    if(mem->used) {
      ASSERT("mem_sanity: deadbeef", mem->deadbeef[0] == 'm' &&
             mem->deadbeef[1] == 'e' &&
             mem->deadbeef[2] == 'm');
    }
    if(prev != (struct mem *)&ram[mem->prev]) {
      DEBUGF(MEM_DEBUG, ("mem_sanity: prev %p, mem->prev %p (i = %d)\n",
                          prev, &ram[mem->prev], i));
      return 0;
    }
    
    prev = mem;
    mem = (struct mem *)&ram[mem->next];
    i++;
  }
  return 1;    
}
#endif /* MEM_DEBUG */
/*-----------------------------------------------------------------------------------*/
static void
plug_holes(struct mem *mem)
{
  struct mem *nmem;
  struct mem *pmem;

  ASSERT("plug_holes: mem >= ram", (char *)mem >= ram);
  ASSERT("plug_holes: mem < ram_end", (char *)mem < (char *)&ram_end);
  ASSERT("plug_holes: mem->used == 0", mem->used == 0);
  
  /* plug hole forward */
  ASSERT("plug_holes: mem->next <= MEM_SIZE", mem->next <= MEM_SIZE);
  
  nmem = (struct mem *)&ram[mem->next];
  if(mem != nmem && nmem->used == 0 && (char *)nmem != (char *)&ram_end) {
    if(lfree == nmem) {
      lfree = mem;
    }
#ifdef MEM_TRACKING
    mem->size += nmem->size;
#endif /* MEM_TRACKING */
    mem->next = nmem->next;
    ((struct mem *)&ram[nmem->next])->prev = (char *)mem - ram;
  }

  /* plug hole backward */
  pmem = (struct mem *)&ram[mem->prev];
  if(pmem != mem && pmem->used == 0) {
    if(lfree == mem) {
      lfree = pmem;
    }
#ifdef MEM_TRACKING
    pmem->size += mem->size;
#endif /* MEM_TRACKING */
    pmem->next = mem->next;
    ((struct mem *)&ram[mem->next])->prev = (char *)pmem - ram;
  }

#if MEM_DEBUG
  ASSERT("plug_holes: memory sanity", mem_sanity());
#endif /* MEM_DEBUG */
}
/*-----------------------------------------------------------------------------------*/
void
mem_init(void)
{
  struct mem *mem;

  bzero(ram, MEM_SIZE);
  mem = (struct mem *)ram;
  mem->next = MEM_SIZE;
  mem->prev = 0;
  mem->used = 0;
  ram_end.used = 1;
  ram_end.next = MEM_SIZE;
  ram_end.prev = MEM_SIZE;
#if MEM_DEBUG
  ram_end.deadbeef[0] = 'm';
  ram_end.deadbeef[1] = 'e';
  ram_end.deadbeef[2] = 'm';
#endif /* MEM_DEBUG */  

  mem_sem = sys_sem_new(1);

  lfree = (struct mem *)ram;
  
#ifdef MEM_STATS
  stats.mem.avail = MEM_SIZE;
#endif /* MEM_STATS */
}
/*-----------------------------------------------------------------------------------*/
#ifdef MEM_RECLAIM
void
mem_reclaim(unsigned int size)
{
  struct mem_reclaim *mr;
  int rec;

  rec = 0;
  
  for(mr = mrlist; mr != NULL; mr = mr->next) {
    DEBUGF(MEM_DEBUG, ("mem_malloc: calling reclaimer\n"));
    rec += mr->f(mr->data, size);
  }
#ifdef MEM_STATS
  stats.mem.reclaimed += rec;
#endif /* MEM_STATS */
}
#endif /* MEM_RECLAIM */
/*-----------------------------------------------------------------------------------*/
void *
#ifdef MEM_TRACKING
_mem_malloc2(unsigned int size, char *file, int line)
#else /* MEM_TRACKING */
mem_malloc2(unsigned int size)
#endif /* MEM_TRACKING */
{
  void *mem;
#ifdef MEM_TRACKING
  mem = _mem_malloc(size, file, line);
  if(mem == NULL) {
    mem_reclaim(size);
    mem = _mem_malloc(size, file, line);
  }  
#else /* MEM_TRACKING */
  mem = mem_malloc(size);
  if(mem == NULL) {
    mem_reclaim(size);
    mem = mem_malloc(size);
  }    
#endif /* MEM_TRACKING */
  return mem;
}
/*-----------------------------------------------------------------------------------*/
void *
#ifdef MEM_TRACKING
_mem_malloc(unsigned int size, char *file, int line)
#else /* MEM_TRACKING */
mem_malloc(unsigned int size)
#endif /* MEM_TRACKING */
{
  unsigned int ptr, ptr2;
  struct mem *mem, *mem2;

  if(size == 0) {
    return NULL;
  }

  ASSERT("mem_malloc: size < MEM_SIZE", size < MEM_SIZE);
  
  sys_sem_wait(mem_sem);

#ifdef MEM_TRACKING
  DEBUGF(MEM_DEBUG, ("mem_malloc: size %d in file %s, line %d\n", size,
		     file, line));
#else  
  DEBUGF(MEM_DEBUG, ("mem_malloc: size %d (sizeof(struct mem) %u)\n", size,
		     sizeof(struct mem)));
#if MEM_DEBUG
  mem_debug_print();
#endif /* MEM_DEBUG */
#endif /* MEM_TRACKING */

  /*  printf("mem_malloc: size %d (sizeof(struct mem) %u)\n", size,
      sizeof(struct mem));*/
  
  
  for(ptr = (char *)lfree - ram; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    if(!mem->used &&
       mem->next - (ptr + sizeof(struct mem)) >= size + sizeof(struct mem)) {
      ptr2 = ptr + sizeof(struct mem) + size;
      mem2 = (struct mem *)&ram[ptr2];

      mem2->prev = ptr;      
      mem2->next = mem->next;
      mem->next = ptr2;      
      if(mem2->next != MEM_SIZE) {
        ((struct mem *)&ram[mem2->next])->prev = ptr2;
      }
      
      mem2->used = 0;      
      mem->used = 1;
#if MEM_DEBUG      
      mem->deadbeef[0] = 'm';
      mem->deadbeef[1] = 'e';
      mem->deadbeef[2] = 'm';
      mem2->deadbeef[0] = 'm';
      mem2->deadbeef[1] = 'e';
      mem2->deadbeef[2] = 'm';
#endif /* MEM_DEBUG */
#ifdef MEM_TRACKING
      mem->size = size;
      mem->file = file;
      mem->line = line;
      mem->allocno = allocno++;
      DEBUGF(MEM_DEBUG, ("mem_malloc: %d, 0x%x (%u)\n",
			 mem->allocno, (int)mem + sizeof(struct mem), size));
#else
      DEBUGF(MEM_DEBUG, ("mem_malloc: 0x%x (%u)\n",
			 (int)mem + sizeof(struct mem), size));
#endif /* MEM_TRACKING */

#if MEM_DEBUG
      ASSERT("mem_malloc: memory sanity", mem_sanity());
#endif /* MEM_DEBUG */

#ifdef MEM_STATS
      stats.mem.used += size;
      if(stats.mem.max < stats.mem.used) {
        stats.mem.max = stats.mem.used;
      }
      ASSERT("mem_malloc: stats.mem.used >= 0", stats.mem.used >= 0);
#ifdef MEM_PERF
      mem_perf_output();
#endif /* MEM_PERF */  
#endif /* MEM_STATS */

      if(mem == lfree) {
	/* Find next free block after mem */
        while(lfree->used && lfree != &ram_end) {
	  lfree = (struct mem *)&ram[lfree->next];
        }
        ASSERT("mem_malloc: !lfree->used", !lfree->used);
      }
      sys_sem_signal(mem_sem);
      return (char *)mem + sizeof(struct mem);
    }    
  }
  DEBUGF(MEM_DEBUG, ("mem_malloc: could not allocate %d bytes\n", size));
#if MEM_DEBUG
  mem_debug_print();
#endif /* MEM_DEBUG */
#ifdef MEM_STATS
  stats.mem.err++;
#endif /* MEM_STATS */  
  sys_sem_signal(mem_sem);
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
extern struct tcp_pcb *tcp_pcbs; /* XXX */
void
#ifdef MEM_TRACKING
_mem_free(void *rmem, char *file, int line)
#else /* MEM_TRACKING */
mem_free(void *rmem)
#endif /* MEM_TRACKING */
{
  struct mem *mem;

  if(rmem == NULL) {
    return;
  }
  
  sys_sem_wait(mem_sem);

  ASSERT("mem_free: legal memory", (char *)rmem >= (char *)ram &&
	 (char *)rmem < (char *)&ram_end);
  
  
  /*  DEBUGF("mem_free: 0x%lx at %s:%d\n", (long)rmem, file, line);*/
  if((char *)rmem < (char *)ram || (char *)rmem >= (char *)&ram_end) {

    DEBUGF(MEM_DEBUG, ("mem_free: illegal memory\n"));
#if MEM_DEBUG
    mem_debug_print();
#endif /* MEM_DEBUG */
#ifdef MEM_STATS
    stats.mem.err++;
#endif /* MEM_STATS */
    return;
  }
  mem = (struct mem *)((char *)rmem - sizeof(struct mem));

  ASSERT("mem_free: mem->used", mem->used);
  
#if MEM_DEBUG
  ASSERT("mem_free: deadbeef", mem->deadbeef[0] == 'm' &&
         mem->deadbeef[1] == 'e' &&
         mem->deadbeef[2] == 'm');
  mem->deadbeef[0] = mem->deadbeef[1] = mem->deadbeef[2] = 0;
#endif /* MEM_DEBUG */
    
  mem->used = 0;

  if(mem < lfree) {
    lfree = mem;
  }
  
#ifdef MEM_TRACKING
  DEBUGF(MEM_DEBUG, ("mem_free: %d, 0x%x (%u)\n",
		     mem->allocno,
		     (int)rmem, mem->next - ((char *)mem - ram) -
		     sizeof(struct mem)));
#else
  DEBUGF(MEM_DEBUG, ("mem_free: 0x%x (%u)\n",
		     (int)rmem, mem->next - ((char *)mem - ram) -
		     sizeof(struct mem)));
#endif /* MEM_TRACKING */
  
#ifdef MEM_STATS
  stats.mem.used -= mem->next - ((char *)mem - ram) - sizeof(struct mem);
  ASSERT("mem_free: stats.mem.used >= 0", stats.mem.used >= 0);
#ifdef MEM_PERF
  mem_perf_output();
#endif /* MEM_PERF */
  
#endif /* MEM_STATS */
  plug_holes(mem);
  sys_sem_signal(mem_sem);
}
/*-----------------------------------------------------------------------------------*/
void *
#ifdef MEM_TRACKING
_mem_reallocm(void *rmem, unsigned int newsize, char *file, int line)
#else 
mem_reallocm(void *rmem, unsigned int newsize)
#endif /* MEM_TRACKING */     
{
  void *nmem;
#ifdef MEM_TRACKING
  nmem = _mem_malloc(newsize, file, line);
  if(nmem == NULL) {
    return _mem_realloc(rmem, newsize, file, line);
  }
  bcopy(rmem, nmem, newsize);
  _mem_free(rmem, file, line);
  return nmem;
#else 
  nmem = mem_malloc(newsize);
  if(nmem == NULL) {
    return mem_realloc(rmem, newsize);
  }
  bcopy(rmem, nmem, newsize);
  mem_free(rmem);
  return nmem;
#endif /* MEM_TRACKING */     
}
/*-----------------------------------------------------------------------------------*/
void *
#ifdef MEM_TRACKING
_mem_realloc(void *rmem, unsigned int newsize, char *file, int line)
#else 
mem_realloc(void *rmem, unsigned int newsize)
#endif /* MEM_TRACKING */     
{
  unsigned int size;
  unsigned int ptr, ptr2;
  struct mem *mem, *mem2;
  
  sys_sem_wait(mem_sem);
  
  ASSERT("mem_realloc: legal memory", (char *)rmem >= (char *)ram &&
	 (char *)rmem < (char *)&ram_end);
  
  if((char *)rmem < (char *)ram || (char *)rmem >= (char *)&ram_end) {
    DEBUGF(MEM_DEBUG, ("mem_free: illegal memory\n"));
    return rmem;
  }
  mem = (struct mem *)((char *)rmem - sizeof(struct mem));

#if MEM_DEBUG
  ASSERT("mem_realloc: deadbeef", mem->deadbeef[0] == 'm' &&
         mem->deadbeef[1] == 'e' &&
         mem->deadbeef[2] == 'm');
#endif /* MEM_DEBUG */
    
  
  ptr = (char *)mem - ram;

  size = mem->next - ptr - sizeof(struct mem);
#ifdef MEM_STATS
  stats.mem.used -= (size - newsize);
  ASSERT("mem_realloc: stats.mem.used >= 0", stats.mem.used >= 0);
#ifdef MEM_PERF
  mem_perf_output();
#endif /* MEM_PERF */ 
#endif /* MEM_STATS */
  
#ifdef MEM_TRACKING
  ASSERT("mem_realloc: mem->size == size", mem->size == size);
#endif /* MEM_TRACKING */
  
  if(newsize < size) {
#ifdef MEM_TRACKING
    DEBUGF(MEM_DEBUG, ("mem_realloc: (%s:%d) reallocating %p %u -> %u (%s:%d)\n",
                       file, line,
                       rmem, size, newsize, mem->file, mem->line));
    mem->size = newsize;
#endif /* MEM_TRACKING */    
    ptr2 = ptr + sizeof(struct mem) + newsize;
    mem2 = (struct mem *)&ram[ptr2];
    mem2->used = 0;
    mem2->next = mem->next;
    mem2->prev = ptr;
    mem->next = ptr2;
    if(mem2->next != MEM_SIZE) {
      ((struct mem *)&ram[mem2->next])->prev = ptr2;
    }

    plug_holes(mem2);
  }
  sys_sem_signal(mem_sem);  
  return rmem;
}
/*-----------------------------------------------------------------------------------*/
#ifdef MEM_RECLAIM
void
mem_register_reclaim(mem_reclaim_func f, void *data)
{
  struct mem_reclaim *mr;

  mr = mem_malloc(sizeof(struct mem_reclaim));
  mr->next = mrlist;
  mrlist = mr;
  mr->f = f;
  mr->data = data;
}     
#endif /* MEM_RECLAIM */
/*-----------------------------------------------------------------------------------*/
#if MEM_DEBUG
void
mem_debug_print(void)
{
  unsigned int used_mem;
  unsigned int scaling = 256;
  unsigned int memimage[MEM_SIZE/256];
  char cmemimage[MEM_SIZE/256];
  struct mem *mem;
  unsigned int ptr, i;


  /*  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    DEBUGF("%d: mem->used %d, mem->next %d, mem->prev %d\n",
	   ptr, mem->used, mem->next, mem->prev);
	   }*/
  for(i = 0; i < MEM_SIZE / scaling; i++) {
    memimage[i] = 0;
  }
  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    for(i = ptr / scaling; i < mem->next / scaling; i++) {
      memimage[i] += mem->used? 1: 0;
    }
  }
  for(i = 0; i < MEM_SIZE / scaling; i++) {
    if(memimage[i] > 5) {
      cmemimage[i] = 'X';
    } else if(memimage[i] > 0) {
      cmemimage[i] = 'x';
    } else {
      cmemimage[i] = '.';
    }
  }
  DEBUGF(MEM_DEBUG, ("%s\n", cmemimage));
	  
  used_mem = 0;
  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    if(mem->used) {
      used_mem += mem->next - ptr;
    }
  }
  
  DEBUGF(MEM_DEBUG, ("----- mem: Allocated memory %dM %dk %db\n",
		     (int)(used_mem / 1048576),
		     (int)(used_mem / 1024), used_mem % 1024));
  
}
/*-----------------------------------------------------------------------------------*/
void
mem_debug_print_more(void)
{
#ifdef MEM_TRACKING
  unsigned int ptr;
  struct mem *mem;
  
  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    if(mem->used) {
      DEBUGF(MEM_DEBUG, ("mem: size %d at %s:%d (0x%lx)\n", mem->next - ptr,
                         mem->file, mem->line, (long)((char *)mem + sizeof(struct mem))));
    }
  }
#endif /* MEM_TRACKING */
}
#endif /* MEM_DEBUG */
/*-----------------------------------------------------------------------------------*/
#ifdef LWIP_DEBUG
int 
mem_debug_print_more_buf(char *buf, int len)
{
  int slen, totlen;
  unsigned int ptr, used_mem;
  struct mem *mem;
  totlen = 0;

  used_mem = 0;
  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    if(mem->used) {
      used_mem += mem->next - ptr;
    }
  }

  slen = snprintf(buf, len, "----- mem: Allocated memory %dM %dk %db (next %p)\n",
		  (int)(used_mem / 1048576),
		  (int)(used_mem / 1024), used_mem % 1024, (char *)lfree + sizeof(struct mem));
  buf += slen;
  totlen += slen;
  len -= slen;
    
#ifdef MEM_TRACKING


  for(ptr = 0; ptr < MEM_SIZE; ptr = ((struct mem *)&ram[ptr])->next) {
    mem = (struct mem *)&ram[ptr];
    if(mem->used) {
      slen = snprintf(buf, len, "mem: %d, size %d at %s:%d (0x%lx)\n",
		      mem->allocno, mem->next - ptr - sizeof(struct mem),
		      mem->file, mem->line,
		      (long)((char *)mem + sizeof(struct mem)));
    } else {
      slen = snprintf(buf, len, "mem: x, size %d  (0x%lx)\n",
		      mem->next - ptr - sizeof(struct mem),
		      (long)((char *)mem + sizeof(struct mem)));
    }
    buf += slen;
    totlen += slen;
    len -= slen;
    
  }  
#endif /* MEM_TRACKING */
  return totlen;
}
#endif /* LWIP_DEBUG */
/*-----------------------------------------------------------------------------------*/
#ifdef MEM_PERF

static void
mem_timeout(void *data)
{
  mem_perf_output();
  sys_timeout(1000, mem_timeout, NULL);
}

void
mem_perf_init(char *fname)
{
  start_time = sys_now();
  
  memfile = open(fname, O_WRONLY | O_TRUNC | O_CREAT, 0644);
  if(memfile == -1) {
    perror("mem_perf_init: open");
  }
  mem_perf_started = 1;
  sys_timeout(1000, mem_timeout, NULL);
}

void
mem_perf_start(void)
{
  if(!mem_perf_started) {
    mem_perf_started = 1;
  }
}

static void
mem_perf_output(void)
{
  char buf[1024];
  unsigned long now;
  
  if(mem_perf_started && memfile != 0) {
    
    now = sys_now() - start_time;
    sprintf(buf, "%lu %u\n", now, stats.mem.used);
    write(memfile, buf, strlen(buf));
  }  
}
#endif /* MEM_PERF */
/*-----------------------------------------------------------------------------------*/

