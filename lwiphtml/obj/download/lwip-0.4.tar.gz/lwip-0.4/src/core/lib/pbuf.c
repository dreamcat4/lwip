/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the Swedish Institute
 *      of Computer Science and its contributors.
 * 4. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: pbuf.c,v 1.25 2001/06/20 08:46:35 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* pbuf.c
 *
 * Functions for the manipulation of pbufs. The pbufs holds all packets in the
 * system.
 *
 */
/*-----------------------------------------------------------------------------------*/
#include "lwip/debug.h"

#include "lwip/stats.h"

#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/memp.h"
#include "lwip/pbuf.h"

#define PBUF_POOL_ALLOC(p)   p = pbuf_pool; \
                             if(p) \
                                pbuf_pool = p->next;

#define PBUF_POOL_FREE(p)    p->next = pbuf_pool; \
                             pbuf_pool = p;

static char pbuf_pool_memory[PBUF_POOL_SIZE * (PBUF_POOL_BUFSIZE + sizeof(struct pbuf))];

static struct pbuf *pbuf_pool = NULL;

#if PBUF_DEBUG
static int allocs[4] = {0,0,0,0};

#include "lwip/list.h"

static struct list *allocated;

#endif /* PBUF_DEBUG */
/*-----------------------------------------------------------------------------------*/
/* pbuf_init():
 *
 * Initializes the pbuf module. A large part of memory is allocated for holding the
 * pool of pbufs. The size of the individual pbufs in the pool is given by the size
 * parameter, and the number of pbufs in the pool by the num parameter.
 *
 * After the memory has been allocated, the pbufs are set up. The ->next pointer in
 * each pbuf is set up to point to the next pbuf in the pool.
 */
/*-----------------------------------------------------------------------------------*/
void
pbuf_init()
{
  struct pbuf *p, *q;
  u8_t i;

  /* Allocate enough memory to hold pool. */
  pbuf_pool = (struct pbuf *)&pbuf_pool_memory[0];
  ASSERT("pbuf_init: pool aligned", (long)pbuf_pool % MEM_ALIGNMENT == 0);
  
  DEBUGF(PBUF_DEBUG, ("pbuf_init: pbuf_pool 0x%lx - 0x%lx\n",
		      (long)pbuf_pool,
		      (long)pbuf_pool + PBUF_POOL_SIZE * (PBUF_POOL_BUFSIZE + sizeof(struct pbuf))));
 

#ifdef PBUF_STATS
  stats.pbuf.avail = PBUF_POOL_SIZE;
#endif /* PBUF_STATS */
  
  /* Set up ->next pointers to link the pbufs of the pool together. */
  p = pbuf_pool;
  
  for(i = 0; i < PBUF_POOL_SIZE; i++) {
    p->next = (struct pbuf *)((char *)p + PBUF_POOL_BUFSIZE + sizeof(struct pbuf));
#if PBUF_DEBUG
    p->deadbeef[0] = 'p';
    p->deadbeef[1] = 'b';
    p->deadbeef[2] = 'u';
    p->deadbeef[3] = 'f';
#endif /* PBUF_DEBUG */
    q = p;
    p = p->next;
  }
  /* The ->next pointer of last pbuf is NULL to indicate that there are no more pbufs
     in the pool. */
  q->next = NULL;

#if PBUF_DEBUG
  allocated = list_new(200);
#endif /* PBUF_DEBUG */
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_alloc():
 *
 * Allocates a pbuf at protocol layer l. The actual memory allocated for the pbuf
 * is determined by the layer at which the pbuf is allocated and the requested size
 * (from the size parameter). The flag parameter decides how and where the pbuf
 * should be allocated as follows:
 * 
 * * PBUF_RAM:  buffer memory for pbuf is allocated as one large chunk. This includes
 *              protocol headers as well. 
 * * RBUF_ROM:  no buffer memory is allocated for the pbuf, even for protocol headers.
 *              Additional headers must be prepended by allocating another pbuf and
 *              chain in to the front of the ROM pbuf.
 * * PBUF_ROOL: the pbuf is allocated as a pbuf chain, with pbufs from the pbuf pool
 *              that is allocated during pbuf_init().
 */
/*-----------------------------------------------------------------------------------*/
struct pbuf *
#if PBUF_DEBUG
_pbuf_alloc(pbuf_layer l, u16_t size, pbuf_flag flag,
            char *file, int line)
#else
pbuf_alloc(pbuf_layer l, u16_t size, pbuf_flag flag)
#endif /* PBUF_DEBUG */
{
  struct pbuf *p, *q, *r;
  u16_t offset;
  s32_t rsize;

  offset = 0;
  switch(l) {
  case PBUF_TRANSPORT:
    offset += PBUF_TRANSPORT_HLEN;
    /* FALLTHROUGH */
  case PBUF_IP:
    offset += PBUF_IP_HLEN;
    offset += PBUF_LINK_HLEN;
    /* FALLTHROUGH */
  case PBUF_LINK:
    break;
  case PBUF_RAW:
    break;
  default:
    ASSERT("pbuf_alloc: bad pbuf layer", 0);
    return NULL;
  }

  switch(flag) {
  case PBUF_POOL:
    /* Allocate head of pbuf chain into p. */
    PBUF_POOL_ALLOC(p);
    if(p == NULL) {      
      return NULL;
    }
#ifdef PBUF_STATS
    stats.pbuf.used++;
    if(stats.pbuf.used > stats.pbuf.max) {
      stats.pbuf.max = stats.pbuf.used;
    }
#endif /* PBUF_STATS */
    p->next = NULL;
    
    /* Set the payload pointer so that it points offset bytes into
       pbuf data memory. */
    p->payload = (void *)((char *)p + sizeof(struct pbuf) + offset);

    /* The total length of the pbuf is the requested size. */
    p->tot_len = size;

    /* Set the length of the first pbuf is the chain. */
    p->len = size > PBUF_POOL_BUFSIZE - offset? PBUF_POOL_BUFSIZE - offset: size;
    /*    DEBUGF("pbuf_alloc: p->len %d, size %d, pbuf_pool_len %d, offset %d\n",
          p->len, size, pbuf_pool_len, offset);*/

    p->flags = PBUF_FLAG_POOL;
    
    /* Allocate the tail of the pbuf chain. */
    r = p;
    rsize = size - p->len;
    while(rsize > 0) {      
      PBUF_POOL_ALLOC(q);
      if(q == NULL) {
	DEBUGF(PBUF_DEBUG, ("pbuf: Out of pbufs in pool,\n"));
#ifdef PBUF_STATS
        stats.pbuf.err++;
#endif /* PBUF_STATS */
        p->ref = 1;
#if PBUF_DEBUG
        p->layer = l;
        allocs[l]++;
        p->file = file;
        p->line = line;
#endif /* PBUF_DEBUG */
        pbuf_free(p);
        return NULL;
      }
#if PBUF_DEBUG
      q->layer = l;
      allocs[l]++;
      q->file = file;
      q->line = line;
#endif /* PBUF_DEBUG */
#ifdef PBUF_STATS
      stats.pbuf.used++;
      if(stats.pbuf.used > stats.pbuf.max) {
        stats.pbuf.max = stats.pbuf.used;
      }
#endif /* PBUF_STATS */
      q->next = NULL;
      r->next = q;
      q->len = rsize > PBUF_POOL_BUFSIZE? PBUF_POOL_BUFSIZE: rsize;
      q->flags = PBUF_FLAG_POOL;
      q->payload = (void *)((char *)q + sizeof(struct pbuf));
      r = q;
      q->ref = 1;
      q = q->next;
      rsize -= PBUF_POOL_BUFSIZE;
    }
    r->next = NULL;

    ASSERT("pbuf_alloc: pbuf->payload properly aligned\n",
	   ((unsigned long)p->payload % MEM_ALIGNMENT) == 0);
    break;
  case PBUF_RAM:
    /* If pbuf is to be allocated in RAM, allocate memory for it. */
    p = mem_malloc(sizeof(struct pbuf) + size + offset);
    if(p == NULL) {
      return NULL;
    }
    /* Set up internal structure of the pbuf. */
    p->payload = (void *)((char *)p + sizeof(struct pbuf) + offset);
    p->len = p->tot_len = size;
    p->next = NULL;
    p->flags = PBUF_FLAG_RAM;

    ASSERT("pbuf_alloc: pbuf->payload properly aligned\n",
	   ((unsigned long)p->payload % MEM_ALIGNMENT) == 0);
    break;
  case PBUF_ROM:
    /* If the pbuf should point to ROM, we only need to allocate
       memory for the pbuf structure. */
    p = memp_malloc(MEMP_PBUF);
    if(p == NULL) {
      return NULL;
    }
    p->payload = NULL;
    p->len = p->tot_len = size;
    p->next = NULL;
    p->flags = PBUF_FLAG_ROM;
    break;
  default:
    ASSERT("pbuf_alloc: erroneous flag", 0);
    break;
  }
  p->ref = 1;
#if PBUF_DEBUG
  p->deadbeef[0] = 'p';
  p->deadbeef[1] = 'b';
  p->deadbeef[2] = 'u';
  p->deadbeef[3] = 'f';

  p->layer = l;
  allocs[l]++;
  p->file = file;
  p->line = line;
  DEBUGF(PBUF_DEBUG, ("pbuf_alloc: %p (%p) %s:%d\n", (void *)p, p->payload, file, line));

  list_push(allocated, p);
  
#endif /* PBUF_DEBUG */
  return p;
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_realloc:
 *
 * Reallocates the memory for a pbuf. If the pbuf is in ROM, this as simple as to
 * adjust the ->tot_len and ->len fields. If the pbuf is a pbuf chain, as it might be
 * with both pbufs in dynamically allocated RAM and for pbufs from the pbuf pool,
 * we have to step through the chain until we find the new endpoint in the pbuf chain.
 * Then the pbuf that is right on the endpoint is resized and any further pbufs on
 * the chain are deallocated.  
 */
/*-----------------------------------------------------------------------------------*/
void
pbuf_realloc(struct pbuf *p, u16_t size)
{
  struct pbuf *q, *r;
  u16_t rsize;

#if PBUF_DEBUG
  ASSERT("pbuf_realloc: deadbeef", p->deadbeef[0] == 'p' &&
         p->deadbeef[1] == 'b' &&
         p->deadbeef[2] == 'u' &&
         p->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */
  
  ASSERT("pbuf_realloc: sane p->flags", p->flags == PBUF_FLAG_POOL ||
         p->flags == PBUF_FLAG_ROM ||
         p->flags == PBUF_FLAG_RAM);

#if PBUF_DEBUG
  DEBUGF(PBUF_DEBUG, ("pbuf_realloc: %p (%s:%d) %u -> %u\n",
                      (void *)p, p->file, p->line, p->tot_len, size));
#endif /* PBUF_DEBUG */
  
  if(p->tot_len <= size) {
    return;
  }
  
  switch(p->flags) {
  case PBUF_FLAG_POOL:
    /* First, step over any pbufs that should still be in the chain. */
    rsize = size;
    q = p;  
    while(rsize > q->len) {
      rsize -= q->len;      
      q = q->next;
    }
    /* Adjust the length of the pbuf that will be halved. */
    q->len = rsize;

    /* And deallocate any left over pbufs. */
    r = q->next;
    q->next = NULL;
    q = r;
    while(q != NULL) {
      r = q->next;
      PBUF_POOL_FREE(q);
#ifdef PBUF_STATS
      stats.pbuf.used--;
#endif /* PBUF_STATS */
      q = r;
    }
    break;
  case PBUF_FLAG_ROM:    
    p->len = size;
    break;
  case PBUF_FLAG_RAM:
    /* First, step over the pbufs that should still be in the chain. */
    rsize = size;
    q = p;
    while(rsize > q->len) {
      rsize -= q->len;
      q = q->next;
    }
    if(q->flags == PBUF_FLAG_RAM) {
    /* Reallocate and adjust the length of the pbuf that will be halved. */
      mem_realloc(q, (char *)q->payload - (char *)q + rsize);
    }
    
    q->len = rsize;
    
    /* And deallocate any left over pbufs. */
    r = q->next;
    q->next = NULL;
    q = r;
    while(q != NULL) {
      r = q->next;
      pbuf_free(q);
      q = r;
    }
    break;
  }
  p->tot_len = size;  
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_header():
 *
 * Adjusts the ->payload pointer so that space for a header appears in the pbuf. Also,
 * the ->tot_len and ->len fields are adjusted.
 */
/*-----------------------------------------------------------------------------------*/
u8_t
pbuf_header(struct pbuf *p, s16_t header_size)
{
  void *payload;

#if PBUF_DEBUG
  ASSERT("pbuf_header: deadbeef", p->deadbeef[0] == 'p' &&
         p->deadbeef[1] == 'b' &&
         p->deadbeef[2] == 'u' &&
         p->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */
  

  payload = p->payload;
  p->payload = (char *)p->payload - header_size;
  if((char *)p->payload < (char *)p + sizeof(struct pbuf)) {
    p->payload = payload;
    return -1;
  }
  p->len += header_size;
  p->tot_len += header_size;
  return 0;
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_free():
 *
 * Decrements the reference count and deallocates the pbuf if the reference count
 * is zero. If the pbuf is a chain all pbufs in the chain are deallocated.
 */ 
/*-----------------------------------------------------------------------------------*/
void
#if PBUF_DEBUG
_pbuf_free(struct pbuf *p, char *file, int line)
#else
pbuf_free(struct pbuf *p)
#endif /* PBUF_DEBUG */
{
  struct pbuf *q;
  if(p == NULL) {
    return;
  }

#if PBUF_DEBUG
  ASSERT("pbuf_free: deadbeef", p->deadbeef[0] == 'p' &&
         p->deadbeef[1] == 'b' &&
         p->deadbeef[2] == 'u' &&
         p->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */
  
  
  ASSERT("pbuf_free: sane flags", p->flags == PBUF_FLAG_POOL ||
         p->flags == PBUF_FLAG_ROM ||
         p->flags == PBUF_FLAG_RAM);
  
  ASSERT("pbuf_free: p->ref > 0", p->ref > 0);
  
  
  /* Decrement reference count. */  
  p->ref--;

  q = NULL;
  /* If reference count == 0, actually deallocate pbuf. */
  if(p->ref == 0) {
#if PBUF_DEBUG
    DEBUGF(PBUF_DEBUG, ("pbuf_free: %p (%p) %s:%d, reference count %d, (%s:%d) flags ",
                        p, p->payload, p->file, p->line,
                        p->ref, file, line));
    pbuf_debug_print_flags(p);
    
    allocs[p->layer]--;
    ASSERT("pbuf_free: allocs[p->layer] >= 0", allocs[p->layer] >= 0);
    
    list_remove(allocated, p);
    
#endif /* PBUF_DEBUG */
    /*    DEBUGF("pbuf_free: pbuf_pool 0x%lx\n", (long)pbuf_pool);*/
    
    /* Check if this is a pbuf from the pool. */
    if(p->flags == PBUF_FLAG_POOL) {
      q = p->next;
      PBUF_POOL_FREE(p);
#ifdef PBUF_STATS
      stats.pbuf.used--;
#endif /* PBUF_STATS */
    } else if(p->flags == PBUF_FLAG_ROM) {
      q = p->next;
      memp_free(MEMP_PBUF, p);
    } else {
      /*  DEBUGF("pbuf_free: at file %s line %d\n", file, line);*/    
      q = p->next;
      mem_free(p);
    }
  } else {
#if PBUF_DEBUG
    DEBUGF(PBUF_DEBUG, ("pbuf_free: !%p (%p) %s:%d, reference count %d, (%s:%d) flags ",
                        p, p->payload, p->file, p->line,
                        p->ref, file, line));
    pbuf_debug_print_flags(p);
#endif /* PBUF_DEBUG */
  }
  pbuf_free(q);
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_ref():
 *
 * Increments the reference count of the pbuf.
 */
/*-----------------------------------------------------------------------------------*/
void
pbuf_ref(struct pbuf *p)
{
  if(p == NULL) {
    return;
  }
#if PBUF_DEBUG
  ASSERT("pbuf_ref: deadbeef", p->deadbeef[0] == 'p' &&
         p->deadbeef[1] == 'b' &&
         p->deadbeef[2] == 'u' &&
         p->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */

  p->ref++;
  /*  pbuf_ref(p->next);*/
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_chain():
 *
 * Chains the two pbufs h and t together. The ->tot_len field of the first pbuf (h)
 * is adjusted.
 */
/*-----------------------------------------------------------------------------------*/
void
pbuf_chain(struct pbuf *h, struct pbuf *t)
{
  struct pbuf *p;

#if PBUF_DEBUG
  ASSERT("pbuf_chain: head deadbeef", h->deadbeef[0] == 'p' &&
         h->deadbeef[1] == 'b' &&
         h->deadbeef[2] == 'u' &&
         h->deadbeef[3] == 'f');
  ASSERT("pbuf_chain: tail deadbeef", t->deadbeef[0] == 'p' &&
         t->deadbeef[1] == 'b' &&
         t->deadbeef[2] == 'u' &&
         t->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */
  

#if PBUF_DEBUG  
  DEBUGF(PBUF_DEBUG, ("pbuf_chain: head %p (%s:%d) tail %p (%s:%d)\n",
                      h, h->file, h->line,
                      t, t->file, t->line));
#endif /* PBUF_DEBUG */
  
  for(p = h; p->next != NULL; p = p->next);
  p->next = t;
  h->tot_len += t->tot_len;  
}
/*-----------------------------------------------------------------------------------*/
/* pbuf_dechain():
 *
 * Adjusts the ->tot_len field of the pbuf and returns the tail (if any) of the
 * pbuf chain.
 */
/*-----------------------------------------------------------------------------------*/
struct pbuf *
pbuf_dechain(struct pbuf *p)
{
  struct pbuf *q;

#if PBUF_DEBUG
  ASSERT("pbuf_dechain: deadbeef", p->deadbeef[0] == 'p' &&
         p->deadbeef[1] == 'b' &&
         p->deadbeef[2] == 'u' &&
         p->deadbeef[3] == 'f');
#endif /* PBUF_DEBUG */
  

  
  q = p->next;
  p->tot_len = p->len;
  p->next = NULL;
  return q;
}
/*-----------------------------------------------------------------------------------*/
#if PBUF_DEBUG
void
pbuf_debug_print(struct pbuf *p, int tab)
{
  int i;

  if(p == NULL) {
    return;
  }
  
  for(i = 0; i < tab; i++) {
    DEBUGF(PBUF_DEBUG, ("+ "));
  }
  DEBUGF(PBUF_DEBUG, ("pbuf 0x%x, payload 0x%x ", (int)p, (int)p->payload));
  DEBUGF(PBUF_DEBUG, ("len %d, tot_len %d, ref %d ", (int)p->len, (int)p->tot_len, p->ref));
  DEBUGF(PBUF_DEBUG, ("file %s:%d\n", p->file, p->line));
  pbuf_debug_print(p->next, 1);
}
/*-----------------------------------------------------------------------------------*/
static void
print_pbuf(void *arg)
{
  pbuf_debug_print((struct pbuf *)arg, 0);
}
/*-----------------------------------------------------------------------------------*/
void
pbuf_debug_print_stats()
{
  DEBUGF(PBUF_DEBUG, ("pbuf statistics: allocated %d LINK %d IP %d TRANSPORT %d/%d from pool.\n",
		      allocs[PBUF_LINK], allocs[PBUF_IP], allocs[PBUF_TRANSPORT],
		      stats.pbuf.used, stats.pbuf.avail));
  list_map(allocated, print_pbuf);
}
/*-----------------------------------------------------------------------------------*/
void
pbuf_debug_print_flags(struct pbuf *p)
{
}
/*-----------------------------------------------------------------------------------*/
#endif /* PBUF_DEBUG */
