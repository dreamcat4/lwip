/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the Swedish Institute
 *      of Computer Science and its contributors.
 * 4. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp.c,v 1.33 2001/06/21 12:58:11 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* tcp.c
 *
 * This file contains common functions for the TCP implementation, such as functinos
 * for manipulating the data structures and the TCP timer functions. TCP functions
 * related to input and output is found in tcp_input.c and tcp_output.c respectively.
 *
 */
/*-----------------------------------------------------------------------------------*/

#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/memp.h"

#include "lwip/tcp.h"

/* Incremented every coarse grained timer shot
   (typically every 500 ms, determined by TCP_COARSE_TIMEOUT). */
u32_t tcp_ticks;
u8_t tcp_backoff[TCP_MAXRTX + 1] =
    { 1, 2, 4, 8, 16, 32, 64, 64, 64, 64, 64, 64, 64 };

/* The TCP PCB lists. */
struct tcp_pcb *tcp_listen_pcbs;  /* List of all TCP PCBs in LISTEN state. */
struct tcp_pcb *tcp_active_pcbs;  /* List of all TCP PCBs that are in a
				 state in which they accept or send
				 data. */
struct tcp_pcb *tcp_tw_pcbs;      /* List of all TCP PCBs in TIME-WAIT. */

#define MIN(x,y) (x) < (y)? (x): (y)

/*-----------------------------------------------------------------------------------*/
/* tcp_close:
 *
 * Closes the connection held by the PCB.
 */
/*-----------------------------------------------------------------------------------*/
err_t
tcp_close(struct tcp_pcb *pcb)
{
  err_t err;

  ASSERT("tcp_close: state != CLOSED", pcb->state != CLOSED);
  
#if TCP_DEBUG
  DEBUGF(TCP_DEBUG, ("tcp_close: closing in state "));
  tcp_debug_print_state(pcb->state);
  DEBUGF(TCP_DEBUG, ("\n"));
#endif /* TCP_DEBUG */
  switch(pcb->state) {
  case LISTEN:
    err = ERR_OK;
    tcp_pcb_remove(&tcp_listen_pcbs, pcb);
    break;
  case SYN_SENT:
    err = ERR_OK;
    tcp_pcb_remove(&tcp_active_pcbs, pcb);
    break;
  case SYN_RCVD:
    err = tcp_send_ctrl(pcb, TCP_FIN);
    if(err == ERR_OK) {
      pcb->state = FIN_WAIT_1;
    }
    break;
  case ESTABLISHED:
    err = tcp_send_ctrl(pcb, TCP_FIN);
    if(err == ERR_OK) {
      pcb->state = FIN_WAIT_1;
    }
    break;
  case CLOSE_WAIT:
    err = tcp_send_ctrl(pcb, TCP_FIN);
    if(err == ERR_OK) {
      pcb->state = LAST_ACK;
    }
    break;
  default:
    /* Has already been closed, do nothing. */
    err = ERR_OK;
    break;
  }
  return err;
}
/*-----------------------------------------------------------------------------------*/
void
tcp_abort(struct tcp_pcb *pcb)
{
  u32_t seqno, ackno;
  u16_t dest_port, local_port;
  struct ip_addr dest_ip, local_ip;
  err_t (* recvf)(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err);
  void *recv_arg;

  
  /* Figure out on which TCP PCB list we are, and remove us. If we
     are in an active state, call the receive function associated with
     the PCB with a NULL argument, and send an RST to the remote end. */
  if(pcb->state == TIME_WAIT) {
    tcp_pcb_remove(&tcp_tw_pcbs, pcb);
  } else if(pcb->state == LISTEN) {
    tcp_pcb_remove(&tcp_listen_pcbs, pcb);
  } else {
    seqno = pcb->snd_nxt;
    ackno = pcb->rcv_nxt;
    ip_addr_set(&local_ip, &(pcb->local_ip));
    ip_addr_set(&dest_ip, &(pcb->dest_ip));
    local_port = pcb->local_port;
    dest_port = pcb->dest_port;
    recvf = pcb->recv;
    recv_arg = pcb->recv_arg;
    tcp_pcb_remove(&tcp_active_pcbs, pcb);
    if(recvf != NULL) {
      recvf(recv_arg, pcb, NULL, ERR_ABRT);
    }
    DEBUGF(TCP_RST_DEBUG, ("tcp_abort: sending RST\n"));
    tcp_rst(seqno, ackno, &local_ip, &dest_ip, local_port, dest_port);
  }
}
/*-----------------------------------------------------------------------------------*/
err_t
tcp_bind(struct tcp_pcb *pcb, struct ip_addr *ipaddr, u16_t port)
{
  if(ipaddr != NULL) {
    pcb->local_ip = *ipaddr;
  }
  pcb->local_port = port;
  DEBUGF(TCP_DEBUG, ("tcp_bind: bind to port %d\n", port));
  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
struct tcp_pcb *
tcp_listen(struct tcp_pcb *pcb)
{
  pcb->state = LISTEN;
  pcb = memp_realloc(MEMP_TCP_PCB, MEMP_TCP_PCB_LISTEN, pcb);
  TCP_REG(&tcp_listen_pcbs, pcb);
  return pcb;
}
/*-----------------------------------------------------------------------------------*/
void
tcp_recved(struct tcp_pcb *pcb, u16_t len)
{
  pcb->rcv_wnd += len;
  if(pcb->rcv_wnd > TCP_WND) {
    pcb->rcv_wnd = TCP_WND;
  }
  tcp_ack(pcb);
  DEBUGF(TCP_DEBUG, ("tcp_recved: recveived %d bytes, wnd %lu (%lu).\n",
		     len, pcb->rcv_wnd, TCP_WND - pcb->rcv_wnd));
}
/*-----------------------------------------------------------------------------------*/
/* tcp_new_port():
 *
 * A nastly hack featuring 'goto' statements that allocates a
 * new TCP local port.
 */
/*-----------------------------------------------------------------------------------*/
static unsigned short 
tcp_new_port(void)
{
  struct tcp_pcb *pcb;
  static u16_t port = 4096;
  
 again:
  if(++port > 0x7fff) {
    port = 4096;
  }
  
  for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->local_port == port) {
      goto again;
    }
  }
  for(pcb = tcp_tw_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->local_port == port) {
      goto again;
    }
  }
  for(pcb = tcp_listen_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->local_port == port) {
      goto again;
    }
  }
  return port;
}
/*-----------------------------------------------------------------------------------*/
err_t
tcp_connect(struct tcp_pcb *pcb, struct ip_addr *ipaddr, u16_t port,
	    err_t (* connected)(void *arg, struct tcp_pcb *pcb, err_t err),
	    void *connected_arg)
{
  char optdata[4];
  u32_t iss;
  err_t ret;

  DEBUGF(TCP_DEBUG, ("tcp_connect to port %d\n", port));
  if(ipaddr != NULL) {
    pcb->dest_ip = *ipaddr;
  } else {
    return ERR_VAL;
  }
  pcb->dest_port = port;
  pcb->local_port = tcp_new_port();
  iss = tcp_next_iss();
  pcb->rcv_nxt = 0;
  pcb->snd_nxt = iss;
  pcb->snd_ack = iss - 1;
  pcb->snd_lbb = iss - 1;
  pcb->rcv_wnd = TCP_WND;
  pcb->snd_wnd = TCP_WND;
  pcb->mss = TCP_MSS;
  pcb->cwnd = 1;
  pcb->ssthresh = pcb->mss * 10;
  pcb->state = SYN_SENT;
  pcb->connected = connected;
  pcb->connected_arg = connected_arg;
  TCP_REG(&tcp_active_pcbs, pcb);
  
  /* Build an MSS option */
  optdata[0] = 2;   /* option kind (MSS) */
  optdata[1] = 4;   /* option length */
  optdata[2] = pcb->mss / 256;
  optdata[3] = pcb->mss & 255;
  ret = tcp_enqueue(pcb, NULL, 0, TCP_SYN, 0, optdata, 4);
  tcp_output(pcb);
  return ret;
} 
/*-----------------------------------------------------------------------------------*/
/* tcp_timer_coarse:
 *
 * Called every 500 ms and implements the retransmission timer and the timer that
 * removes PCBs that have been in TIME-WAIT for enough time. It also increments
 * various timers such as the inactivity timer in each PCB.
 */
/*-----------------------------------------------------------------------------------*/
static void
tcp_timer_coarse(void *data)
{
  static struct tcp_pcb *pcb, *pcb2, *prev;
  static struct tcp_seg *seg, *useg;
  static u32_t eff_wnd;
  static u8_t pcb_remove;      /* flag if a PCB should be removed */

  tcp_ticks++;
    
  prev = NULL;
  
  /* Steps through all of the active PCBs. */
  pcb = tcp_active_pcbs;
  while(pcb != NULL) {
    ASSERT("tcp_timer_coarse: active pcb->state != CLOSED", pcb->state != CLOSED);
    ASSERT("tcp_timer_coarse: active pcb->state != LISTEN", pcb->state != LISTEN);
    ASSERT("tcp_timer_coarse: active pcb->state != TIME-WAIT", pcb->state != TIME_WAIT);

    pcb_remove = 0;

    if(pcb->nrtx >= TCP_MAXRTX) {
      pcb_remove++;
    } else {
      pcb->rtime++;
      seg = pcb->unacked;
      if(seg != NULL && pcb->rtime >= pcb->rto) {
        
        DEBUGF(TCP_RTO_DEBUG, ("tcp_timer_coarse: rtime %d pcb->rto %d\n",
                               tcp_ticks - pcb->rtime, pcb->rto));

	/* Double retransmission time-out. */
        pcb->rto = ((pcb->sa >> 3) + pcb->sv) << tcp_backoff[pcb->nrtx];

        /* Move all other unacked segments to the unsent queue. */
        if(seg->next != NULL) {
          for(useg = seg->next; useg->next != NULL; useg = useg->next);
          /* useg now points to the last segment on the unacked queue. */
          useg->next = pcb->unsent;
          pcb->unsent = seg->next;
          seg->next = NULL;
          pcb->snd_nxt = ntohl(pcb->unsent->tcphdr->seqno);
        }
        tcp_rexmit_seg(pcb, seg);

        /* Reduce congestion window and ssthresh. */
        eff_wnd = MIN(pcb->cwnd, pcb->snd_wnd);
        pcb->ssthresh = eff_wnd >> 1;
        if(pcb->ssthresh < pcb->mss) {
          pcb->ssthresh = pcb->mss * 2;
        }
        pcb->cwnd = pcb->mss;

        DEBUGF(TCP_CWND_DEBUG, ("tcp_rexmit_seg: cwnd %lu ssthresh %lu\n",
                                pcb->cwnd, pcb->ssthresh));
      }
    }
	  
    /* Check if this PCB has stayed too long in FIN-WAIT-2 */
    if(pcb->state == FIN_WAIT_2) {
      if((u32_t)(tcp_ticks - pcb->tmr) >
	 TCP_FIN_WAIT_TIMEOUT / TCP_COARSE_TIMEOUT) {
        pcb_remove++;
      }
    }

    /* Check if this PCB has stayed too long in SYN-RCVD */
    if(pcb->state == SYN_RCVD) {
      if((u32_t)(tcp_ticks - pcb->tmr) >
	 TCP_SYN_RCVD_TIMEOUT / TCP_COARSE_TIMEOUT) {
        pcb_remove++;
      }
    }


    /* If the PCB should be removed, do it. */
    if(pcb_remove) {
      tcp_pcb_purge(pcb);      
      /* Remove PCB from tcp_active_pcbs list. */
      if(prev != NULL) {
	ASSERT("tcp_timer_coarse: middle tcp != tcp_active_pcbs", pcb != tcp_active_pcbs);
        prev->next = pcb->next;
      } else {
        /* This PCB was the first. */
        ASSERT("tcp_timer_coarse: first pcb == tcp_active_pcbs", tcp_active_pcbs == pcb);
        tcp_active_pcbs = pcb->next;
      }
      pcb2 = pcb->next;
      memp_free(MEMP_TCP_PCB, pcb);
      pcb = pcb2;
    } else {
      prev = pcb;
      pcb = pcb->next;
    }
  }

    prev = NULL;
  
  /* Steps through all of the TIME-WAIT PCBs. */
  pcb = tcp_tw_pcbs;
  while(pcb != NULL) {
    ASSERT("tcp_timer_coarse: TIME-WAIT pcb->state == TIME-WAIT", pcb->state == TIME_WAIT);
    pcb_remove = 0;

    /* Check if this PCB has stayed long enough in TIME-WAIT */
    if((u32_t)(tcp_ticks - pcb->tmr) > 2 * TCP_MSL / TCP_COARSE_TIMEOUT) {
      pcb_remove++;
    }
    


    /* If the PCB should be removed, do it. */
    if(pcb_remove) {
      tcp_pcb_purge(pcb);      
      /* Remove PCB from tcp_tw_pcbs list. */
      if(prev != NULL) {
	ASSERT("tcp_timer_coarse: middle tcp != tcp_tw_pcbs", pcb != tcp_tw_pcbs);
        prev->next = pcb->next;
      } else {
        /* This PCB was the first. */
        ASSERT("tcp_timer_coarse: first pcb == tcp_tw_pcbs", tcp_tw_pcbs == pcb);
        tcp_tw_pcbs = pcb->next;
      }
      pcb2 = pcb->next;
      memp_free(MEMP_TCP_PCB, pcb);
      pcb = pcb2;
    } else {
      prev = pcb;
      pcb = pcb->next;
    }
  }
  sys_timeout(TCP_COARSE_TIMEOUT, (sys_timeout_handler)tcp_timer_coarse, NULL);
}
/*-----------------------------------------------------------------------------------*/
/* tcp_timer_fine:
 *
 * Is called every TCP_FINE_TIMEOUT (100 ms) and sends delayed ACKs.
 */
/*-----------------------------------------------------------------------------------*/
static void
tcp_timer_fine(void *data)
{
  struct tcp_pcb *pcb;

  /* send delayed ACKs */  
  for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->flags & TF_ACK_NEXT) {
      pcb->flags &= ~TF_ACK_NEXT;
      tcp_send_ctrl(pcb, TCP_ACK);
      DEBUGF(TCP_DEBUG, ("tcp_timer_fine: delayed ACK\n"));
    }
  }
  
  sys_timeout(TCP_FINE_TIMEOUT, (sys_timeout_handler)tcp_timer_fine, NULL);
}
/*-----------------------------------------------------------------------------------*/
/* tcp_segs_free:
 *
 * Deallocates a list of TCP segments (tcp_seg structures).
 *
 * It returns as approximation of the number of freed bytes.
 */
/*-----------------------------------------------------------------------------------*/
mem_size_t
tcp_segs_free(struct tcp_seg *seg)
{
  if(seg != NULL) {
    return tcp_segs_free(seg->next) + tcp_seg_free(seg);
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/
/* tcp_seg_free:
 *
 * Frees a TCP segment and returns the approximate number of memory bytes freed.
 *
 */
/*-----------------------------------------------------------------------------------*/
mem_size_t
tcp_seg_free(struct tcp_seg *seg)
{
  unsigned int size;
  if(seg != NULL) {
    if(seg->p == NULL) {
      memp_free(MEMP_TCP_SEG, seg);
      return sizeof(struct tcp_seg);
    } else {
      size = seg->p->tot_len;
      
      pbuf_free(seg->p);
      seg->p = NULL;
      memp_free(MEMP_TCP_SEG, seg);
      return size + sizeof(struct tcp_seg);
    }
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/
struct tcp_seg *
tcp_seg_copy(struct tcp_seg *seg)
{
  struct tcp_seg *cseg;

  cseg = memp_malloc(MEMP_TCP_SEG);
  bcopy(seg, cseg, sizeof(struct tcp_seg));
  pbuf_ref(cseg->p);
  return cseg;
}
/*-----------------------------------------------------------------------------------*/
struct tcp_pcb *
tcp_pcb_new(void)
{
  struct tcp_pcb *pcb;
  u32_t iss;
  
  pcb = memp_malloc2(MEMP_TCP_PCB);
  if(pcb != NULL) {
    bzero(pcb, sizeof(struct tcp_pcb));
    pcb->unsent = pcb->unacked = pcb->ooseq = NULL;
    pcb->rcv_wnd = TCP_WND;
    pcb->mss = TCP_MSS;
    pcb->rto = 3000 / TCP_COARSE_TIMEOUT;
    pcb->sa = 0;
    pcb->sv = 3000 / TCP_COARSE_TIMEOUT;
    pcb->rtime = 0;
    pcb->cwnd = 1;
    iss = tcp_next_iss();
    pcb->snd_wl2 = iss;
    pcb->snd_nxt = iss;
    pcb->snd_max = iss;
    pcb->snd_ack = iss;
    pcb->snd_lbb = iss;
    pcb->tmr = tcp_ticks;
    
    return pcb;
  }
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
/* tcp_mem_reclaim:
 *
 * Tries to free up TCP memory. This function is called from the memory manager
 * when memory is scarce.
 *
 */
/*-----------------------------------------------------------------------------------*/
#if MEM_RECLAIM
static mem_size_t
tcp_mem_reclaim(void *data, mem_size_t size)
{
  static struct tcp_pcb *pcb, *npcb, *inactive;
  static u32_t inactivity;
  static mem_size_t reclaimed;

  reclaimed = 0;
  
  /* First, kill all connections in TIME-WAIT. */
  for(pcb = tcp_tw_pcbs; pcb != NULL;) {
    TCP_RMV(&tcp_tw_pcbs, pcb);
    npcb = pcb->next;
    memp_free(MEMP_TCP_PCB, pcb);
    pcb = npcb;
    reclaimed += sizeof(struct tcp_pcb_tw);
  }

  
  /* Next, trash all out of sequence data for active connections. */  
  pcb = tcp_active_pcbs;
  while(reclaimed < size && pcb != NULL) {
    if(pcb->ooseq) {
      reclaimed += tcp_segs_free(pcb->ooseq);
      pcb->ooseq = NULL;
      DEBUGF(TCP_DEBUG, ("tcp_mem_reclaim: reclaiming memory from PCB 0x%lx\n", (long)pcb));
    }
    pcb = pcb->next;
  }

  /* If that still is not enough, abort last recently used active
     connection. If that is not enough, well, tough luck! */
  if(reclaimed < size) {
    inactivity = 0;
    inactive = NULL;
    for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
      if((u32_t)(tcp_ticks - pcb->tmr) > inactivity) {
	inactivity = tcp_ticks - pcb->tmr;
	inactive = pcb;
      }
    }
    if(inactive != NULL) {
      DEBUGF(TCP_DEBUG, ("tcp_mem_reclaim: killing oldest PCB 0x%p (%ld)\n",
			 inactive, inactivity));
      tcp_abort(inactive);
    }
  }
  DEBUGF(TCP_DEBUG, ("tcp_mem_reclaim: reclaimed %d bytes (wanted %d)\n", reclaimed, size));
  return reclaimed;
}
#endif /* MEM_RECLAIM */
/*-----------------------------------------------------------------------------------*/
/* tcp_memp_reclaim:
 *
 * Tries to free up TCP memory. This function is called from the
 * memory pool manager when memory is scarce.
 *
 */
/*-----------------------------------------------------------------------------------*/
#if MEMP_RECLAIM
static u8_t
tcp_memp_reclaim(void *data, memp_t type)
{
  struct tcp_pcb *pcb, *inactive;
  u32_t inactivity;

  switch(type) {
  case MEMP_TCP_SEG:
#if TCP_QUEUE_OOSEQ
    /* Try to find any buffered out of sequence data. */
    for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
      if(pcb->ooseq) {
	DEBUGF(TCP_DEBUG, ("tcp_memp_reclaim: reclaiming memory from PCB 0x%lx\n", (long)pcb));
	tcp_segs_free(pcb->ooseq);
	pcb->ooseq = NULL;
	return 1;
      }
    }
   
#else /* TCP_QUEUE_OOSEQ */
    return 0;
#endif /* TCP_QUEUE_OOSEQ */
    break;
    
  case MEMP_PBUF:
    return tcp_memp_reclaim(data, MEMP_TCP_SEG);

  case MEMP_TCP_PCB:
    /* We either kill off a connection in TIME-WAIT, or the oldest
       active connection. */
    pcb = tcp_tw_pcbs;
    if(pcb != NULL) {
      tcp_tw_pcbs = tcp_tw_pcbs->next;
      memp_free(MEMP_TCP_PCB, pcb);
      return 1;
    } else {
      inactivity = 0;
      inactive = NULL;
      for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
	if((u32_t)(tcp_ticks - pcb->tmr) > inactivity) {
	  inactivity = tcp_ticks - pcb->tmr;
	  inactive = pcb;
	}
      }
      if(inactive != NULL) {
	DEBUGF(TCP_DEBUG, ("tcp_mem_reclaim: killing oldest PCB 0x%p (%ld)\n",
			   inactive, inactivity));
	tcp_abort(inactive);
	return 1;
      }      
    }
    break;
    
  default:
    ASSERT("tcp_memp_reclaim: called with wrong type", 0);
    break;
  }
  return 0;
}
#endif /* MEM_RECLAIM */
/*-----------------------------------------------------------------------------------*/
/* tcp_init:
 *
 * Initializes the TCP layer.
 */
/*-----------------------------------------------------------------------------------*/
void
tcp_init(void)
{
  /* initialize timers */
  tcp_ticks = 0;
  sys_timeout(TCP_FINE_TIMEOUT, (sys_timeout_handler)tcp_timer_fine, NULL);
  sys_timeout(TCP_COARSE_TIMEOUT, (sys_timeout_handler)tcp_timer_coarse, NULL);

  /* Register memory reclaim function */
  mem_register_reclaim(tcp_mem_reclaim, NULL);

  memp_register_reclaim(MEMP_PBUF, tcp_memp_reclaim, NULL);
  memp_register_reclaim(MEMP_TCP_SEG, tcp_memp_reclaim, NULL);
  memp_register_reclaim(MEMP_TCP_PCB, tcp_memp_reclaim, NULL);
}
/*-----------------------------------------------------------------------------------*/
void
tcp_recv(struct tcp_pcb *pcb,
	 err_t (* recv)(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err),
	 void *recv_arg)
{
  pcb->recv = recv;
  pcb->recv_arg = recv_arg;
}
/*-----------------------------------------------------------------------------------*/
void
tcp_accept(struct tcp_pcb *pcb,
	   err_t (* accept)(void *arg, struct tcp_pcb *newpcb, err_t err),
	   void *accept_arg)
{
  pcb->accept = accept;
  pcb->accept_arg = accept_arg;
}
/*-----------------------------------------------------------------------------------*/
/* tcp_pcb_purge:
 *
 * Purges a TCP PCB. Removes any buffered data and frees the buffer memory.
 */
/*-----------------------------------------------------------------------------------*/
mem_size_t
tcp_pcb_purge(struct tcp_pcb *pcb)
{
  unsigned int size;
  if(pcb->state != CLOSED &&
     pcb->state != TIME_WAIT &&
     pcb->state != LISTEN) {

#if TCP_DEBUG
    if(pcb->unsent != NULL) {    
      DEBUGF(TCP_DEBUG, ("tcp_pcb_purge: not all data sent\n"));
    }
    if(pcb->unacked != NULL) {    
      DEBUGF(TCP_DEBUG, ("tcp_pcb_purge: data left on ->unacked\n"));
    }
    if(pcb->ooseq != NULL) {    
      DEBUGF(TCP_DEBUG, ("tcp_pcb_purge: data left on ->ooseq\n"));
    }
#endif /* TCP_DEBUG */
    size = tcp_segs_free(pcb->unsent) + 
      tcp_segs_free(pcb->unacked) +
      tcp_segs_free(pcb->ooseq);
    pcb->unacked = pcb->unsent = pcb->ooseq = NULL;
    return size;
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/
/* tcp_pcb_remove:
 *
 * Purges the PCB and removes it from a PCB list. Any delayed ACKs are sent first.
 */
/*-----------------------------------------------------------------------------------*/
mem_size_t
tcp_pcb_remove(struct tcp_pcb **pcblist, struct tcp_pcb *pcb)
{
  unsigned int size;

  TCP_RMV(pcblist, pcb);

  /* if there is an outstanding delayed ACKs, send it */
  if(pcb->state != TIME_WAIT &&
     pcb->state != LISTEN &&
     pcb->flags & TF_ACK_NEXT) {
    tcp_send_ctrl(pcb, TCP_ACK);
  }
  
  size = tcp_pcb_purge(pcb);
  pcb->state = CLOSED;
  memp_free(MEMP_TCP_PCB, pcb);

  ASSERT("tcp_pcb_remove: tcp_pcbs_sane()", tcp_pcbs_sane());
  return size;
}
/*-----------------------------------------------------------------------------------*/
/* tcp_next_iss:
 *
 * Calculates a new initial sequence number for new connections.
 */
/*-----------------------------------------------------------------------------------*/
u32_t
tcp_next_iss(void)
{
  static u32_t iss = 6510;
  
  iss += tcp_ticks;       /* XXX */
  return iss;
}
/*-----------------------------------------------------------------------------------*/
#if TCP_DEBUG
void
tcp_debug_print(struct tcp_hdr *tcphdr)
{
  DEBUGF(TCP_DEBUG, ("TCP header:\n"));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_DEBUG, ("|      %04x     |      %04x     | (src port, dest port)\n",
		     tcphdr->src, tcphdr->dest));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_DEBUG, ("|            %08lu           | (seq no)\n",
			    tcphdr->seqno));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_DEBUG, ("|            %08lu           | (ack no)\n",
		     tcphdr->ackno));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
#ifdef HAVE_BITFIELDS
  DEBUGF(TCP_DEBUG, ("| %2d |    |%d%d%d%d%d|    %5d      | (offset, flags (",
		     tcphdr->offset,
		     tcphdr->flags >> 4 & 1,
		     tcphdr->flags >> 3 & 1,
		     tcphdr->flags >> 2 & 1,
		     tcphdr->flags >> 1 & 1,
		     tcphdr->flags & 1,
		     tcphdr->wnd));
#else
  DEBUGF(TCP_DEBUG, ("| %2d |    |%d%d%d%d%d|    %5d      | (offset, flags (",
		     tcphdr->flags >> 4 & 1,
		     tcphdr->flags >> 4 & 1,
		     tcphdr->flags >> 3 & 1,
		     tcphdr->flags >> 2 & 1,
		     tcphdr->flags >> 1 & 1,
		     tcphdr->flags & 1,
		     tcphdr->wnd));
#endif /* HAVE_BITFIELDS */
  tcp_debug_print_flags(tcphdr->flags);
  DEBUGF(TCP_DEBUG, ("), win)\n"));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_DEBUG, ("|    0x%04x     |     %5d     | (chksum, urgp)\n",
		     ntohs(tcphdr->chksum), ntohs(tcphdr->urgp)));
  DEBUGF(TCP_DEBUG, ("+-------------------------------+\n"));
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_state(enum tcp_state s)
{
  DEBUGF(TCP_DEBUG, ("State: "));
  switch(s) {
  case CLOSED:
    DEBUGF(TCP_DEBUG, ("CLOSED\n"));
    break;
 case LISTEN:
   DEBUGF(TCP_DEBUG, ("LISTEN\n"));
   break;
  case SYN_SENT:
    DEBUGF(TCP_DEBUG, ("SYN_SENT\n"));
    break;
  case SYN_RCVD:
    DEBUGF(TCP_DEBUG, ("SYN_RCVD\n"));
    break;
  case ESTABLISHED:
    DEBUGF(TCP_DEBUG, ("ESTABLISHED\n"));
    break;
  case FIN_WAIT_1:
    DEBUGF(TCP_DEBUG, ("FIN_WAIT_1\n"));
    break;
  case FIN_WAIT_2:
    DEBUGF(TCP_DEBUG, ("FIN_WAIT_2\n"));
    break;
  case CLOSE_WAIT:
    DEBUGF(TCP_DEBUG, ("CLOSE_WAIT\n"));
    break;
  case CLOSING:
    DEBUGF(TCP_DEBUG, ("CLOSING\n"));
    break;
  case LAST_ACK:
    DEBUGF(TCP_DEBUG, ("LAST_ACK\n"));
    break;
  case TIME_WAIT:
    DEBUGF(TCP_DEBUG, ("TIME_WAIT\n"));
   break;
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_flags(u8_t flags)
{
  if(flags & TCP_FIN) {
    DEBUGF(TCP_DEBUG, ("FIN "));
  }
  if(flags & TCP_SYN) {
    DEBUGF(TCP_DEBUG, ("SYN "));
  }
  if(flags & TCP_RST) {
    DEBUGF(TCP_DEBUG, ("RST "));
  }
  if(flags & TCP_PSH) {
    DEBUGF(TCP_DEBUG, ("PSH "));
  }
  if(flags & TCP_ACK) {
    DEBUGF(TCP_DEBUG, ("ACK "));
  }
  if(flags & TCP_URG) {
    DEBUGF(TCP_DEBUG, ("URG "));
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_pcbs(void)
{
  struct tcp_pcb *pcb;
  DEBUGF(TCP_DEBUG, ("Active PCB states:\n"));
  for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
    DEBUGF(TCP_DEBUG, ("Local port %d, foreign port %d snd_nxt %lu rcv_nxt %lu ",
                       pcb->local_port, pcb->dest_port,
                       pcb->snd_nxt, pcb->rcv_nxt));
    tcp_debug_print_state(pcb->state);
  }    
  DEBUGF(TCP_DEBUG, ("Listen PCB states:\n"));
  for(pcb = tcp_listen_pcbs; pcb != NULL; pcb = pcb->next) {
    DEBUGF(TCP_DEBUG, ("Local port %d, foreign port %d snd_nxt %lu rcv_nxt %lu ",
                       pcb->local_port, pcb->dest_port,
                       pcb->snd_nxt, pcb->rcv_nxt));
    tcp_debug_print_state(pcb->state);
  }    
  DEBUGF(TCP_DEBUG, ("TIME-WAIT PCB states:\n"));
  for(pcb = tcp_tw_pcbs; pcb != NULL; pcb = pcb->next) {
    DEBUGF(TCP_DEBUG, ("Local port %d, foreign port %d snd_nxt %lu rcv_nxt %lu ",
                       pcb->local_port, pcb->dest_port,
                       pcb->snd_nxt, pcb->rcv_nxt));
    tcp_debug_print_state(pcb->state);
  }    
}
/*-----------------------------------------------------------------------------------*/
int
tcp_pcbs_sane(void)
{
  struct tcp_pcb *pcb;
  for(pcb = tcp_active_pcbs; pcb != NULL; pcb = pcb->next) {
    ASSERT("tcp_pcbs_sane: active pcb->state != CLOSED", pcb->state != CLOSED);
    ASSERT("tcp_pcbs_sane: active pcb->state != LISTEN", pcb->state != LISTEN);
    ASSERT("tcp_pcbs_sane: active pcb->state != TIME-WAIT", pcb->state != TIME_WAIT);
  }
  for(pcb = tcp_tw_pcbs; pcb != NULL; pcb = pcb->next) {
    ASSERT("tcp_pcbs_sane: tw pcb->state == TIME-WAIT", pcb->state == TIME_WAIT);
  }
  for(pcb = tcp_listen_pcbs; pcb != NULL; pcb = pcb->next) {
    ASSERT("tcp_pcbs_sane: listen pcb->state == LISTEN", pcb->state == LISTEN);
  }
  return 1;
}
#endif /* TCP_DEBUG */
/*-----------------------------------------------------------------------------------*/









