/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the Swedish Institute
 *      of Computer Science and its contributors.
 * 4. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: test_inet.c,v 1.4 2001/06/21 08:32:11 adam Exp $
 */

#include <stdio.h>
#include <unistd.h>

#include "lwip/debug.h"
#include "lwip/def.h"
#include "lwip/inet.h"
#include "lwip/mem.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"
#include "lwip/stats.h"

static void main_thread(void *arg);

#define PBUF_POOL_ALLOC 100

#define PBUF_NUM 100

/*-----------------------------------------------------------------------------------*/
int
main(int argc, char **argv)
{
  stats_init();
  sys_init();
  mem_init();
  pbuf_init();
  sys_thread_new((void *)(main_thread), NULL);
  pause();
  exit(0);
}
/*-----------------------------------------------------------------------------------*/
static void
main_thread(void *arg)
{
  struct pbuf *pool[PBUF_POOL_SIZE];
  struct pbuf *pbufs[PBUF_NUM];
  int i, sum;

  /* Allocate maximum pool pbufs at link layer. */
  for(i = 0; i < PBUF_POOL_SIZE; i++) {
    pool[i] = pbuf_alloc(PBUF_LINK, PBUF_POOL_ALLOC, PBUF_POOL);
    if(pool[i] == NULL) {
      printf("Allocation of pbuf from pool failed for i = %d\n", i);
    } else {
      printf("Successfull allocation of pbuf from pool for i = %d (%p)\n",
             i, pool[i]);
      /* Fill pbuf with zeros. */
      bzero(pool[i]->payload, PBUF_POOL_ALLOC);

      /* Test checksum */
      sum = inet_chksum_pbuf(pool[i]);
      if(sum != 0xffff) {
        printf("Checksum failed for i = %d (should be 0xffff, was 0x%4x)\n", i, sum);
      }
    }
  }  

  /* Deallocate pool pbufs. */
  for(i = 0; i < PBUF_POOL_SIZE; i++) {
    pbuf_free(pool[i]);
  }


  exit(0);
}
/*-----------------------------------------------------------------------------------*/
