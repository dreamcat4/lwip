/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the Swedish Institute
 *      of Computer Science and its contributors.
 * 4. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: test_sys.c,v 1.3 2001/06/07 19:01:31 adam Exp $
 */

#include "lwip/sys.h"
#include "lwip/def.h"

#include <stdio.h>
#define PRINT(x) printf(x)

static sys_sem_t sem, sem2;
static sys_mbox_t mbox, mbox2;

/*-----------------------------------------------------------------------------------*/
static void
thread1_timeout(void *arg)
{
  PRINT("+++ Thread 1 timeout: signalling semaphore.\n");
  sys_sem_signal(sem2);
}
/*-----------------------------------------------------------------------------------*/
static void
thread1(void *arg)     
{
  char *data;
  PRINT("Thread 1: waiting for thread 2 to start.\n");
  sys_sem_wait(sem);
  PRINT("Thread 1: thread 2 signalled semaphore.\n");
  PRINT("Thread 1: sending \"Hello thread 2\" by mail to thread 2.\n");
  sys_mbox_post(mbox, "Hello thread 2\n");
  sys_sem_wait(sem);
  PRINT("Thread 1: setting timeout.\n");
  sys_timeout(4000, thread1_timeout, NULL);
  PRINT("Thread 1: waiting for mail from thread 2.\n");
  sys_mbox_fetch(mbox2, (void **)&data);
  PRINT("Thread 1: got mail from thread 2: ");
  PRINT(data);
  
}
/*-----------------------------------------------------------------------------------*/
static void 
thread2(void *arg)
{
  char *data;
  
  PRINT("Thread 2: signalling semaphore.\n");
  sys_sem_signal(sem);
  sys_mbox_fetch(mbox, (void **)&data);
  PRINT("Thread 2: got mail from thread 1: ");
  PRINT(data);
  sys_sem_signal(sem);
  PRINT("Thread 2: waiting on semaphore\n");
  sys_sem_wait(sem2);
  PRINT("Thread 2: woke up, sending mail to thread 1\n");
  sys_mbox_post(mbox2, "Hello there thread 1!\n");
}
/*-----------------------------------------------------------------------------------*/
static void
test_sys(void)
{
  sys_sem_t dummy;
  
  sem = sys_sem_new(0);
  sem2 = sys_sem_new(0);
  mbox = sys_mbox_new();
  mbox2 = sys_mbox_new();
  sys_thread_new((void *)thread1, NULL);
  sys_thread_new((void *)thread2, NULL);

  dummy = sys_sem_new(0);
  sys_sem_wait(dummy); /* Wait forever. */
}
/*-----------------------------------------------------------------------------------*/
int
main(int arhc, char **argv)
{
  sys_thread_new((void *)test_sys, NULL);
  pause();
  return 0;
}
/*-----------------------------------------------------------------------------------*/
