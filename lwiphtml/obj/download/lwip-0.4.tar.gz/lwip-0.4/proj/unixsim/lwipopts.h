/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the Swedish Institute
 *      of Computer Science and its contributors.
 * 4. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: lwipopts.h,v 1.2 2001/06/21 12:58:02 adam Exp $
 */
#ifndef __LWIPOPTS_H__
#define __LWIPOPTS_H__

/* ---------- Statistics options ---------- */
#define STATS

#ifdef STATS
#define LINK_STATS
#define IP_STATS
#define ICMP_STATS
#define UDP_STATS
#define TCP_STATS
#define MEM_STATS
#define PBUF_STATS
#define SYS_STATS
#endif /* STATS */

/* ---------- IP options ---------- */
/* Define IP_FORWARD if you wish to have the ability to forward
   IP packets across network interfaces. If you are going to run
   lwIP on a device with only one network interface, don't define
   this. */
#define IP_FORWARD              1

/* ---------- ICMP options ---------- */
#define ICMP_TTL                255

/* ---------- UDP options ---------- */
#define UDP_TTL                 255

/* ---------- TCP options ---------- */
#define TCP_TTL                 255

#define TCP_QUEUE_OOSEQ         1

/* TCP Maximum segment size. */
#define TCP_MSS                 512

/* TCP receive window. */
#define TCP_WND                 2048

/* Maximum number of retransmissions. */
#define TCP_MAXRTX              12

/* ---------- Memory options ---------- */
#define MEM_ALIGNMENT           4

#define MEM_SIZE                1600

#define MEM_RECLAIM             1
#define MEMP_RECLAIM            1

#define MEM_POOLS               1

#define MEMP_NUM_PBUF           16
#define MEMP_NUM_UDP_PCB        2
#define MEMP_NUM_TCP_PCB        5
#define MEMP_NUM_TCP_PCB_LISTEN 4
#define MEMP_NUM_TCP_PCB_TW     0
#define MEMP_NUM_TCP_SEG        16
#define MEMP_NUM_NETBUF         3
#define MEMP_NUM_NETCONN        6
#define MEMP_NUM_API_MSG        4
#define MEMP_NUM_TCPIP_MSG      5

/* ---------- Pbuf options ---------- */

#define PBUF_POOL_SIZE          6
#define PBUF_POOL_BUFSIZE       128

#define PBUF_LINK_HLEN          16

#endif /* __LWIPOPTS_H__ */
