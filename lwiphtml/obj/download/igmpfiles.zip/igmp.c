/*
 * Copyright (c) 2002 CITEL Technologies Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of CITEL Technologies Ltd nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY CITEL TECHNOLOGIES AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL CITEL TECHNOLOGIES OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is a contribution to the lwIP TCP/IP stack.
 * The Swedish Institute of Computer Science and Adam Dunkels
 * are specifically granted permission to redistribute this
 * source code.
*/


#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/ip.h"
#include "lwip/inet.h"
#include "lwip/netif.h"
#include "lwip/icmp.h"
#include "lwip/udp.h"
#include "lwip/tcp.h"

#include "lwip/stats.h"

#include "arch/perf.h"

#include "stdio.h"

#include "lwip/igmp.h"
#include "lwip/igmpapi.h"

#include "Ethernet/mac_filter.h"

struct igmp_stats igmpstats;


struct igmp_group *GroupList;

struct ip_addr allsystems;
struct ip_addr allrouters;


/*****************************************************************

In the spirit of LW (I hope)

----------------------------------------------------------
  note 1) Although the rfc requires V1 AND V2 capability
 we will only support v2 since now V1 is 5 years old
 V1 can be added if required

a debug print and statistic have been implemented to
show this up.

----------------------------------------------------------
----------------------------------------------------------
note 2)

A query for a specific group address (as opposed to ALLHOSTS)
has now been implemented as I am unsure if it is required


a debug print and statistic have been implemented to
show this up.
----------------------------------------------------------------

------------------------------------------------------------
note 3)

The router alert rfc 2113 is implemented in outgoing packets
but not checked rigorously incoming

-------------------------------------------------------------

Steve Reynolds

*****************************************************************/


#define IGMP_DEBUG 1


void
igmp_init (void)
{
  struct igmp_group *group;
  struct netif *netif;
#if IGMP_DEBUG
  printf ("IGMP Initialising \n");
#endif

  IP4_ADDR (&allrouters, 224, 0, 0, 2);
 
  IP4_ADDR (&allsystems, 224, 0, 0, 1);

  // start the 10 millisecond tick 
  // we can optimise this to only run when timers are active later on

  sys_timeout (IGMP_TICK, (sys_timeout_handler) igmp_tick, NULL);

  for (netif = netif_list; netif != NULL; netif = netif->next)
    {
 
      group = lookup_group (netif, &allsystems);
      group->group_state = IDLE_MEMBER;
	// allow the igmp messages at the MAC level
	 igmp_control_mac(netif,&allrouters,ON);
	 igmp_control_mac(netif,&allsystems,ON);
 
   }
}

struct igmp_group *
lookup_group (struct netif *ifp, struct ip_addr *addr)
{
  struct igmp_group *group = GroupList;
  while (group)
    {
      if (group->interface == ifp
	  && ip_addr_cmp (&(group->group_address), addr))
	{

	  return group;
	}
      group = group->next;
    }
  group = mem_malloc (sizeof (struct igmp_group));

  group->interface = ifp;
  ip_addr_set (&(group->group_address), addr);
  group->timer = 0;		//not running
  group->group_state = NON_MEMBER;
  group->last_reporter_flag = 0;
  group->next = GroupList;
  GroupList = group;
#if IGMP_DEBUG
  printf ("igmp.c,Line %d  allocated a new group with address %x on if %x \n", __LINE__,
	  (int) addr, (int) ifp);
#endif
  return group;
}




void
igmp_input (struct pbuf *p, struct netif *inp, struct ip_addr *dest)
{

  struct igmpmsg *igmp = ((struct igmpmsg *) p->payload);
  struct igmp_group *group, *groupref;

#if IGMP_DEBUG
  printf ("igmp message to address %l \n", (long) dest->addr);
#endif


  // check length

  if (p->len < IGMP_MINLEN)
    {

      // nore that the length CAN be greater than 8 but only 8 are
      // used - All are included in the checksum

      pbuf_free (p);
      igmpstats.igmp_length_err++;

#if IGMP_DEBUG
      printf ("[igmp.c,Line %x igmp length error\n", __LINE__);
#endif
      return;
    }


  // now calculate and check the checksum
  if (inet_chksum (igmp, p->len))
    {
      pbuf_free (p);
      igmpstats.igmp_checksum_err++;

#if IGMP_DEBUG
      printf ("[igmp.c,Line %x igmp checksum error\n", __LINE__);
#endif
      return;
    }

  // packet is ok so find the group (or create a new one)

  group = lookup_group (inp, dest);	// use the incoming IP address!

  // Now act on the incoming message type 

  // The membership query message goes to the all groups address
  // and it control block does not have state  



  if (( IGMP_MEMB_QUERY == igmp->igmp_msgtype )
      && (ip_addr_cmp (dest, &allsystems))
      && (igmp->igmp_group_address.addr == 0))
    {
      // THIS IS THE GENERAL QUERY


#if IGMP_DEBUG
      printf ("General IGMP_MEMB_QUERY on ALL SYSTEMS ADDRESS 224.0.0.1\n");
#endif
      if (0 ==igmp->igmp_maxresp )
	{
	  igmpstats.igmp_v1_rxed++;
	  igmp->igmp_maxresp = 10;
#if IGMP_DEBUG
	  printf
	    ("[igmp.c,Line %d got an all hosts query with time== 0 - this is V1 and not implemented - treat as v2\n",
	     __LINE__);
#endif
	}
      igmpstats.igmp_group_query_rxed++;
      groupref = GroupList;
      while (groupref)
	{
	  if (groupref->interface == inp
	      && (!(ip_addr_cmp (&(groupref->group_address), &allsystems))))
	    {
	      // do not send messages on the all systems group address!
	      if ((groupref->group_state == IDLE_MEMBER) ||
		  ((groupref->group_state == DELAYING_MEMBER) &&
		   (igmp->igmp_maxresp > groupref->timer)))
		{
		  igmp_start_timer (groupref, igmp->igmp_maxresp);
		  groupref->group_state = DELAYING_MEMBER;
		}
	    }
	  groupref = groupref->next;
	}
      pbuf_free (p);
      return;
    }
  else
    if (IGMP_MEMB_QUERY == igmp->igmp_msgtype 
	&& ip_addr_cmp (dest, &allsystems)
	&& (group->group_address.addr != 0))
    {
#if IGMP_DEBUG
      printf
	("igmp.c,Line %x got a  query to a specific group using the allsystems address \n",
	 __LINE__);
#endif

      // we first need to re-lookup the group since we used dest last time

      group = lookup_group (inp, &igmp->igmp_group_address);	// use the incoming IP address!
      igmpstats.igmp_unicast_query++;

      if ((IDLE_MEMBER == group->group_state ) ||
	  ((DELAYING_MEMBER == group->group_state  ) &&
	   (igmp->igmp_maxresp > group->timer)))
	{
	  igmp_start_timer (group, igmp->igmp_maxresp);
	  group->group_state = DELAYING_MEMBER;
	}
      pbuf_free (p);
      return;
    }
  else
    if (IGMP_MEMB_QUERY == igmp->igmp_msgtype  
	&& !(ip_addr_cmp (dest, &allsystems))
	&& (group->group_address.addr != 0))
    {				/* this is the unicast query */
      igmpstats.igmp_unicast_query++;

#if IGMP_DEBUG
      printf
	("igmp.c,Line %x got a  query to a specific group with the group address as destination \n",
	 __LINE__);
#endif
      if ((IDLE_MEMBER == group->group_state  ) ||
	  ((DELAYING_MEMBER == group->group_state  ) &&
	   (igmp->igmp_maxresp > group->timer)))
	{
	  igmp_start_timer (group, igmp->igmp_maxresp);
	  group->group_state = DELAYING_MEMBER;
	}
      pbuf_free (p);
      return;
    }
  else if (IGMP_V2_MEMB_REPORT == igmp->igmp_msgtype )
    {
#if IGMP_DEBUG
      printf
	("igmp.c,Line %x got an IGMP_V2_MEMB_REPORT \n",
	 __LINE__);
#endif
      igmpstats.report_rxed++;
      if (DELAYING_MEMBER == group->group_state )
	{
	  // this is on a specific group we have already looked up
	  group->timer = 0;	//stopped
	  group->group_state = IDLE_MEMBER;
	  group->last_reporter_flag = 0;
	  pbuf_free (p);
	  return;
	}
    } else {
#if IGMP_DEBUG
  printf
    ("igmp_input, Line %x unexpected msg %x in state %x on group %x  at interface %x\n",
     __LINE__, (int) igmp->igmp_msgtype, (int) group->group_state,
     (int) &group, (int) group->interface);

#endif
  pbuf_free (p);
    }
}


void
igmp_joingroup (struct netif *ifp, struct ip_addr *groupaddr)
{
  struct igmp_group *group;
  group = lookup_group (ifp, groupaddr);
  // this should creatre a new group
  // check the state to make sure

  if (group->group_state != NON_MEMBER)
    {
#if IGMP_DEBUG
      printf ("igmp.c Line %x join to group not in state NON_MEMBER\n",
	      __LINE__);
#endif
      return;
    }

  // OK - it was new group
  igmpstats.igmp_joins++;
#if IGMP_DEBUG
  printf ("igmp.c Line %x join to new group\n", __LINE__);
#endif

  send_igmp (group, IGMP_V2_MEMB_REPORT);
  igmp_start_timer (group, 10);
  // need to work out where this timer comes from
  group->group_state = DELAYING_MEMBER;

  igmp_control_mac(ifp,groupaddr,ON);

}


void
igmp_leavegroup (struct netif *ifp, struct ip_addr *groupaddr)
{
  struct igmp_group *group;
  group = lookup_group (ifp, groupaddr);
  // onl; send a leave if the flag is set according to the state diagram

  if (group->last_reporter_flag)
    {
#if IGMP_DEBUG
      printf ("igmp.c Line %x Leaving group\n", __LINE__);
#endif
      igmpstats.igmp_leave_sent++;
      send_igmp (group, IGMP_LEAVE_GROUP);
 
    }
  // the block is not deleted since the group still exists and we may rejoin

      group->last_reporter_flag = 0;
      group->group_state = NON_MEMBER;
      group->timer = 0;
	  igmp_control_mac(ifp,groupaddr,OFF);
}

void
igmp_tick ()
{
  struct igmp_group *group = GroupList;

//	printf ("tick\n");

  while (group)
    {
      if (group->timer != 0)
	{
	  group->timer -=1;
	  if (group->timer == 0)
	    igmp_timeout (group);
	}
      group = group->next;
    }

  // 100 millisecond tick handler

  // go down the list of all groups here and check for timeoouts

  // next tick

  sys_timeout (IGMP_TICK, (sys_timeout_handler) igmp_tick, NULL);

}


void
igmp_timeout (struct igmp_group *group)
{
  // if the state is DELAYING_MEMBER then we send a report for
  // this group

#if IGMP_DEBUG
  printf ("got a timeout\n");
#endif

  if (DELAYING_MEMBER == group->group_state)
    {
      send_igmp (group, IGMP_V2_MEMB_REPORT);

    }
}


void
igmp_start_timer (struct igmp_group *group, u8_t max_time)
{
  group->timer = max_time;

  // important !! this should be random 0 -> max_time
  // find out how to do this
}



void
igmp_stop_timer (struct igmp_group *group)
{
  group->timer = 0;
}



/*-----------------------------------------------------------------------------------*/
/* igmp_ip_output_if:
 *
 * Sends an IP packet on a network interface. This function constructs the IP header
 * and calculates the IP header checksum. If the source IP address is NULL,
 * the IP address of the outgoing network interface is filled in as source address.
 */
/*-----------------------------------------------------------------------------------*/
err_t
igmp_ip_output_if (struct pbuf *p, struct ip_addr *src, struct ip_addr *dest,
		   u8_t ttl, u8_t proto, struct netif *netif)
{
  static struct ip_hdr *iphdr;
  static u16_t ip_id = 0;
  u16_t *ra;


  PERF_START;

  // first write in the router alert

  if (pbuf_header (p, ROUTER_ALERTLEN))
    {

      DEBUGF (IGMP_DEBUG,
	      ("ip_output: not enough room for IP header in pbuf\n"));

    }

  ra = p->payload;
  // this is the router alert option

  ra[0] = htons (0x9404);
  ra[1] = 0x0000;


  // now the normal ip header
  if (pbuf_header (p, IP_HLEN))
    {

      DEBUGF (IGMP_DEBUG,
	      ("ip_output: not enough room for IP header in pbuf\n"));

#ifdef IP_STATS
      stats.ip.err++;
#endif /* IP_STATS */
      pbuf_free (p);
      return ERR_BUF;
    }

  iphdr = p->payload;


  if (dest != IP_HDRINCL)
    {
      iphdr->ttl = ttl;
      iphdr->proto = proto;

      /*  iphdr->dest = dest->addr; */
      ip_addr_set (&(iphdr->dest), dest);
#ifdef HAVE_BITFIELDS
    iphdr->hl = (IP_HLEN+ ROUTER_ALERTLEN)/4;
    iphdr->v = 4;
#else
    iphdr->v_hl = (4 << 4) | ((IP_HLEN + ROUTER_ALERTLEN)/ 4 & 0xf);
#endif /* HAVE_BITFIELDS */
 //     iphdr->v_hl = (4 << 4) | ((IP_HLEN + ROUTER_ALERTLEN) / 4 & 0xf);

      iphdr->tos = 0;
      iphdr->len = htons (p->tot_len);
      iphdr->offset = htons (0);
      iphdr->id = htons (ip_id++);

      if (ip_addr_isany (src))
	{
	  ip_addr_set (&(iphdr->src), &(netif->ip_addr));
	}
      else
	{
	  ip_addr_set (&(iphdr->src), src);
	}

      iphdr->chksum = 0;
      iphdr->chksum = inet_chksum (iphdr, IP_HLEN + ROUTER_ALERTLEN);
    }
  else
    {
      dest = &(iphdr->dest);
    }

#ifdef IP_STATS
  stats.ip.xmit++;
#endif /* IP_STATS */
  DEBUGF (IGMP_DEBUG,
	  ("ip_output_if: %c%c ", netif->name[0], netif->name[1]));
#if IGMP_DEBUG
#if IP_DEBUG
  ip_debug_print (p);
#endif
#endif /* IGMP_DEBUG */

  PERF_STOP ("ip_output_if");

#if IGMP_DEBUG
  printf ("IGMP sending to netif %x \n", (int) netif);
#endif
  return netif->output (netif, p, dest);
}


void
send_igmp (struct igmp_group *group, u8_t type)
{
  struct pbuf *p;
  struct igmpmsg *igmp;
  struct ip_addr src;
  struct ip_addr *dest;

  p = pbuf_alloc (PBUF_TRANSPORT, IGMP_MINLEN, PBUF_RAM);
  /* ICMP header + IP header + 8 bytes of data */

  igmp = p->payload;

  ip_addr_set (&src, &((group->interface)->ip_addr));
  if (IGMP_V2_MEMB_REPORT ==type )
    {
      dest = &(group->group_address);
      igmpstats.report_sent++;
      ip_addr_set (&(igmp->igmp_group_address), &(group->group_address));
      group->last_reporter_flag = 1;	// remember we were the 
      //last to report
    }
  else if (IGMP_LEAVE_GROUP == type )
    {
      dest = &allrouters;
      ip_addr_set (&(igmp->igmp_group_address), &(group->group_address));
    }
  else
    {
      return;
    }

  igmp->igmp_msgtype = type;

  igmp->igmp_maxresp = 0;
  igmp->igmp_checksum = 0;
  igmp->igmp_checksum = inet_chksum (igmp, IGMP_MINLEN);
  igmp_ip_output_if (p, &src, dest, TTL_1, IP_PROTO_IGMP, group->interface);
}


// ip and hence igmp knows about multiple interfaces but we only
//have one and there is no ifp used by the mac drivers for filtering.


void igmp_control_mac(struct netif *ifp,struct ip_addr *ip,ONOFF onoff)
{
	unsigned char mcastaddr[6];
	
	// this mapping is from the ietf IN RFC 1700
	mcastaddr[0] = 0x01;
    mcastaddr[1] = 0x00;
    mcastaddr[2] = 0x5e;
    mcastaddr[3] = ip4_addr2(ip) & 0x7f;
    mcastaddr[4] = ip4_addr3(ip);
    mcastaddr[5] = ip4_addr4(ip);

	if (ON == onoff)
	{
		if (0 == add_mcast_mac (mcastaddr)) 
		{
			printf ("failed to allow a mcast mac address\n");
		}
	}
	else
	{
		if (0 == delete_mcast_mac (mcastaddr)) 
		{
			printf ("failed to allow a mcast mac address\n");
		}
	} 
}

