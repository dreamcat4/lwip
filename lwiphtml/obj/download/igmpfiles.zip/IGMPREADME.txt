This implementation of IGMP was written for lwip by Steve Reynolds of Citel Technologies
(steve.reynolds@citel.com)

It has been donated 'as is' to the lwip community in thanks to Adam and all others who have
contributed to the stack.

This is an IGMP client - it is limited to v2 functionality and it will not act as a router.


The integration of the IGMP protocol into the IP stack requires the following:-


Mods to the ip_input function to call the igmp_input routine and handle the router 
alert option.


Mods to the ip_output function to send the router alert option


You may also find you need small changes elsewhere in lwip to allow you to 
receive multicasts.



An example ip.c file is included with igmp - it is an old version do not overwrite
yours but use it as an example.



Since igmp uses multicasts, you may be able to configure mac address filtering for your
lan device - there are calls to such a function in this code.


The code was written for multiple network interfaces but we only run it with one so
test carefully if you use it with multiple interfaces.

I have tested this with a Cisco router and it seems OK.

