/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_from_net.c,v 1.9 2001/02/06 10:48:19 adam Exp $
 */
#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/mem.h"

#include "lwip/stats.h"

#include "lwip/inet.h"
#include "ip_proxy.h"
#include "tcp_proxy.h"

#include "lwip/sys.h"



static int tcp_receive_from_net(struct tcp_seg *seg, struct tcp_pcb *pcb);
static int tcp_process_from_net(struct tcp_seg *seg, struct tcp_pcb *pcb);
static void tcp_ack(struct tcp_pcb *pcb);

/*-----------------------------------------------------------------------------------*/
void
tcp_input_from_net(struct pbuf *p)
{
  struct tcp_hdr *tcphdr;
  struct tcp_pcb *pcb, *pcbmatch;
  struct tcp_seg *seg;
  /*  void *ip_header;*/
  struct ip_hdr *iphdr;
  int ret;

#ifdef TCP_STATS
  stats.tcp.recv++;
#endif /* TCP_STATS */ 

  tcphdr = p->payload;
  iphdr = (struct ip_hdr *)((int)p->payload - IP_HLEN);

  /* verify checksum */
  if(inet_chksum_pseudo(p, (struct ip_addr *)&(iphdr->src), (struct ip_addr *)&(iphdr->dest),
			IP_PROTO_TCP, p->tot_len) != 0) {
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_input: packet discarded due to failing checksum\n"));
    return;
  }

  /*  p->payload = (void *)((int)p->payload + tcphdr->offset * 4);*/
  
  /* set up a tcp_seg structure */
  seg = mem_malloc(sizeof(struct tcp_seg));
  seg->next = NULL;
  seg->seqno = ntohl(tcphdr->seqno);
  seg->ackno = ntohl(tcphdr->ackno);
  seg->wnd = ntohs(tcphdr->wnd);
  seg->urgp = ntohs(tcphdr->urgp);
  seg->len = p->tot_len - tcphdr->offset * 4;
  /*  seg->src_port = ntohs(tcphdr->src);
      seg->src_ip.addr = iphdr->src;*/
  /*  seg->data = (void *)((int)p->payload + tcphdr->offset * 4);*/
  seg->tcphdr = p->payload;
  seg->iphdr = (struct ip_hdr *)((char *)p->payload - IP_HLEN);
  seg->plen = p->len;
  seg->ptot_len = p->tot_len;
  seg->p = p;
  seg->flags = tcphdr->flags;

  if(tcphdr->flags & TCP_FIN || tcphdr->flags & TCP_SYN) {
    seg->len++;
  }

  pcbmatch = NULL;
  
  /* demultiplex */
  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->net.ip.addr == iphdr->src.addr &&
       pcb->net.port == ntohs(tcphdr->src) &&
       pcb->wl.ip.addr == iphdr->dest.addr &&
       pcb->wl.port == ntohs(tcphdr->dest)) {
      pcbmatch = pcb;
      break;
    }       
  }

  if(pcbmatch == NULL) {
    DEBUGF(TCP_PROXY_DEBUG, ("pcbmatch == NULL\n"));
  }

#if TCP_PROXY_DEBUG
  DEBUGF(1, ("+-+-+-+-+-+-+-+-+-+-+-+-+-+- tcp_input: flags "));
  tcp_debug_print_flags(tcphdr->flags);
  DEBUGF(1, ("-+-+-+-+-+-+-+-+-+-+-+-+-+-+ (from net)\n"));

  /*  DEBUGF("tcp_input_from_net: seqno %lu acko %lu ", seg->seqno, seg->ackno);
      tcp_debug_print_pcb(pcbmatch);*/
#endif /* TCP_PROXY_DEBUG */

  ret = 0;
  
  if(pcbmatch) {
    if(pcbmatch->net.received == 0) {
      pcbmatch->net.snd = seg->seqno;
      pcbmatch->net.rcv = seg->ackno;
      pcbmatch->net.received = 1;
#ifdef TCP_PROXY_DEBUG
      /*      DEBUGF("tcp_input_from_net: pcb->net.snd %lu, pcb->net.rcv %lu\n",
	      pcbmatch->net.snd, pcbmatch->net.rcv);*/
#endif /* TCP_PROXY_DEBUG */
    }
    /*    DEBUGF("tcp_input: pcbmatch ");
    tcp_debug_print_flags(tcphdr->flags);
    DEBUGF("\n");*/
#if TCP_PROXY_DEBUG
    tcp_debug_print_state(pcbmatch->state); 
#endif /* TCP_PROXY_DEBUG */
    ret = tcp_process_from_net(seg, pcbmatch);
#if TCP_PROXY_DEBUG
    tcp_debug_print_state(pcbmatch->state); 
#endif /* TCP_PROXY_DEBUG */
    /*    ret = 0;*/
    /*    tcp_debug_print_pcb(pcbmatch);*/
  } else {
    struct tcp_pcb *pcb;
    /* create a new PCB for this connection */
    if(tcphdr->flags == TCP_SYN) {
      pcb = tcp_pcb_new();
      pcb->wl.ip.addr = iphdr->dest.addr;
      pcb->wl.port = ntohs(tcphdr->dest);
      pcb->net.ip.addr = iphdr->src.addr;
      pcb->net.port = ntohs(tcphdr->src);
      pcb->state = SYN_RCVD_1;
      pcb->wl.wnd = 0;
      pcb->net.wnd = seg->wnd;
      pcb->wl.snd = 0;
      pcb->wl.iss = 0;
      pcb->wl.rcv = 0;
      pcb->net.snd = seg->seqno + 1;
      pcb->net.iss = seg->seqno;
      pcb->net.rcv = seg->seqno;
      pcb->wl.received = 0;
      pcb->net.received = 1;
      ret = 0;
    }
  }
  if(ret == 0) {
    ip_output_if(seg->p, NULL, IP_HDRINCL, 0, 0, ip_route(&(iphdr->dest)));
  }  
}
/*-----------------------------------------------------------------------------------*/
static int
tcp_process_from_net(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  struct tcp_hdr *tcphdr;
  char fin, syn, rst, psh, ack, urg;  
  int ret;
  
  tcphdr = seg->p->payload;
  
  /*  tcp_debug_print_state(pcb->state);*/
  fin = tcphdr->flags & TCP_FIN;
  syn = tcphdr->flags & TCP_SYN;
  rst = tcphdr->flags & TCP_RST;
  psh = tcphdr->flags & TCP_PSH;
  ack = tcphdr->flags & TCP_ACK;
  urg = tcphdr->flags & TCP_URG;

  if(rst) {
    int acceptable = 0;
    if(seg->seqno >= pcb->wl.rcv &&
       seg->seqno <= pcb->wl.rcv + pcb->wl.wnd) {
      acceptable = 1;
    }
    if(acceptable) {
      DEBUGF(TCP_PROXY_DEBUG, ("tcp_process_from_net: Connection RESET\n"));

      /* Do not send any delayed ACK. */
      /*      pcb->flags &= ~TCP_ACK_NEXT;*/
      tcp_pcb_remove(pcb);
      return 0;
    }
  }
  ret = 0;
  
  switch(pcb->state) {
  case CLOSED:
    break;
  case SYN_SENT_1:
    if(syn && ack && seg->ackno == pcb->wl.snd) {
      tcp_receive_ack(seg, &(pcb->net), &(pcb->wl), 1); 
      pcb->state = SYN_SENT_2;
      pcb->net.snd++;  
    }
    break;
  case SYN_RCVD_2:
    if(ack && seg->ackno == pcb->wl.snd) {
      tcp_receive_ack(seg, &(pcb->net), &(pcb->wl), 1); 
      pcb->state = SYN_RCVD_3;
    }
    break;
  case SYN_RCVD_3:
  case ESTABLISHED:
    ret = tcp_receive_from_net(seg, pcb);
    if(fin) {
      pcb->state = CLOSE_WAIT;
    }
    break;
  case FIN_WAIT_1:
    ret = tcp_receive_from_net(seg, pcb);
    if(fin && ack) {
      pcb->state = FIN_WAIT_3;
    } else if(fin) {
      pcb->state = CLOSING_1;
    } else if(ack) {
      pcb->state = FIN_WAIT_2;
    }
    break;
  case FIN_WAIT_2:
    ret = tcp_receive_from_net(seg, pcb);
    if(fin) {
      pcb->state = FIN_WAIT_3;
    }
    break;
  case CLOSING_2:
    /*    ret = tcp_receive_from_net(seg, pcb);    */
    if(ack && seg->ackno == pcb->wl.snd) {
      tcp_receive_ack(seg, &(pcb->net), &(pcb->wl), 1); 
      pcb->state = TIME_WAIT;
      tcp_time_wait_kill(pcb);
      tcp_pcb_purge(pcb);
      pcb->timer_tw = 1;
    }
    break;
  case TIME_WAIT:
    /*    tcp_rst(pcb->net.snd, pcb->wl.snd,
	    &(pcb->wl.ip), &(pcb->net.ip),
	    pcb->wl.port,
	    pcb->net.port);*/
    tcp_ack(pcb);
    pcb->timer_tw = 1;
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_process_from_net: TIME-WAIT dropping\n"));
    return 1;    
  default:
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_process_from_net: should not be in %s\n",
			     tcp_states[pcb->state]));
  }
  return ret;
}
/*-----------------------------------------------------------------------------------*/
static int
tcp_receive_from_net(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  if(seg->flags & TCP_ACK) {
    tcp_receive_ack(seg, &(pcb->net), &(pcb->wl), 1); 
  }
  
  if(seg->len > 0) {
    if(seg->flags & TCP_SYN || seg->flags & TCP_FIN) {
      tcp_receive_seg(seg, &(pcb->net), 0, 1);
    } else {
      tcp_receive_seg(seg, &(pcb->net), 0, 1);
    }
    /*    if(pcb->wl.rttest == 0) {
      DEBUGF(TCP_PROXY_DEBUG, ("pcb->wl.rtseq %lu\n", seg->seqno));

      pcb->wl.rtseq = seg->seqno;
      pcb->wl.rttest = tcp_ticks;
      }*/
    /*    tcp_ack_net(pcb); */
    return 0;
  } else {
    if(pcb->state == ESTABLISHED && seg->flags & TCP_ACK) {
      DEBUGF(TCP_PROXY_DEBUG, ("wl: tcp_receive not forwarding ACK\n"));
      return 1;
    }

    return 0;
    return 1;
  }
}
/*-----------------------------------------------------------------------------------*/
static void
tcp_ack(struct tcp_pcb *pcb)
{
  struct pbuf *p;
  p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
  DEBUGF(TCP_PROXY_DEBUG, ("tcp_ack_net: ackno %lu\n", pcb->net.snd));
  tcp_output_packet(p, &(pcb->wl.ip), &(pcb->net.ip),
		    pcb->wl.port, pcb->net.port,
		    TCP_ACK, pcb->wl.snd, pcb->net.snd,
		    pcb->wl.wnd, 0);
}
/*-----------------------------------------------------------------------------------*/
