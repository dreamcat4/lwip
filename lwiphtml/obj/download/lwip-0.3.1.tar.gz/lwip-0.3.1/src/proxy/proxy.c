/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: proxy.c,v 1.8 2001/02/26 17:56:43 adam Exp $
 */

#include "lwip/debug.h"

#include <stdlib.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>




#include "lwip/pbuf.h"
#include "ip_proxy.h"
#include "tcp_proxy.h"

#include "lwip/mem.h"
#include "lwip/sys.h"

#include "lwip/netif.h"
#include "netif/delif.h"
#include "netif/tunif.h"
#include "netif/tapif.h"
#include "netif/unixif.h"

static void
pbuf_timeout(void *data)
{
#ifdef PROXY_DEBUG
  pbuf_debug_print_stats();
#endif /* PROXY_DEBUG */
  /*  mem_debug_print();*/
  sys_timeout(5000, pbuf_timeout, NULL);
}

static void
tcp_timeout(void *data)
{
#ifdef TCP_PROXY_DEBUG
  tcp_debug_print_pcbs_state();
#endif /* TCP_PROXY_DEBUG */
  sys_timeout(5000, tcp_timeout, NULL);
}

static void *
proxy_thread(void *arg)
{
  struct netif *netif;
  struct ip_addr ipaddr, netmask, gw;


  IP4_ADDR(&ipaddr, 192,168,0,2);
  IP4_ADDR(&gw, 192,168,0,1);
  IP4_ADDR(&netmask, 255,255,255,0);
  
#ifdef USE_DELAY_INTERFACE  
  netif = netif_add(&ipaddr, &netmask, &gw, delif_init, ip_input);
  netif->flags = NETIF_WIRED;
  netif_set_default(netif);
#else /* USE_DELAY_INTERFACE */
#ifdef linux
  netif = netif_add(&ipaddr, &netmask, &gw, tapif_init, ip_input);
  netif->flags = NETIF_WIRED;
  netif_set_default(netif);
  /*  netif = netif_add(&ipaddr, &netmask, &gw, tunif_init, ip_input);
  netif->flags = NETIF_WIRED;
  netif_set_default(netif);*/
#else /* linux */
  netif = netif_add(&ipaddr, &netmask, &gw, tunif_init, ip_input);
  netif->flags = NETIF_WIRED;
  netif_set_default(netif);
#endif /* linux */
#endif /* USE_DELAY_INTERFACE */


  IP4_ADDR(&ipaddr, 192,168,1,1);
  IP4_ADDR(&gw, 0,0,0,0);
  IP4_ADDR(&netmask, 255,255,255,0);
  netif = netif_add(&ipaddr, &netmask, &gw, unixif_accept, ip_input);
  netif->flags = NETIF_WIRELESS;


  ip_init();
  tcp_init();
  
   
  sys_timeout(5000, pbuf_timeout, NULL);
  /*  sys_timeout(1000, udp_send, init_udp_sender());*/

  sys_timeout(5000, tcp_timeout, NULL);

  sys_main();

  return NULL;
}

int
main(int argc, char **argv)
{
  mem_init();
  stats_init();
  pbuf_init(8192, 256);
  sys_init();

  sys_thread_new((void *)&proxy_thread, NULL);
  printf("Proxy started.\n");

  pause();
  return 0;
}
	
  
