/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp.h,v 1.14 2001/03/01 12:24:21 adam Exp $
 */
#ifndef __LWIP_TCP_H__
#define __LWIP_TCP_H__

#include "lwip/sys.h"

#include "lwip/pbuf.h"
#include "lwip/opt.h"
#include "lwip/ip.h"
#include "lwip/icmp.h"

#include "lwip/sys.h"

#include "lwip/err.h"

#define TCP_SEQ_LT(a,b)     ((s32_t)((a)-(b)) < 0)
#define TCP_SEQ_LEQ(a,b)    ((s32_t)((a)-(b)) <= 0)
#define TCP_SEQ_GT(a,b)     ((s32_t)((a)-(b)) > 0)
#define TCP_SEQ_GEQ(a,b)    ((s32_t)((a)-(b)) >= 0)


#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

/* Length of the TCP header, excluding options. */
#define TCP_HLEN sizeof(struct tcp_hdr)

/* TCP Maximum segment size. */
#define TCP_MSS 512

/* TCP receive window. */
#define TCP_WND 2048

/* Maximum number of retransmissions. */
#define TCP_MAXRTX 12

#define TCP_FINE_TIMEOUT     200  /* the fine grained timeout in microseconds */
#define TCP_COARSE_TIMEOUT   500  /* the coarse grained timeout in microseconds */
#define TCP_FIN_WAIT_TIMEOUT 20000 /* microseconds */
#define TCP_SYN_RCVD_TIMEOUT 20000 /* microseconds */


#ifdef LWIP_DEBUG
#define TCP_MSL 50000  /* The maximum segment lifetime in microseconds */
#else 
#define TCP_MSL 30000  /* The maximum segment lifetime in microseconds */
#endif /* LWIP_DEBUG */

struct tcp_hdr {
  u16_t src, dest;
  u32_t seqno, ackno;
#ifdef HAVE_BITFIELDS
#if BYTE_ORDER == LITTLE_ENDIAN
  u8_t unused:4,
    offset:4;
#else
  u8_t offset:4,
    unused:4.
#endif
#else
  u8_t offset_unused;
#endif /* HAVE_BITFIELDS */
  u8_t flags;
  u16_t wnd;
  u16_t chksum;
  u16_t urgp;
  u8_t options[0];
};

enum tcp_state {
  CLOSED      = 0,
  LISTEN      = 1,
  SYN_SENT    = 2,
  SYN_RCVD    = 3,
  ESTABLISHED = 4,
  FIN_WAIT_1  = 5,
  FIN_WAIT_2  = 6,
  CLOSE_WAIT  = 7,
  CLOSING     = 8,
  LAST_ACK    = 9,
  TIME_WAIT   = 10
};


/* the TCP protocol control block */
struct tcp_pcb {
  struct tcp_pcb *next;   /* for the linked list */

  enum tcp_state state;   /* TCP state */

  /* Function to call when a listener has been connected. */
  void (* accept)(void *arg, struct tcp_pcb *newpcb, int err);
  void *accept_arg;

  struct ip_addr local_ip;
  u16_t local_port;
  
  struct ip_addr dest_ip;
  u16_t dest_port;
  
  /* receiver varables */
  u32_t rcv_nxt;   /* next seqno expected */
  u32_t rcv_wnd;   /* receiver window */
  
  /* timers */
  u16_t tmr;
  
  u32_t mss;   /* maximum segment size */

  u8_t flags;
#define TCP_ACK_NEXT 0x01   /* Delayed ACK */
#define TCP_INFR     0x02   /* In fast recovery */
  
  /* RTT estimation variables. */
  u16_t rttest; /* RTT estimate in 500ms ticks */
  u32_t rtseq;  /* sequence number being timed */
  s32_t sa, sv;

  u16_t rto;    /* retransmission time-out */
  u8_t nrtx;    /* number of retransmissions */

  /* fast retransmit/recovery */
  u32_t lastack;
  u8_t dupacks;
  
  /* congestion avoidance/control variables */
  u32_t cwnd;  
  u32_t ssthresh;

  /* sender variables */
  u32_t snd_ack,   /* Highest acknowledged seqno. */
    snd_nxt,       /* next seqno to be sent */
    snd_max,       /* Highest seqno sent. */
    snd_wnd,       /* sender window */
    snd_wl1, snd_wl2,
    snd_lbb;       /* */


  /* Function to be called when (in-sequence) data has arrived. */
  void (* recv)(void *arg, struct tcp_pcb *pcb, struct pbuf *p, int err);
  void *recv_arg;

  /* Function to be called when a connection has been set up. */
  void (* connected)(void *arg, struct tcp_pcb *pcb, int err);
  void *connected_arg;

  /* These are ordered by sequence number: */
  struct tcp_seg *unsent;   /* Unsent (queued) segments. */
  struct tcp_seg *unacked;  /* Sent but unacknowledged segments. */
  struct tcp_seg *ooseq;    /* Received out of sequence segments. */

};

struct tcp_pcb_listen {  
  struct tcp_pcb *next;   /* for the linked list */
  
  enum tcp_state state;   /* TCP state */

  /* Function to call when a listener has been connected. */
  void (* accept)(void *arg, struct tcp_pcb *newpcb);
  void *accept_arg;

  struct ip_addr local_ip;
  u16_t local_port;
};

/* The TCP PCB when in TIME-WAIT. */
struct tcp_pcb_tw {
  struct tcp_pcb *next;   /* for the linked list */

  enum tcp_state state;   /* TCP state */

  /* Function to call when a listener has been connected. */
  void (* accept)(void *arg, struct tcp_pcb *newpcb);
  void *accept_arg;

  struct ip_addr local_ip;
  u16_t local_port;
  
  struct ip_addr dest_ip;
  u16_t dest_port;  

  /* receiver varables */
  u32_t rcv_nxt;   /* next seqno expected */
  u32_t rcv_wnd;   /* receiver window */

  /* timer */
  u32_t tmr;
};

/* This structure is used for outgoing TCP segments */
struct tcp_seg {
  struct tcp_seg *next;    /* used when putting segements on a queue */
  u16_t len;               /* the TCP length of this segment */
  struct pbuf *p;          /* buffer containing data + TCP header */
  struct tcp_hdr *tcphdr;  /* the TCP header */
  void *data;              /* pointer to the TCP data in the pbuf */
  u16_t rtime;             /* retransmission timer */
};


/* This structure is used for incomming TCP segments */
struct tcp_seg_in {
  struct tcp_seg *next;    /* used when putting segements on a queue */
  u16_t len;               /* the TCP length of this segment */
  struct pbuf *p;          /* buffer containing data + TCP header */
  struct tcp_hdr *tcphdr;  /* the TCP header */
  void *data;              /* pointer to the TCP data in the pbuf */
};


/* Functions for interfacing with TCP: */
void tcp_init    (void);
void tcp_accept  (struct tcp_pcb *pcb,
		  void (* accept)(void *arg, struct tcp_pcb *newpcb,
				  int err),
		  void *accept_arg);
void tcp_recv    (struct tcp_pcb *pcb,
		  void (* recv)(void *arg, struct tcp_pcb *pcb,
				struct pbuf *p, int err),
		  void *recv_arg);
void tcp_recved  (struct tcp_pcb *pcb, unsigned short len);
int  tcp_bind    (struct tcp_pcb *pcb, struct ip_addr *ipaddr,
		  u16_t port);
int  tcp_connect (struct tcp_pcb *pcb, struct ip_addr *ipaddr,
		  u16_t port,void (* connected)(void *arg,
						struct tcp_pcb *pcb,
						int err),
		  void *connected_arg);
int  tcp_listen  (struct tcp_pcb *pcb);
void tcp_abort   (struct tcp_pcb *pcb);
int  tcp_close   (struct tcp_pcb *pcb);
void tcp_input   (struct pbuf *p);
void tcp_output  (struct tcp_pcb *pcb);
int  tcp_write   (struct tcp_pcb *pcb, void *data, u16_t len,
		  u8_t copy);


/* Internal functions and global variables: */
struct tcp_pcb *tcp_pcb_new(void);
struct tcp_pcb *tcp_pcb_copy(struct tcp_pcb *pcb);
unsigned int tcp_pcb_purge(struct tcp_pcb *pcb);
unsigned int tcp_pcb_remove(struct tcp_pcb **pcblist, struct tcp_pcb *pcb);

unsigned int tcp_segs_free(struct tcp_seg *seg);
unsigned int tcp_seg_free(struct tcp_seg *seg);
struct tcp_seg *tcp_seg_copy(struct tcp_seg *seg);

#define tcp_ack(pcb)     if((pcb)->flags & TCP_ACK_NEXT) { \
                            tcp_send_ctrl((pcb), TCP_ACK); \
                            (pcb)->flags &= ~TCP_ACK_NEXT; \
                         } else { \
                            (pcb)->flags |= TCP_ACK_NEXT; \
                         }

#define tcp_ack_now(pcb) tcp_send_ctrl((pcb), TCP_ACK); \
                         if((pcb)->flags & TCP_ACK_NEXT) { \
                            (pcb)->flags &= ~TCP_ACK_NEXT; \
                         }


int tcp_send_ctrl(struct tcp_pcb *pcb, unsigned char flags);
int tcp_enqueue(struct tcp_pcb *pcb, void *data, u16_t len,
		u8_t flags, u8_t copy,
                char *optdata, u8_t optlen);

void tcp_rexmit_seg(struct tcp_pcb *pcb, struct tcp_seg *seg);

void tcp_rst(u32_t seqno, u32_t ackno,
	     struct ip_addr *local_ip, struct ip_addr *dest_ip,
	     u16_t local_port, u16_t dest_port);

u32_t tcp_next_iss(void);

extern u32_t tcp_ticks;
extern u8_t tcp_backoff[TCP_MAXRTX + 1];

#if TCP_DEBUG
void tcp_debug_print(struct tcp_hdr *tcphdr);
void tcp_debug_print_flags(u8_t flags);
void tcp_debug_print_state(enum tcp_state s);
void tcp_debug_print_pcbs(void);
int tcp_pcbs_sane(void);
#else
#define tcp_pcbs_sane() 1
#endif /* TCP_DEBUG */


/* The TCP PCB lists. */
extern struct tcp_pcb *tcp_listen_pcbs;  /* List of all TCP PCBs in LISTEN state. */
extern struct tcp_pcb *tcp_active_pcbs;  /* List of all TCP PCBs that are in a
					    state in which they accept or send
					    data. */
extern struct tcp_pcb *tcp_tw_pcbs;      /* List of all TCP PCBs in TIME-WAIT. */

/* Axoims about the above list:   
   1) Every TCP PCB that is not CLOSED is in one of the lists.
   2) A PCB is only in one of the lists.
   3) All PCBs in the tcp_listen_pcbs list is in LISTEN state.
   4) All PCBs in the tcp_tw_pcbs list is in TIME-WAIT state.
*/

/* Define two macros, TCP_REG and TCP_RMV that registers a TCP PCB
   with a PCB list or removes a PCB from a list, respectively. */
#ifdef LWIP_DEBUG
#define TCP_REG(pcbs, npcb) do {\
                            struct tcp_pcb *__ipcb; \
                            DEBUGF(TCP_DEBUG, ("TCP_REG local port %d\n", npcb->local_port)); \
                            for(__ipcb = *pcbs; \
				  __ipcb != NULL; \
				__ipcb = __ipcb->next) { \
                                ASSERT("TCP_REG: already registered\n", __ipcb != npcb); \
                            } \
                            ASSERT("TCP_REG: pcb->state != CLOSED", npcb->state != CLOSED); \
                            npcb->next = *pcbs; \
                            ASSERT("TCP_REG: npcb->next != npcb", npcb->next != npcb); \
                            *pcbs = npcb; \
                            ASSERT("TCP_RMV: tcp_pcbs sane", tcp_pcbs_sane()); \
                            } while(0)
#define TCP_RMV(pcbs, npcb) do { \
                            struct tcp_pcb *__ipcb; \
                            DEBUGF(TCP_DEBUG, ("TCP_RMV: removing %p from %p\n", npcb, *pcbs)); \
                            if(*pcbs == npcb) { \
                               *pcbs = (*pcbs)->next; \
                            } else for(__ipcb = *pcbs; __ipcb != NULL; __ipcb = __ipcb->next) { \
                               if(__ipcb->next != NULL && __ipcb->next == npcb) { \
                                  __ipcb->next = npcb->next; \
                                  break; \
                               } \
                            } \
                            ASSERT("TCP_RMV: pcb not found on pcbs list", __ipcb != NULL); \
                            ASSERT("TCP_RMV: tcp_pcbs sane", tcp_pcbs_sane()); \
                            DEBUGF(TCP_DEBUG, ("TCP_RMV: removed %p from %p\n", npcb, *pcbs)); \
                            } while(0)

#else /* LWIP_DEBUG */
#define TCP_REG(pcbs, npcb) do { \
                            npcb->next = *pcbs; \
                            *pcbs = npcb; \
                            } while(0)
#define TCP_RMV(pcbs, npcb) do { \
                            struct tcp_pcb *__ipcb; \
                            if(*pcbs == npcb) { \
                               *pcbs = (*pcbs)->next; \
                            } else for(__ipcb = *pcbs; __ipcb != NULL; __ipcb = __ipcb->next) { \
                               if(__ipcb->next != NULL && __ipcb->next == npcb) { \
                                  __ipcb->next = npcb->next; \
                                  break; \
                               } \
                            } \
                            ASSERT("TCP_RMV: pcb not found on pcbs list", __ipcb != NULL); \
                            } while(0)
#endif /* LWIP_DEBUG */
#endif /* __LWIP_TCP_H__ */



