/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: test_tcp.c,v 1.6 2001/03/01 12:24:23 adam Exp $
 */

#include <unistd.h>

#include "lwip/debug.h"
#include "lwip/mem.h"
#include "lwip/stats.h"
#include "netif/loopif.h"
#include "netif/tcpdump.h"
#include "lwip/tcpip.h"
#include "lwip/tcp.h"

/*-----------------------------------------------------------------------------------*/
static void *
echo_server(void *arg)
{
  struct netconn *conn, *newconn;
  struct netbuf *buf;
  struct ip_addr ipaddr;
  char data[1000];
  
  conn = netconn_new(NETCONN_TCP);
  IP4_ADDR(&ipaddr, 127,0,0,1);
  netconn_bind(conn, &ipaddr, 7);
  netconn_listen(conn);
  while(1) {
    newconn = netconn_accept(conn);
    while((buf = netconn_recv(newconn)) != NULL) {
      netbuf_copy(buf, data, 1000);
      data[netbuf_len(buf)] = 0;
      netconn_write(newconn, data, netbuf_len(buf), NETCONN_COPY);
      netbuf_delete(buf);
    }
    netconn_delete(newconn);
  }
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
static void 
echo_client_to(void *arg)
{
  struct netconn *conn;
  struct netbuf *buf;
  char data[1000];
  struct ip_addr ipaddr;
  char rq[] = "Hejsan echo!\n";
  
  conn = netconn_new(NETCONN_TCP);
  IP4_ADDR(&ipaddr, 127,0,0,1);
  netconn_connect(conn, &ipaddr, 7);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
  netconn_close(conn);
  while((buf = netconn_recv(conn)) != NULL) {
    netbuf_copy(buf, data, 1000);
    data[netbuf_len(buf)] = 0;
#ifdef LWIP_DEBUG
    DEBUGF(1, ("%s", data));
#endif /* LWIP_DEBUG */
    netbuf_delete(buf);
  }
  netconn_delete(conn);
}
/*-----------------------------------------------------------------------------------*/
static void *
echo_client(void *arg)
{
  sys_timeout(1000, echo_client_to, NULL);
  sys_main();
  return NULL;
}
/*-----------------------------------------------------------------------------------*/
static void
main_thread(void *arg)
{
  struct ip_addr ipaddr, netmask, gw;
  sys_sem_t sem;

  IP4_ADDR(&gw, 127,0,0,1);
  IP4_ADDR(&ipaddr, 127,0,0,1); 
  IP4_ADDR(&netmask, 255,0,0,0);

  netif_add(&ipaddr, &netmask, &gw, loopif_init, tcpip_input);

  sem = sys_sem_new(0);  
  tcpip_init(&sem);
  sys_sem_wait(sem);
  sys_sem_free(sem);
  
  printf("TCP/IP initialized.\n");
  
#ifdef MEM_PERF
  mem_perf_init("/tmp/memstats.client");
#endif /* MEM_PERF */

  sys_thread_new(echo_server, NULL);
  sys_thread_new(echo_client, NULL);
  sys_main();
}
/*-----------------------------------------------------------------------------------*/
int
main(int argc, char **argv)
{
  
#ifdef STATS
  stats_init();
#endif /* STATS */
  sys_init();
  mem_init();
  pbuf_init(16, 128);

  tcpdump_init();
  
  printf("System initialized.\n");
    
  sys_thread_new((void *)(main_thread), NULL);
  pause();
  return 0;
}
/*-----------------------------------------------------------------------------------*/
