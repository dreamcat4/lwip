/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: sys_arch.c,v 1.5 2001/02/21 20:39:40 adam Exp $
 */

#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/sys.h"
#include "lwip/mem.h"
#include "arch/dlist.h"

#include "rtxcapi.h"
#include "csema.h"
#include "cclock.h"
#include "cqueue.h"
#include "cres.h"

/*static struct irq_s *irqs;*/
/*static struct dlist *timeouts;*/
static struct sys_thread *threads = NULL;

static struct sem *semfree = NULL;

struct timeoutlist {
  struct timeoutlist *next;
  struct dlist *timeouts;
  TASK pid;
};

static struct timeoutlist *timeoutlist = NULL;

struct timeout_s {
  sys_timeout_handler h;
  void *data;
};

struct irq_s {
  struct irq_s *next;
  sys_irq_handler h;
  int fd;
  void *data;
};

//static struct timeval starttime;
/*-----------------------------------------------------------------------------------*/
sys_mbox_t
sys_mbox_new(void)
{
  QUEUE mbox;  
  KS_dequeuew(IP_MBOXQ, &mbox);
  KS_purgequeue(mbox);
  return mbox;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(sys_mbox_t mbox)
{
  KS_enqueue(IP_MBOXQ, &mbox);
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(sys_mbox_t mbox, void *data)
{
  KS_enqueue(mbox, &data);
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_fetch(sys_mbox_t mbox, void **data)
{
  KS_dequeuew(mbox, data);
}
/*-----------------------------------------------------------------------------------*/
sys_sem_t
sys_sem_new(int count)
{
  SEMA sem;
  KS_dequeuew(IP_SEMQ, &sem);
  KS_pend(sem);
  if(count > 0) {
    KS_signal(sem);
  }
  return sem;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_wait(sys_sem_t sem)
{
  unsigned int ticks;
  struct dlist *timeouts;
  struct timeout_s *timeout_s;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;

  if(timeoutlist == NULL) {
    timeouts = NULL;    
  } else {
    pid = KS_inqtask();
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
  
  
  if(timeouts == NULL || dlist_is_empty(timeouts)) {
    KS_wait(sem);
  } else {  
    ticks = dlist_first(timeouts, (void **)&timeout_s);
    ret = KS_waitt(sem, (TICKS)ticks/CLKTICK);
    
    if(ret == RC_TIMEOUT) {
      do {
	timeout_s = dlist_remove_first(timeouts);
	timeout_s->h(timeout_s->data);
	mem_free(timeout_s);
	if(!dlist_is_empty(timeouts)) {
	  ticks = dlist_first(timeouts, (void **)&timeout_s);
	}
      } while(!dlist_is_empty(timeouts) && ticks == 0);
    }
  }
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(sys_sem_t sem)
{
  KS_signal(sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(sys_sem_t sem)
{
  KS_enqueue(IP_SEMQ, &sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_timeout(unsigned int msecs, sys_timeout_handler h, void *data)
{
  struct dlist *timeouts;
  struct timeout_s *t;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;

  pid = KS_inqtask();
  
  if(timeoutlist == NULL) {
    timeouts = NULL;    
  } else {
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
  
  if(timeouts == NULL) {
    timeouts = dlist_new();
    tl = mem_malloc(sizeof(struct timeoutlist));
    tl->pid = pid;
    tl->timeouts = timeouts;
    
    KS_lockw(IP_S_RES);
    tl->next = timeoutlist;    
    timeoutlist = tl;
    KS_unlock(IP_S_RES);
  }
  
  t = mem_malloc(sizeof(struct timeout_s));
  t->h = h;
  t->data = data;
  dlist_insert(timeouts, t, msecs);  
}
/*-----------------------------------------------------------------------------------*/
void
sys_init(void)
{
  /* posta in alla semaforer i IP_SEMQ, posta in alla mboxar i
     IP_MBOXQ */
  QUEUE mbox;
  SEMA  sem;
  
  mbox = IP_Q_01; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_02; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_03; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_04; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_05; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_06; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_07; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_08; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_09; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_10; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_11; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_12; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_13; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_14; KS_enqueue(IP_MBOXQ, &mbox);
  mbox = IP_Q_15; KS_enqueue(IP_MBOXQ, &mbox);
  sem  = IP_S_01; KS_enqueue(IP_SEMQ,  &sem);
  sem  = IP_S_02; KS_enqueue(IP_SEMQ,  &sem);
  sem  = IP_S_03; KS_enqueue(IP_SEMQ,  &sem);
}

/*-----------------------------------------------------------------------------------*/

sys_thread_t sys_thread_new(void *(* function)(void *arg), void *arg) {
  return (sys_thread_t)function(arg);
}






