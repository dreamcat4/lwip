/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: client.c,v 1.1 2001/02/06 13:42:41 adam Exp $
 */

#include "lwip/debug.h"

#include "lwip/mem.h"
#include "lwip/sys.h"

#include "lwip/stats.h"

#include "netif/loopif.h"
#include "netif/rs232if.h"

#include "http_noapi.h"

#include "systat.h"

#include "lwip/ip.h"
#include "lwip/udp.h"
#include "lwip/tcp.h"

int
main(int argc, char **argv)
{
  struct ip_addr ipaddr, netmask, gw;
    
#ifdef STATS
  stats_init();
#endif /* STATS */
  sys_init();
  mem_init();
  pbuf_init(16, 128);

  printf("System initialized\n");

  gw.addr = htonl(0x7f000001);
  ipaddr.addr = htonl(0x7f000001);
  netmask.addr = htonl(0xff000000);
  netif_add(&ipaddr, &netmask, &gw, loopif_init, ip_input);

  gw.addr = htonl(0x0a000001);
  ipaddr.addr = htonl(0x0a000002);
  netmask.addr = htonl(0xffffff00);
  netif_set_default(netif_add(&ipaddr, &netmask, &gw, rs232if_init,
			      ip_input));

  printf("Before ip_init()\n");
  ip_init();
  printf("Before udp_init()\n");
  udp_init();
  printf("Before tcp_init()\n");
  tcp_init();

  printf("TCP/IP initialized\n");
  
  /*  http_init();*/
  printf("Before systat_init()\n");
  systat_init();

  printf("Clients initialized\n");
  
  sys_main();
}




