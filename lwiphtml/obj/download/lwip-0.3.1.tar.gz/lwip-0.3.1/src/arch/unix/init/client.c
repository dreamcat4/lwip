/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: client.c,v 1.8 2001/02/27 13:24:25 adam Exp $
 */

#include "lwip/debug.h"

#include <unistd.h>


#include "lwip/mem.h"
#include "lwip/sys.h"

#include "lwip/stats.h"


#include "lwip/tcpip.h"

#ifdef linux
#include "netif/tapif.h"
#else /* linux */
#include "netif/tunif.h"
#endif /* linux */

#include "netif/unixif.h"
#include "netif/dropif.h"

#include "netif/loopif.h"

#include "netif/tcpdump.h"

#include "example.h"
#include "udp_example.h"
#include "http_example.h"

#include "http_noapi.h"

#include "systat.h"
#include "echo.h"
#include "memdebug.h"

#include "lwip/ip_addr.h"

#include "arch/perf.h"
/*-----------------------------------------------------------------------------------*/
static void
mem_timeout(void *data)
{
  /*#ifdef MEM_TRACKING
  stats_mem();
#else
  mem_debug_print();
  #endif*/ /* MEM_TRACKING */
#if MEM_DEBUG
  mem_debug_print();
#endif /* MEM_DEBUG */
  sys_timeout(1000, mem_timeout, NULL);
}
/*-----------------------------------------------------------------------------------*/
static void
mem_more_timeout(void *data)
{
#if MEM_DEBUG
#ifdef MEM_TRACKING
  mem_debug_print_more();
#endif /* MEM_TRACKING */
#endif /* MEM_DEBUG */
  sys_timeout(10000, mem_more_timeout, NULL);
}
/*-----------------------------------------------------------------------------------*/
static void
pbuf_timeout(void *data)
{
#if PBUF_DEBUG
  pbuf_debug_print_stats();
#endif /* PBUF_DEBUG */
  /*  mem_debug_print();*/
  sys_timeout(2500, pbuf_timeout, NULL);
}

/*-----------------------------------------------------------------------------------*/
static void
tcp_timeout(void *data)
{
#if TCP_DEBUG
  tcp_debug_print_pcbs();
#endif /* TCP_DEBUG */
  sys_timeout(5000, tcp_timeout, NULL);
}
/*-----------------------------------------------------------------------------------*/
static void
exit_timeout(void *arg)
{
  exit(0);
}
/*-----------------------------------------------------------------------------------*/
static void
accept_exit(void *arg, struct tcp_pcb *pcb, int err)
{
  tcp_close(pcb);
  sys_timeout(1000, exit_timeout, NULL);
}
/*-----------------------------------------------------------------------------------*/
static void
main_thread(void *arg)
{
  struct ip_addr ipaddr, netmask, gw;
  sys_sem_t sem;


  IP4_ADDR(&gw, 127,0,0,1);
  IP4_ADDR(&ipaddr, 127,0,0,1); 
  IP4_ADDR(&netmask, 255,0,0,0);

  netif_add(&ipaddr, &netmask, &gw, loopif_init, ip_input);
    
  IP4_ADDR(&gw, 192,168,1,1);
  IP4_ADDR(&ipaddr, 192,168,1,2);
  IP4_ADDR(&netmask, 255,255,255,0);

  /* For testing without proxy. */

  /*
#ifdef linux
  netif_set_default(netif_add(&ipaddr, &netmask, &gw, tapif_init_thread,
  tcpip_input));
#else
  netif_set_default(netif_add(&ipaddr, &netmask, &gw, tunif_init_thread,
  tcpip_input));
#endif
  */

  netif_set_default(netif_add(&ipaddr, &netmask, &gw, unixif_init,
			      tcpip_input)); 

  
  sem = sys_sem_new(0);
  tcpip_init(&sem);
  sys_sem_wait(sem);
  sys_sem_free(sem);
  printf("TCP/IP initialized.\n");

  sys_thread_new(example_thread, NULL);
  sys_thread_new(udp_example_thread, NULL);
  sys_thread_new(http_example_thread, NULL);

  memdebug_init();
  echo_init();
  http_init();
  systat_init();

  printf("Applications started.\n");
    
  sys_timeout(1000, mem_timeout, NULL);
  sys_timeout(10000, mem_more_timeout, NULL);
  sys_timeout(5000, tcp_timeout, NULL);
  sys_timeout(1000, pbuf_timeout, NULL);

#ifdef MEM_PERF
  mem_perf_init("/tmp/memstats.client");
#endif /* MEM_PERF */

  /* Set up a server on port 666 that causes the process to exit when called. */
  {
    struct tcp_pcb *pcb;    
    pcb = tcp_pcb_new();
    tcp_bind(pcb, NULL, 666);
    tcp_listen(pcb);
    tcp_accept(pcb, accept_exit, NULL);
  }
  sys_main();
}
/*-----------------------------------------------------------------------------------*/
int
main(int argc, char **argv)
{
#ifdef PERF
  perf_init("/tmp/client.perf");
#endif /* PERF */
#ifdef STATS
  stats_init();
#endif /* STATS */
  sys_init();
  mem_init();
  pbuf_init(16, 128);

  tcpdump_init();

  
  printf("System initialized.\n");
    
  sys_thread_new((void *)(main_thread), NULL);
  pause();
  return 0;
}
/*-----------------------------------------------------------------------------------*/









