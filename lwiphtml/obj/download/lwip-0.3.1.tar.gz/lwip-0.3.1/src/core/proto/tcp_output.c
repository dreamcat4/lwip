/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_output.c,v 1.21 2001/03/01 12:24:19 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* tcp_output.c
 *
 * The output functions of TCP.
 *
 */
/*-----------------------------------------------------------------------------------*/

#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/opt.h"

#include "arch/lib.h"

#include "lwip/mem.h"
#include "lwip/sys.h"

#include "lwip/netif.h"

#include "lwip/inet.h"
#include "lwip/tcp.h"

#include "lwip/stats.h"


#define MIN(x,y) (x) < (y)? (x): (y)



/* Forward declarations.*/
static void tcp_output_packet(struct pbuf *p,
                              struct ip_addr *local_ip, struct ip_addr *dest_ip,
                              u16_t local_port, u16_t dest_port,
                              u8_t flags,
                              u32_t seqno, u32_t ackno,
                              u32_t rcv_wnd, u16_t snd_up);
static void tcp_output_segment(struct tcp_seg *seg, struct tcp_pcb *pcb);


/*-----------------------------------------------------------------------------------*/
int
tcp_send_ctrl(struct tcp_pcb *pcb, u8_t flags)
{
  return tcp_enqueue(pcb, NULL, 0, flags, 1, NULL, 0);
}
/*-----------------------------------------------------------------------------------*/
int
tcp_write(struct tcp_pcb *pcb, void *data, u16_t len, u8_t copy)
{
  return tcp_enqueue(pcb, data, len, 0, copy, NULL, 0);
}
/*-----------------------------------------------------------------------------------*/
int
tcp_enqueue(struct tcp_pcb *pcb, void *data, u16_t len,
	    u8_t flags, u8_t copy,
            char *optdata, u8_t optlen)
{
  struct pbuf *p;
  struct tcp_seg *seg, *useg;
  u32_t left, seglen;
  void *ptr;
  char mf;  /* more fragments */
  int i;

  left = len;
  ptr = data;

  if(len == 0 && flags == TCP_ACK) {
    p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
    if(p == NULL) {
      return ERR_MEM;
    }
    /*    DEBUGF("tcp_enqueue: sending ACK for %lu\n", pcb->rcv_nxt);*/
    tcp_output_packet(p, &(pcb->local_ip), &(pcb->dest_ip),
		      pcb->local_port, pcb->dest_port,
		      flags, pcb->snd_nxt, pcb->rcv_nxt,
		      pcb->rcv_wnd, 0);
    pbuf_free(p);
    
  } else {
    mf = 1;
    while(mf) {
      
      seglen = left > pcb->mss? pcb->mss: left;

      /* allocate memory for tcp_seg, and fill in fields */
      seg = mem_malloc(sizeof(struct tcp_seg));
      if(seg == NULL) {
#ifdef TCP_STATS
        stats.tcp.memerr++;
#endif /* TCP_STATS */

	return ERR_MEM;
      }
      seg->next = NULL;

      /* If copy is set, memory should be allocated
	 and data copied into pbuf, otherwise data comes from
	 ROM or such, and need not be copied. If
         optdata is != NULL, we have options instead of data. */
      if(optdata != NULL) {
	if((seg->p = pbuf_alloc(PBUF_TRANSPORT, optlen, PBUF_RAM)) == NULL) {
	  mem_free(seg);
#ifdef TCP_STATS
          stats.tcp.memerr++;
#endif /* TCP_STATS */
	  return ERR_MEM;
	}
	seg->data = seg->p->payload;
      } else if(copy) {
	if((seg->p = pbuf_alloc(PBUF_TRANSPORT, seglen, PBUF_RAM)) == NULL) {
	  mem_free(seg);
#ifdef TCP_STATS
          stats.tcp.memerr++;
#endif /* TCP_STATS */
	  return ERR_MEM;
	}
	if(data != NULL) {
	  bcopy(ptr, seg->p->payload, seglen);
	}
	seg->data = seg->p->payload;
      } else {
        /* Do not copy the data. */
	if((p = pbuf_alloc(PBUF_TRANSPORT, seglen, PBUF_ROM)) == NULL) {
	  mem_free(seg);
#ifdef TCP_STATS
          stats.tcp.memerr++;
#endif /* TCP_STATS */
	  return ERR_MEM;
	}
        p->payload = ptr;
	seg->data = ptr;
	if((seg->p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM)) == NULL) {
	  mem_free(seg);
#ifdef TCP_STATS
          stats.tcp.memerr++;
#endif /* TCP_STATS */
	  return ERR_MEM;
	}
	pbuf_chain(seg->p, p);
      }
      
      seg->len = seglen;
      if((flags & TCP_SYN) || (flags & TCP_FIN)) { 
	seg->len++;
      }

      if(pcb->unsent == NULL) {
	useg = NULL;
      } else {
	for(useg = pcb->unsent; useg->next != NULL; useg = useg->next);
      }

      /* If there is room in the last pbuf on the unsent queue,
	 chain this pbuf together with that. */
      if(useg != NULL &&
	 !(useg->tcphdr->flags & (TCP_SYN | TCP_FIN)) &&
	 !(flags & (TCP_SYN | TCP_FIN)) &&
	 useg->len + seg->len <= pcb->mss) {
	pbuf_chain(useg->p, seg->p);
	useg->len += seg->len;

	DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_output: chaining, new len %u\n", useg->len));
	
      } else {
	
	/* build TCP header */
	if(pbuf_header(seg->p, TCP_HLEN)) {

	  DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_enqueue: no room for TCP header in pbuf.\n"));

#ifdef TCP_STATS
          stats.tcp.err++;
#endif /* TCP_STATS */
	  pbuf_free(seg->p);
	  mem_free(seg);
	  return ERR_BUF;
	}
	seg->tcphdr = seg->p->payload;
	seg->tcphdr->src = htons(pcb->local_port);
	seg->tcphdr->dest = htons(pcb->dest_port);
	seg->tcphdr->seqno = htonl(pcb->snd_lbb);
	seg->tcphdr->urgp = 0;
	seg->tcphdr->flags = flags;
	/* don't fill in tcphdr->ackno and tcphdr->wnd until later */
	
	if(optdata == NULL) {
#ifdef HAVE_BITFIELDS
	  seg->tcphdr->offset = 5;
#else
          seg->tcphdr->offset_unused = 5 << 4;
#endif /* HAVE_BITFIELDS */
	} else {
#ifdef HAVE_BITFIELDS
	  seg->tcphdr->offset = 5 + optlen / 4;
#else
          seg->tcphdr->offset_unused = (5 + optlen / 4) << 4;
#endif /* HAVE_BITFIELDS */
	  /* Copy options into data portion of segment.
	     Options can thus only be sent in non data carrying
	     segments such as SYN|ACK. */
	  for(i = 0; i < optlen; i++) {
	    ((char *)(seg->data))[i] = optdata[i];
	  }
	}
	if(useg == NULL) {
	  pcb->unsent = seg;
	} else {
	  useg->next = seg;
	}

	DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_enqueue: queueing %lu:%lu\n",
				  ntohl(seg->tcphdr->seqno),
				  ntohl(seg->tcphdr->seqno) + seg->len));
      }

      pcb->snd_lbb += seg->len;
      left -= seglen;
      ptr = (void *)((char *)ptr + seglen);
      if(left == 0) {
	mf = 0;
      }
    }
    tcp_output(pcb);
  }
  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
/* find out what we can send and send it */
void
tcp_output(struct tcp_pcb *pcb)
{
  struct tcp_seg *seg, *useg;
  u32_t wnd;
#if TCP_CWND_DEBUG
  int i = 0;
#endif /* TCP_CWND_DEBUG */
  
  wnd = MIN(pcb->snd_wnd, pcb->cwnd);
  
  seg = pcb->unsent; 

#if TCP_CWND_DEBUG
  if(seg == NULL) {
    DEBUGF(TCP_CWND_DEBUG, ("tcp_output: snd_wnd %lu, cwnd %lu, wnd %lu, seg == NULL, ack %lu\n",
                            pcb->snd_wnd, pcb->cwnd, wnd,
                            pcb->snd_ack));
  } else {
    DEBUGF(TCP_CWND_DEBUG, ("tcp_output: snd_wnd %lu, cwnd %lu, wnd %lu, effwnd %lu, seq %lu, ack %lu\n",
                            pcb->snd_wnd, pcb->cwnd, wnd,
                            ntohl(seg->tcphdr->seqno) - pcb->snd_ack + seg->len,
                            ntohl(seg->tcphdr->seqno), pcb->snd_ack));
  }
#endif /* TCP_CWND_DEBUG */

  while(seg != NULL &&
	ntohl(seg->tcphdr->seqno) - pcb->snd_ack + seg->len <= wnd) {
#if TCP_CWND_DEBUG
    DEBUGF(TCP_CWND_DEBUG, ("tcp_output: snd_wnd %lu, cwnd %lu, wnd %lu, effwnd %lu, seq %lu, ack %lu, i%d\n",
                            pcb->snd_wnd, pcb->cwnd, wnd,
                            ntohl(seg->tcphdr->seqno) + seg->len -
                            pcb->snd_ack,
                            ntohl(seg->tcphdr->seqno), pcb->snd_ack, i));
    i++;
#endif /* TCP_CWND_DEBUG */

    pcb->unsent = seg->next;
    
    
    if(pcb->state != SYN_SENT) {
      seg->tcphdr->flags |= TCP_ACK;
      if(pcb->flags & TCP_ACK_NEXT) {
	pcb->flags &= ~TCP_ACK_NEXT;
      }
    }
    
    tcp_output_segment(seg, pcb);
    pcb->snd_nxt = ntohl(seg->tcphdr->seqno) + seg->len;
    if(TCP_SEQ_LT(pcb->snd_max, pcb->snd_nxt)) {
      pcb->snd_max = pcb->snd_nxt;
    }
    /* put segment on unacknowledged list if length > 0 */
    if(seg->len > 0) {
      seg->next = NULL;
      if(pcb->unacked == NULL) {
        pcb->unacked = seg;
      } else {
        for(useg = pcb->unacked; useg->next != NULL; useg = useg->next);
        useg->next = seg;
      }
      seg->rtime = 0;
    } else {
      tcp_seg_free(seg);
    }
    seg = pcb->unsent;
  }
}
/*-----------------------------------------------------------------------------------*/
static void
tcp_output_segment(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  u16_t len, tot_len;
  struct netif *netif;
  
  /* The TCP header has already been constructed,
   but the ackno and wnd fields remain. */
  seg->tcphdr->ackno = htonl(pcb->rcv_nxt);

  /* silly window avoidance */
  if(pcb->rcv_wnd < pcb->mss) {
    seg->tcphdr->wnd = 0;
  } else {
    seg->tcphdr->wnd = htons(pcb->rcv_wnd);
  }

  /* If we don't have a local IP address, we get one by
     calling ip_route(). */
  if(ip_addr_isany(&(pcb->local_ip))) {
    netif = ip_route(&(pcb->dest_ip));
    if(netif == NULL) {
      return;
    }
    ip_addr_set(&(pcb->local_ip), &(netif->ip_addr));
  }
  
  if(pcb->rttest == 0) {
    pcb->rttest = tcp_ticks;
    pcb->rtseq = ntohl(seg->tcphdr->seqno);

    DEBUGF(TCP_RTO_DEBUG, ("tcp_output_segment: rtseq %lu\n", pcb->rtseq));
  }
  DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_output_segment: %lu:%lu\n",
			    htonl(seg->tcphdr->seqno), htonl(seg->tcphdr->seqno) +
			    seg->len));

  seg->tcphdr->chksum = 0;
  seg->tcphdr->chksum = inet_chksum_pseudo(seg->p,
					   &(pcb->local_ip),
					   &(pcb->dest_ip),
					   IP_PROTO_TCP, seg->p->tot_len);
#ifdef TCP_STATS
    stats.tcp.xmit++;
#endif /* TCP_STATS */

  len = seg->p->len;
  tot_len = seg->p->tot_len;
  ip_output(seg->p, &(pcb->local_ip), &(pcb->dest_ip), TCP_TTL,
	    IP_PROTO_TCP);
  seg->p->len = len;
  seg->p->tot_len = tot_len;
  seg->p->payload = seg->tcphdr;

}
/*-----------------------------------------------------------------------------------*/
static void
tcp_output_packet(struct pbuf *p,
		  struct ip_addr *local_ip, struct ip_addr *dest_ip,
		  u16_t local_port, u16_t dest_port,
		  u8_t flags,
		  u32_t seqno, u32_t ackno,
		  u32_t rcv_wnd, u16_t snd_up)
{
  struct tcp_hdr *tcphdr;
  u16_t len, tot_len;
  
  if(pbuf_header(p, TCP_HLEN)) {
    DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_send_data: no room for TCP header in pbuf.\n"));

#ifdef TCP_STATS
    stats.tcp.err++;
#endif /* TCP_STATS */
    return;
  }

  tcphdr = p->payload;
  tcphdr->src = htons(local_port);
  tcphdr->dest = htons(dest_port);
  tcphdr->seqno = htonl(seqno);
  tcphdr->ackno = htonl(ackno);
  tcphdr->flags = flags;
  tcphdr->wnd = htons(rcv_wnd);
  tcphdr->urgp = htons(snd_up);
#ifdef HAVE_BITFIELDS
  tcphdr->offset = 5;
#else
  tcphdr->offset_unused = 5 << 4;
#endif /* HAVE_BITFIELDS */
  
  tcphdr->chksum = 0;
  tcphdr->chksum = inet_chksum_pseudo(p, local_ip, dest_ip,
				      IP_PROTO_TCP, p->tot_len);

#ifdef TCP_STATS
    stats.tcp.xmit++;
#endif /* TCP_STATS */

  len = p->len;
  tot_len = p->tot_len;
  ip_output(p, local_ip, dest_ip, TCP_TTL, IP_PROTO_TCP);
  p->len = len;
  p->tot_len = tot_len;
  p->payload = tcphdr;
  
}
/*-----------------------------------------------------------------------------------*/
void
tcp_rexmit_seg(struct tcp_pcb *pcb, struct tcp_seg *seg)
{
  u32_t wnd;
  u32_t old_ackno, old_wnd;
  u16_t len, tot_len;
  struct netif *netif;
  
  DEBUGF(TCP_REXMIT_DEBUG, ("tcp_rexmit_seg: skickar %ld:%ld\n",
			    ntohl(seg->tcphdr->seqno),
			    ntohl(seg->tcphdr->seqno) + seg->len));

  wnd = MIN(pcb->snd_wnd, pcb->cwnd);
  
  if(ntohl(seg->tcphdr->seqno) - pcb->snd_ack + seg->len <= wnd) {

    /* Count the number of retranmissions. */
    pcb->nrtx++;
    
    if((netif = ip_route((struct ip_addr *)&(pcb->dest_ip))) == NULL) {

      DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_rexmit_segment: No route to 0x%lx\n", pcb->dest_ip.addr));

#ifdef TCP_STATS
      stats.tcp.rterr++;
#endif /* TCP_STATS */

      return;
    }

    old_ackno = ntohl(seg->tcphdr->ackno);
    seg->tcphdr->ackno = htonl(pcb->rcv_nxt);
    old_wnd = ntohs(seg->tcphdr->wnd);
    seg->tcphdr->wnd = htons(pcb->rcv_wnd);

    /* Adjust checksum */

    /* XXX: for now, we just recompute it. Bad, bad, bad, since
       there are better ways (RFC1624) */
    seg->tcphdr->chksum = 0;
    seg->tcphdr->chksum = inet_chksum_pseudo(seg->p,
                                             &(pcb->local_ip),
                                             &(pcb->dest_ip),
                                             IP_PROTO_TCP, seg->p->tot_len);
    len = seg->p->len;
    tot_len = seg->p->tot_len;
    ip_output_if(seg->p, NULL, IP_HDRINCL, TCP_TTL, IP_PROTO_TCP, netif);
    seg->p->len = len;
    seg->p->tot_len = tot_len;
    seg->p->payload = seg->tcphdr;

#ifdef TCP_STATS
    stats.tcp.xmit++;
    stats.tcp.rexmit++;
#endif /* TCP_STATS */

    seg->rtime = 0;
    
    /* Don't take any rtt measurements after retransmitting. */    
    pcb->rttest = 0;
  } else {
    DEBUGF(TCP_REXMIT_DEBUG, ("tcp_rexmit_seg: no room in window %lu to send %lu (ack %lu)\n",
                              wnd, ntohl(seg->tcphdr->seqno), pcb->snd_ack));
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_rst(u32_t seqno, u32_t ackno,
	struct ip_addr *local_ip, struct ip_addr *dest_ip,
	u16_t local_port, u16_t dest_port)
{
  struct pbuf *p;
  p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
  if(p == NULL) {
    mem_reclaim(sizeof(struct pbuf));
    p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
    if(p == NULL) {
      DEBUGF(TCP_DEBUG, ("tcp_rst: could not allocate memory for pbuf\n"));
      return;
    }
  }
  tcp_output_packet(p, local_ip, dest_ip, local_port, dest_port,
		    TCP_RST | TCP_ACK, seqno, ackno,
		    0, 0);
  pbuf_free(p);
  DEBUGF(TCP_OUTPUT_DEBUG, ("tcp_rst: seqno %lu ackno %lu.\n", seqno, ackno));
}
/*-----------------------------------------------------------------------------------*/
