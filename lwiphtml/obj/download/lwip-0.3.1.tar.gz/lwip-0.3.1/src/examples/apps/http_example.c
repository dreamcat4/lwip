/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: http_example.c,v 1.6 2001/02/06 10:47:37 adam Exp $
 */

#include "lwip/mem.h"

#include "fs.h"

#include "lwip/debug.h"

#include "lwip/def.h"
#include "http_example.h"
#include "lwip/api.h"

#include "lwip/stats.h"

static void
http_input(struct netconn *conn)
{
  int i, j;
  struct netbuf *buf;
  char *data;
  int len;
  char fname[40];
  struct fs_file file;
  
  buf = netconn_recv(conn);
  if(buf != NULL) {
    netbuf_data(buf, (void *)&data, &len);
    if(strncmp(data, "GET ", 4) == 0) {
      for(i = 0; i < 40; i++) {
	if(((char *)data + 4)[i] == ' ' ||
	   ((char *)data + 4)[i] == '\r' ||
	   ((char *)data + 4)[i] == '\n') {
	  ((char *)data + 4)[i] = 0;
	}
      }
      /*      DEBUGF("http_example: %s\n", data);*/
      i = 0;
      do {
	fname[i] = "/http"[i];
	i++;
      } while(fname[i - 1] != 0 && i < 40);
      i--;
      /*      DEBUGF("http: file %s\n", fname);*/
      j = 0;
      do {
	fname[i] = ((char *)data + 4)[j];
	j++;
	i++;
      } while(fname[i - 1] != 0 && i < 40);
      if(fs_open(fname, &file)) {
	/*	DEBUGF("http: writing %s len %d\n", fname, file.len);*/
        netbuf_free(buf);
	netconn_write(conn, file.data, file.len, NETCONN_NOCOPY);         
      } else {
	/*	DEBUGF("http: file %s not found.\n", fname);*/
      }
    }
    netbuf_delete(buf);
  }
  netconn_close(conn);
}



void *
http_example_thread(void *arg)
{
  struct netconn *conn, *newconn;

  conn = netconn_new(NETCONN_TCP);
  netconn_bind(conn, NULL, 80);
  netconn_listen(conn);

  while(1) {
    newconn = netconn_accept(conn);
    http_input(newconn);
    netconn_delete(newconn);
  }

}



