/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: stats.h,v 1.4 2001/01/31 09:11:55 adam Exp $
 */
#ifndef __STATS_H__
#define __STATS_H__

#include "opt.h"

#ifdef STATS

struct stats_proto {
  unsigned int xmit;    /* Transmitted packets. */
  unsigned int rexmit;  /* Retransmitted packets. */
  unsigned int recv;    /* Received packets. */
  unsigned int fw;      /* Forwarded packets. */
  unsigned int drop;    /* Dropped packets. */
  unsigned int chkerr;  /* Checksum error. */
  unsigned int lenerr;  /* Invalid length error. */
  unsigned int memerr;  /* Out of memory error. */
  unsigned int rterr;   /* Routing error. */
  unsigned int proterr; /* Protocol error. */
  unsigned int opterr;  /* Error in options. */
  unsigned int err;     /* Misc error. */  
};

struct stats_mem {
  int avail;
  int used;
  int max;
  int err;
};


struct stats {
  struct stats_proto link;
  struct stats_proto ip;
  struct stats_proto icmp;
  struct stats_proto udp;
  struct stats_proto tcp;
  struct stats_mem mem;
  struct stats_mem pbuf;
};

extern struct stats stats;

void stats_init(void);
void stats_mem(void);

/* This macro can only be used if all *_STATS are defined. */
#define STATSF(stats) \
"Link level: transmitted %d, received %d, dropped %d\n\n\
IP packets transmitted %d, received %d, forwarded %d, dropped %d\n\
IP errors: bad checksum %d, invalid packet size %d, out of memory %d,\n\
           routing error %d, protocol error %d, options error %d, misc error %d.\n\n\
ICMP packets transmitted %d, received %d, dropped %d\n\
ICMP errors: bad checksum %d, invalid packet size %d, out of memory %d,\n\
             routing error %d, protocol error %d, options error %d, misc error %d.\n\n\
UDP packets transmitted %d, received %d, dropped %d\n\
UDP errors: bad checksum %d, invalid packet size %d, out of memory %d,\n\
            routing error %d, protocol error %d, options error %d, misc error %d.\n\n\
TCP packets transmitted %d, received %d, retransmitted %d, dropped %d\n\
TCP errors: bad checksum %d, invalid packet size %d, out of memory %d,\n\
            routing error %d, protocol error %d, options error %d, misc error %d.\n\n\
Memory statistics: avaliable %d bytes, used %d bytes, maximum %d bytes, errors %d\n\n\
Pbuf pool statistics: avaliable %d, used %d, maximum %d, errors %d\n",\
stats.link.xmit, stats.link.recv, stats.link.drop,\
stats.ip.xmit, stats.ip.recv, stats.ip.fw, stats.ip.drop,\
stats.ip.chkerr, stats.ip.lenerr, stats.ip.memerr,\
stats.ip.rterr, stats.ip.proterr, stats.ip.opterr, stats.ip.err,\
stats.icmp.xmit, stats.icmp.recv, stats.icmp.drop,\
stats.icmp.chkerr, stats.icmp.lenerr, stats.icmp.memerr,\
stats.icmp.rterr, stats.icmp.proterr, stats.icmp.opterr, stats.icmp.err,\
stats.udp.xmit, stats.udp.recv, stats.udp.drop,\
stats.udp.chkerr, stats.udp.lenerr, stats.udp.memerr,\
stats.udp.rterr, stats.udp.proterr, stats.udp.opterr, stats.udp.err,\
stats.tcp.xmit, stats.tcp.recv, stats.tcp.rexmit, stats.tcp.drop,\
stats.tcp.chkerr, stats.tcp.lenerr, stats.tcp.memerr,\
stats.tcp.rterr, stats.tcp.proterr, stats.tcp.opterr, stats.tcp.err,\
stats.mem.avail, stats.mem.used, stats.mem.max, stats.mem.err,\
stats.pbuf.avail, stats.pbuf.used, stats.pbuf.max, stats.pbuf.err
#else /* STATS */
#define STATSF(stats) "Statistics not available\n"
#endif /* STATS */

#endif /* __STATS_H__ */




