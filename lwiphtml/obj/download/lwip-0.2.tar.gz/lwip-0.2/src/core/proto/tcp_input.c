/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_input.c,v 1.11 2001/01/31 10:57:30 adam Exp $
 */

/*-----------------------------------------------------------------------------------*/
/* tcp_input.c
 *
 * The input processing functions of TCP.
 *
 */
/*-----------------------------------------------------------------------------------*/

#include "debug.h"

#include "def.h"
#include "opt.h"

#include "netif.h"
#include "mem.h"

#include "inet.h"
#include "tcp.h"

#include "stats.h"

#include "perf.h"

/* Forward declarations. */
static void tcp_process(struct tcp_seg *seg, struct tcp_pcb *pcb);
static void tcp_receive(struct tcp_seg *seg, struct tcp_pcb *pcb);

/*-----------------------------------------------------------------------------------*/
/* tcp_input:
 *
 * The initial input processing of TCP. It verifies the TCP header, demultiplexes
 * the segment between the PCBs and passes it on to tcp_process, which implements
 * the TCP finite state machine.
 */
/*-----------------------------------------------------------------------------------*/
void
tcp_input(struct pbuf *p)
{
  struct tcp_hdr *tcphdr;
  struct tcp_pcb *pcb, *prev, *pcbmatch, *pcbmatch2;
  struct tcp_seg *seg;
  struct ip_hdr *iphdr;
  u8_t offset;
  
  PERF_START;
  
#ifdef TCP_STATS
  stats.tcp.recv++;
#endif /* TCP_STATS */
  
  tcphdr = p->payload;
  iphdr = (struct ip_hdr *)((int)p->payload - IP_HLEN);

  /*  tcp_debug_print(tcphdr);*/
  /*  DEBUGF("tcphdr->src %d, tcphdr->dest %d\n", ntohs(tcphdr->src),
      ntohs(tcphdr->dest));*/
  

  /* verify checksum */
  if(inet_chksum_pseudo(p, (struct ip_addr *)&(iphdr->src),
			(struct ip_addr *)&(iphdr->dest),
			IP_PROTO_TCP, p->tot_len) != 0) {
    DEBUGF(TCP_INPUT_DEBUG, ("tcp_input: packet discarded due to failing checksum\n"));
#ifdef TCP_STATS
    stats.tcp.chkerr++;
    stats.tcp.drop++;
#endif /* TCP_STATS */
    return;
  }
#ifdef HAVE_BITFIELDS
  offset = tcphdr->offset;
#else
  offset = tcphdr->offset_unused >> 4;
#endif /* HAVE_BITFIELDS */
  pbuf_header(p, -(offset * 4));

  /* Convert fields in TCP header to host byte order. */
  tcphdr->src = ntohs(tcphdr->src);
  tcphdr->dest = ntohs(tcphdr->dest);
  tcphdr->seqno = ntohl(tcphdr->seqno);
  tcphdr->ackno = ntohl(tcphdr->ackno);
  tcphdr->wnd = ntohs(tcphdr->wnd);
  
  /* set up a tcp_seg structure */
  seg = mem_malloc(sizeof(struct tcp_seg_in));
  if(seg == NULL) {
#ifdef TCP_STATS
    stats.tcp.memerr++;
    stats.tcp.drop++;
#endif /* TCP_STATS */

    pbuf_free(p);
    return;
  }
  seg->next = NULL;
  seg->len = p->tot_len;
  seg->data = p->payload;
  seg->p = p;
  seg->tcphdr = tcphdr;

  if(tcphdr->flags & TCP_FIN || tcphdr->flags & TCP_SYN) {
    seg->len++;
  }

  pcbmatch = pcbmatch2 = NULL;

  /*  tcp_debug_print_pcbs();*/

  /*  ASSERT(tcp_pcbs->next != NULL);*/
  
  /* demultiplex */
  prev = NULL;
  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {
    ASSERT("tcp_input: pcb->state != CLOSED", pcb->state != CLOSED);
    if(pcb->state != LISTEN &&
       ip_addr_cmp(&(pcb->dest_ip), &(iphdr->src)) &&
       pcb->dest_port == tcphdr->src &&
       pcb->local_port == tcphdr->dest) {
      /*      pcbmatch = pcb;*/

      /* Move this PCB to the front of the list. */
      if(prev != NULL) {
        prev->next = pcb->next;
        pcb->next = tcp_pcbs;
        tcp_pcbs = pcb; 
      }
      break;
    } else if(pcb->state == LISTEN &&
              (ip_addr_isany(&(pcb->local_ip)) ||
               ip_addr_cmp(&(pcb->local_ip), &(iphdr->dest))) &&
              pcb->local_port == tcphdr->dest) {
      pcbmatch = pcb;
    }
    prev = pcb;
  }

#if TCP_INPUT_DEBUG
  /*  DEBUGF("+-+-+-+-+-+-+-+-+-+-+-+-+-+- tcp_input: flags ");
  tcp_debug_print_flags(tcphdr->flags);
  DEBUGF("-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n");
  tcp_debug_print(tcphdr); */
#endif /* TCP_INPUT_DEBUG */

  if(pcb == NULL && pcbmatch != NULL) {
    pcb = pcbmatch;
  }
  
  if(pcb != NULL) {
#if TCP_INPUT_DEBUG
#if TCP_DEBUG
    tcp_debug_print_state(pcb->state);
#endif /* TCP_DEBUG */
#endif /* TCP_INPUT_DEBUG */
    tcp_process(seg, pcb);
#if TCP_INPUT_DEBUG
#if TCP_DEBUG
    tcp_debug_print_state(pcb->state);
#endif /* TCP_DEBUG */
#endif /* TCP_INPUT_DEBUG */
    
  } else {
    if(!(tcphdr->flags & TCP_RST)) {
      tcp_rst(0, tcphdr->seqno + seg->len,
	      &(iphdr->dest), &(iphdr->src),
              tcphdr->dest, tcphdr->src);
#ifdef TCP_STATS
      stats.tcp.proterr++;
      stats.tcp.drop++;
#endif /* TCP_STATS */
    }
  }
  tcp_seg_free(seg);

  PERF_STOP("tcp_input");
}
/*-----------------------------------------------------------------------------------*/
/* tcp_process
 *
 * Implements the TCP state machine. Called by tcp_input. In some states tcp_receive
 * is called to receive data.
 */
/*-----------------------------------------------------------------------------------*/
static void
tcp_process(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  struct tcp_pcb *npcb;
  struct ip_hdr *iphdr;
  struct tcp_hdr *tcphdr;
  u32_t seqno, ackno, iss;
  u8_t flags;
  char optdata[4];
  struct tcp_seg *rseg;
  
  iphdr = (struct ip_hdr *)((char *)seg->tcphdr - IP_HLEN);
  tcphdr = seg->tcphdr;
  flags = tcphdr->flags;
  seqno = tcphdr->seqno;
  ackno = tcphdr->ackno;
  
  /*  tcp_debug_print_state(pcb->state);*/

  if(flags & TCP_RST) {
    int acceptable = 0;
    if(pcb->state != LISTEN) {
      if(pcb->state == SYN_SENT) {
	if(ackno == pcb->snd_nxt) {
	  acceptable = 1;
	}
      } else {
	if(TCP_SEQ_GEQ(seqno, pcb->rcv_nxt) &&
	   TCP_SEQ_LEQ(seqno, pcb->rcv_nxt + pcb->rcv_wnd)) {
	  acceptable = 1;
	}
      }
    }
    if(acceptable) {
      DEBUGF(TCP_INPUT_DEBUG, ("tcp_process: Connection RESET\n"));

      /* Do not send any delayed ACK. */
      pcb->flags &= ~TCP_ACK_NEXT;
      tcp_pcb_remove(pcb);
      return;
    } else {
      DEBUGF(TCP_INPUT_DEBUG, ("tcp_process: unacceptable reset seqno %lu rcv_nxt %lu\n",
	     seqno, pcb->rcv_nxt));
    }
  }

  switch(pcb->state) {
    /* ------- CLOSED ------- */
  case CLOSED:
    break;
    /* ------- LISTEN ------- */
  case LISTEN:
    if(flags & TCP_ACK) {
      tcp_rst(ackno + 1, seqno + seg->len,
	      &(iphdr->dest), &(iphdr->src),
	      tcphdr->dest, tcphdr->src);
    } else if(flags & TCP_SYN) {      
      npcb = tcp_pcb_new();
      if(npcb == NULL) {
#ifdef TCP_STATS
        stats.tcp.memerr++;
#endif /* TCP_STATS */
	break;
      }
      ip_addr_set(&(npcb->local_ip), &(iphdr->dest));
      npcb->local_port = pcb->local_port;
      ip_addr_set(&(npcb->dest_ip), &(iphdr->src));
      npcb->dest_port = tcphdr->src;
      npcb->state = SYN_RCVD;
      npcb->rcv_nxt = seqno + 1;
      npcb->snd_wnd = tcphdr->wnd;
      iss = tcp_next_iss();
      npcb->snd_nxt = iss;
      npcb->snd_ack = iss;
      npcb->snd_lbb = iss;
      npcb->mss = TCP_MSS;
      npcb->cwnd = npcb->mss;
      npcb->ssthresh = npcb->mss * 10;
      npcb->accept = pcb->accept;
      npcb->accept_arg = pcb->accept_arg;
      
      tcp_register(npcb);
      
      /* Build an MSS option */
      optdata[0] = 2;   /* option kind (MSS) */
      optdata[1] = 4;   /* option length */
      optdata[2] = npcb->mss / 256;
      optdata[3] = npcb->mss & 255;
      tcp_enqueue(npcb, NULL, 0, TCP_SYN | TCP_ACK, 0, optdata, 4);
    }  
    break;
    /* ------- SYN_SENT ------- */
  case SYN_SENT:
    DEBUGF(TCP_INPUT_DEBUG, ("SYN-SENT: ackno %lu pcb->snd_nxt %lu unacked %lu\n", ackno,
	   pcb->snd_nxt, ntohl(pcb->unacked->tcphdr->seqno)));
    if(flags & TCP_ACK &&
       flags & TCP_SYN &&
       ackno == ntohl(pcb->unacked->tcphdr->seqno) + 1) {
      pcb->rcv_nxt = seqno + 1;
      pcb->rcv_wnd = tcphdr->wnd;
      pcb->state = ESTABLISHED;
      pcb->cwnd = pcb->mss;
      rseg = pcb->unacked;
      pcb->unacked = rseg->next;
      tcp_seg_free(rseg);
      tcp_ack_now(pcb);
      tcp_output(pcb);
    }    
    break;
    /* ------- SYN_RCVD ------- */
  case SYN_RCVD:
    if(flags & TCP_ACK &&
       !(flags & TCP_RST)) {
      /*      DEBUGF("SYN_RCVD: pcb->snd_una %lu, ack %lu, pcb->snd_nxt %lu\n",
	      pcb->snd_una, ackno, pcb->snd_nxt);*/
      if(TCP_SEQ_LT(pcb->snd_ack, ackno) &&
	 TCP_SEQ_LEQ(ackno, pcb->snd_nxt)) {
	tcp_receive(seg, pcb);
        pcb->state = ESTABLISHED;
	pcb->cwnd = pcb->mss;
        /* Call the accept function. */
        if(pcb->accept != NULL) {
          pcb->accept(pcb->accept_arg, pcb);
        }
      }	
    }  
    break;
    /* ------- ESTABLISHED ------- */
  case CLOSE_WAIT:
  case ESTABLISHED:
    /*
      
          If SND.UNA < SEG.ACK =< SND.NXT, the send window should be
          updated.  If (SND.WL1 < SEG.SEQ or (SND.WL1 = SEG.SEQ and
          SND.WL2 =< SEG.ACK)), set SND.WND <- SEG.WND, set
          SND.WL1 <- SEG.SEQ, and set SND.WL2 <- SEG.ACK.

          Note that SND.WND is an offset from SND.UNA, that SND.WL1
          records the sequence number of the last segment used to update
          SND.WND, and that SND.WL2 records the acknowledgment number of
          the last segment used to update SND.WND.  The check here
          prevents using old segments to update the window.
    */
    if(TCP_SEQ_LT(pcb->snd_ack, ackno) &&
       TCP_SEQ_LEQ(ackno, pcb->snd_nxt) &&
       (TCP_SEQ_LT(pcb->snd_wl1, seqno) ||
	(pcb->snd_wl1 == seqno &&
	 TCP_SEQ_LEQ(pcb->snd_wl2, ackno)))) {
      pcb->snd_wnd = seg->tcphdr->wnd;
      pcb->snd_wl1 = seqno;
      pcb->snd_wl2 = ackno;
    }

    tcp_receive(seg, pcb);	  
    if(flags & TCP_FIN) {
      pcb->state = CLOSE_WAIT;
    }
    break;
  case FIN_WAIT_1:
    tcp_receive(seg, pcb);
    if(flags & TCP_FIN) {
      if(flags & TCP_ACK && ackno == pcb->snd_nxt) {
	pcb->state = TIME_WAIT;
	tcp_ack_now(pcb);
	tcp_pcb_purge(pcb);
        pcb->tmr = 0;
      } else {
	pcb->state = CLOSING;
      }
    } else if(flags & TCP_ACK && ackno == pcb->snd_nxt) {
      pcb->state = FIN_WAIT_2;
    }
    break;
  case FIN_WAIT_2:
    tcp_receive(seg, pcb);
    if(flags & TCP_FIN) {
      tcp_ack_now(pcb);
      tcp_pcb_purge(pcb);
      mem_realloc(pcb, sizeof(struct tcp_pcb_tw));
      pcb->state = TIME_WAIT;
      pcb->tmr = 0;
    }
    break;
  case CLOSING:
    tcp_receive(seg, pcb);	  
    if(flags & TCP_ACK && ackno == pcb->snd_nxt) {
      tcp_ack_now(pcb);
      tcp_pcb_purge(pcb);
      mem_realloc(pcb, sizeof(struct tcp_pcb_tw));
      pcb->state = TIME_WAIT;
      pcb->tmr = 0;
    }
    break;
  case LAST_ACK:
    tcp_receive(seg, pcb);
    if(flags & TCP_ACK && ackno == pcb->snd_nxt) {
      tcp_pcb_remove(pcb);
    }
    break;
  case TIME_WAIT:
    /*    DEBUGF("tcp_process: TIME-WAIT\n");*/
    tcp_rst(ackno + 1, seqno + seg->len,
	    &(iphdr->dest), &(iphdr->src),
	    tcphdr->dest, tcphdr->src);
    pcb->tmr = 0;
    break;
  }
#if TCP_DEBUG
  if(pcb != NULL) {
    tcp_debug_print_state(pcb->state);
  }
#endif /* TCP_DEBUG */
}

/*-----------------------------------------------------------------------------------*/
/* tcp_receive:
 *
 * Called by tcp_process. Checks if the given segment is an ACK for outstanding
 * data, and if so frees the memory of the buffered data. Next, is places the
 * segment on any of the receive queues (pcb->recved or pcb->ooseq). If the segment
 * is buffered, the pbuf is referenced by pbuf_ref so that it will not be freed until
 * i it has been removed from the buffer.
 *
 * If the incoming segment constitutes an ACK for a segment that was used for RTT
 * estimation, the RTT is estimated here as well.
 */
/*-----------------------------------------------------------------------------------*/
static void
tcp_receive(struct tcp_seg *seg, struct tcp_pcb *pcb)
{
  struct tcp_seg *next, *prev;
  u32_t ackno, seqno;
  int m;

  ackno = seg->tcphdr->ackno;
  seqno = seg->tcphdr->seqno;


  /*  DEBUGF("tcp_receive: ACK for %lu\n", ackno);
      tcp_debug_print_flags(seg->tcphdr->flags);*/
  if(seg->tcphdr->flags & TCP_ACK) {

    if(pcb->lastack == ackno) {
      pcb->dupacks++;
      if(pcb->dupacks >= 3 && pcb->unacked != NULL) {
	/* This is fast retransmit. Retransmit the first unacked segment. */
	tcp_rexmit_seg(pcb, pcb->unacked);
	DEBUGF(TCP_FR_DEBUG, ("tcp_receive: dupacks %d (%lu), fast retransmit %lu\n",
	       pcb->dupacks, pcb->lastack,
	       ntohl(pcb->unacked->tcphdr->seqno)));
	
	pcb->cwnd = pcb->ssthresh + 3 * pcb->mss;
	pcb->flags |= TCP_INFR;
      } else if(pcb->flags & TCP_INFR) {	
	pcb->cwnd += pcb->mss;
      }
    } else {

      if(pcb->flags & TCP_INFR) {
	pcb->flags &= ~TCP_INFR;
	pcb->cwnd = pcb->ssthresh;
      }
      
      pcb->dupacks = 0;
      pcb->lastack = ackno;    

      if(TCP_SEQ_LT(pcb->snd_ack, ackno) &&
	 TCP_SEQ_LEQ(ackno, pcb->snd_nxt)) {
	pcb->snd_ack = ackno;
	if(pcb->state >= ESTABLISHED) {
	  if(pcb->cwnd < pcb->ssthresh) {
	    pcb->cwnd += pcb->mss;
	    DEBUGF(TCP_CWND_DEBUG, ("tcp_receive: slow start cwnd %lu\n", pcb->cwnd));
	  } else {
	    pcb->cwnd += pcb->mss * pcb->mss / pcb->cwnd;
	    DEBUGF(TCP_CWND_DEBUG, ("tcp_receive: congestion avoidance cwnd %lu\n", pcb->cwnd));

	  }
	}
	
      }
      
      /* remove segment from the unacknowledged list */
      DEBUGF(TCP_INPUT_DEBUG, ("tcp_receive: ACK for %lu, unacked->seqno %lu:%lu\n",
                               ackno,
                               pcb->unacked != NULL?
                               ntohl(pcb->unacked->tcphdr->seqno): 0,
                               pcb->unacked != NULL?
                               ntohl(pcb->unacked->tcphdr->seqno) + pcb->unacked->len: 0));
      while(pcb->unacked != NULL &&
	    TCP_SEQ_LEQ(ntohl(pcb->unacked->tcphdr->seqno) + pcb->unacked->len,
                        ackno)) {
	DEBUGF(TCP_INPUT_DEBUG, ("tcp_receive: removing %lu:%lu from pcb->unacked\n",
	       ntohl(pcb->unacked->tcphdr->seqno),
	       ntohl(pcb->unacked->tcphdr->seqno) +
	       pcb->unacked->len));

	next = pcb->unacked->next;
	tcp_seg_free(pcb->unacked);
	pcb->unacked = next;
      }
    }
    DEBUGF(TCP_RTO_DEBUG, ("tcp_receive: pcb->rttest %d rtseq %lu ackno %lu\n",
	   pcb->rttest, pcb->rtseq, ackno));
    
    /* RTT estimation calculations */
    if(pcb->rttest && TCP_SEQ_LT(pcb->rtseq, ackno)) {
      m = tcp_ticks - pcb->rttest;

      DEBUGF(TCP_RTO_DEBUG, ("tcp_receive: experienced rtt %d ticks (%d msec).\n",
	     m, m * TCP_COARSE_TIMEOUT));

      /* This is taken directly from VJs original code in his paper */      
      m = m - (pcb->sa >> 3);
      pcb->sa += m;
      if(m < 0) {
	m = -m;
      }
      m = m - (pcb->sv >> 2);
      pcb->sv += m;
      pcb->rto = (pcb->sa >> 3) + pcb->sv;
      
      DEBUGF(TCP_RTO_DEBUG, ("tcp_receive: RTO %d (%d miliseconds)\n",
			     pcb->rto, pcb->rto * TCP_COARSE_TIMEOUT));

      pcb->rttest = 0;
    } 

  }
  

  /*  DEBUGF("tcp_receive: len %d seqno %lu ackno %lu\n",
	 seg->len, ntohl(seg->tcphdr->seqno),
	 ntohl(seg->tcphdr->ackno));*/
  
  /* put segment of recved queue if len > 0 */
  if(seg->len > 0) {

    /* Segment must atlest be above rcv_nxt in order
       to be further processed. */
    if(TCP_SEQ_GT(seqno + seg->len, pcb->rcv_nxt)) {
      
      /* Trim the edges, start with the first. */
      if(TCP_SEQ_LT(seqno, pcb->rcv_nxt)) {
        seg->data = (void *)((char *)seg->data + pcb->rcv_nxt - seqno);
      }
      /* Trim the second edge */
      next = pcb->ooseq;
      while(next != NULL &&
	    TCP_SEQ_LT(next->tcphdr->seqno, pcb->rcv_wnd)) {
        next = next->next;
      }
      if(next) {
        if(TCP_SEQ_GT(seqno + seg->len, next->tcphdr->seqno)) {
          seg->len -= next->tcphdr->seqno - seqno;
        }
      }
    
      /* Update the receiver's (our) window. */
      if(pcb->rcv_wnd < seg->len) {
	pcb->rcv_wnd = 0;
      } else {
	pcb->rcv_wnd -= seg->len;
      }
      
      if(seqno == pcb->rcv_nxt) {
        /* This segment is the next in-sequence segment expected. */

        /* We have to update rcv_nxt. */
        pcb->rcv_nxt += seg->len;

	if(pcb->recv != NULL) {
	  /* Pass it to receiver's function, if there is
	     data in the pbuf. */
	  if(seg->p->tot_len > 0) {
	    pcb->recv(pcb->recv_arg, pcb, seg->p);
	    seg->p = NULL;
	  } else {            
	    /* This is a FIN, send NULL to receiever. */
            DEBUGF(TCP_INPUT_DEBUG, ("tcp_receive: received FIN, passing NULL\n"));
	    pcb->recv(pcb->recv_arg, pcb, NULL);
	  }
	}
	 
	

	/* Check if we have out of sequence data that
	   now is in sequence because of the incoming segment. */
#ifndef WITH_PROXY_SUPPORT
        next = pcb->ooseq;
        while(next != NULL && next->tcphdr->seqno == pcb->rcv_nxt) {
          pcb->rcv_nxt += next->len;

	  pcb->ooseq = next->next;
	  if(pcb->recv != NULL) {
	    pcb->recv(pcb->recv_arg, pcb, next->p);
	    next->p = NULL;
	  }
	  tcp_seg_free(next);
	}
#endif /* WITH_PROXY_SUPPORT */
	/* Acknowlegde the received segment. */
	tcp_ack(pcb);

      } else {
        /* This is an out of order segment */
#ifndef WITH_PROXY_SUPPORT
	pbuf_ref(seg->p);
        if(pcb->ooseq == NULL) {
          pcb->ooseq = seg;
        } else {
          prev = pcb->ooseq;
          while(prev->next != NULL &&
                TCP_SEQ_LT(prev->tcphdr->seqno, seqno)) {
            prev = prev->next;
          }
          seg->next = prev->next;
          prev->next = seg;
        }
#endif /* WITH_PROXY_SUPPORT */
       	/* Generate an immediate acknowledgement that triggers
	   fast retransmit in the remote end. */
	tcp_ack_now(pcb);
      }
    }
  }


  /* It the incoming segment was an ACK for outstanding data, the window
     has been opened and we can send more data. Therefore, call tcp_output. */
  tcp_output(pcb);
}
/*-----------------------------------------------------------------------------------*/


