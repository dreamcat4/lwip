/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: sys_arch.c,v 1.3 2001/01/31 09:11:40 adam Exp $
 */

#include "debug.h"

#include "def.h"
#include "sys.h"
#include "dlist.h"

#include "rtxcapi.h"
#include "csema.h"
#include "cqueue.h"

/*static struct irq_s *irqs;*/
/*static struct dlist *timeouts;*/
static struct sys_thread *threads = NULL;

static struct sem *semfree = NULL;

struct timeoutlist {
  struct timeoutlist *next;
  struct dlist *timeouts;
  TASK pid;
};

static struct timeoutlist *timeoutlist = NULL;

struct timeout_s {
  sys_timeout_handler h;
  void *data;
};

struct irq_s {
  struct irq_s *next;
  sys_irq_handler h;
  int fd;
  void *data;
};

static struct timeval starttime;
/*-----------------------------------------------------------------------------------*/
sys_mbox_t
sys_mbox_new()
{
  QUEUE mbox;  
  KS_dequeuew(SYSMBOXQ, &mbox);
  KS_purgequeue(mbox);
  return mbox;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(sys_mbox_t mbox)
{
  KS_enqueue(SYSMBOXQ, &mbox);
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(sys_mbox_t mbox, void *data)
{
  KS_enqueue(mbox, data);
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_fetch(sys_mbox_t mbox, void **data)
{
  KS_dequeuew(mbox, *data);
}
/*-----------------------------------------------------------------------------------*/
sys_sem_t
sys_sem_new(int count)
{
  SEMA sem;
  KS_dequeuew(SYSSEMQ, &sem);
  KS_pend(sem);
  if(count > 0) {
    KS_signal(sem);
  }
  return sem;
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_wait(sys_sem_t sem)
{
  unsigned int ticks;
  struct dlist *timeouts;
  struct timeout_s *timeout_s;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;

  if(timeoutlist == NULL) {
    timeouts = NULL;    
  } else {
    pid = KS_inqtask();
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
  
  
  if(timeouts == NULL || dlist_is_empty(timeouts)) {
    KS_wait(sem);
  } else {  
    ticks = dlist_first(timeouts, (void **)&timeout_s);
    ret = KS_waitt(sem, (TICKS)ticks/CLKTICK);
    
    if(ret = RC_TIMEOUT) {
      do {
	timeout_s = dlist_remove(timeouts);
	timeout_s->h(timeout_s->data);
	mem_free(timeout_s);
	if(!dlist_is_empty(timeouts)) {
	  ticks = dlist_first(timeouts, (void **)&timeout_s);
	}
      } while(!dlist_is_empty(timeouts) && ticks == 0);
    }
  }
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(sys_sem_t sem)
{
  KS_signal(sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(sys_sem_t sem)
{
  KS_enqueue(SYSSEMQ, &sem);
}
/*-----------------------------------------------------------------------------------*/
void
sys_timeout(unsigned int msecs, sys_timeout_handler h, void *data)
{
  struct dlist *timeouts;
  struct timeout_s *t;
  struct timeoutlist *tl;
  KSRC ret;
  TASK pid;

  pid = KS_inqtask();
  
  if(timeoutlist == NULL) {
    timeouts = NULL;    
  } else {
    for(tl = timeoutlist; tl != NULL; tl = tl->next) {
      if(tl->pid == pid) {
	timeouts = tl->timeouts;
	break;
      }
    }
  }
  
  if(timeouts == NULL) {
    timeouts = dlist_new();
    tl = mem_malloc(sizeof(struct timeoutlist));
    tl->pid = pid;
    tl->timeouts = timeouts;
    
    KS_lockw(SYSTLOCK);
    tl->next = timeoutlist;    
    timeoutlist = tl;
    KS_unlock(SYSTLOCK);
  }
  
  t = mem_malloc(sizeof(struct timeout_s));
  t->h = h;
  t->data = data;
  dlist_insert(timeouts, t, msecs);  
}
/*-----------------------------------------------------------------------------------*/
void
sys_init()
{
  /* posta in alla semaforer i SYSSEMQ, posta in alla mboxar i
     SYSMBOXQ */
}

/*-----------------------------------------------------------------------------------*/







