/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_proxy.c,v 1.8 2001/01/31 09:12:22 adam Exp $
 */

#include "debug.h"

#include "def.h"
#include "mem.h"

#include "stats.h"

#include "netif.h"
#include "inet.h"
#include "ip_proxy.h"
#include "tcp_proxy.h"

#include "sys.h"

struct tcp_pcb *tcp_pcbs;
unsigned long tcp_ticks;

#ifdef TCP_PROXY_DEBUG
char *tcp_states[] = {
  "CLOSED",
  "SYN_SENT_1",
  "SYN_SENT_2",  
  "SYN_RCVD_1",
  "SYN_RCVD_2",
  "SYN_RCVD_3",
  "ESTABLISHED",
  "FIN_WAIT_1",
  "FIN_WAIT_2",
  "FIN_WAIT_3",
  "CLOSE_WAIT",
  "CLOSING_1",
  "CLOSING_2",
  "TIME_WAIT"};
#endif /* TCP_PROXY_DEBUG */

#define MIN(x,y) (x) < (y)? (x): (y)

/*-----------------------------------------------------------------------------------*/
void
tcp_input(struct pbuf *p, struct netif *inp)
{
  switch(inp->flags) {
  case NETIF_WIRELESS:
    tcp_input_from_wl(p);
    break;
  case NETIF_WIRED:
    tcp_input_from_net(p);
    break;
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_receive_ack(struct tcp_seg *seg, struct tcp_pcb_host *pcb,
		struct tcp_pcb_host *otherpcb, int rtt)
{
  struct tcp_seg *rseg;
  int m;
  
  if(pcb->lastack == seg->ackno) {
    pcb->dupacks++;
    if(pcb->dupacks >= 3 && otherpcb->buffer &&
       TCP_SEQ_LT(seg->ackno, otherpcb->buffer->seqno)) {
      /* This is fast retransmit. Retransmit the first unacked segment. */
      tcp_rexmit_seg(pcb, otherpcb->buffer);

      DEBUGF(TCP_PROXY_DEBUG, ("tcp_receive: dupacks %d (%lu), fast retransmit %lu\n",
			       pcb->dupacks, pcb->lastack,
			       otherpcb->buffer->seqno));
      
      pcb->cwnd = pcb->ssthresh + 3 * pcb->mss;
      pcb->flags |= TCP_INFR;
    } else if(pcb->flags & TCP_INFR) {	
      pcb->cwnd += pcb->mss;
    }
  } else {
    
    if(pcb->flags & TCP_INFR) {
      pcb->flags &= ~TCP_INFR;
      pcb->cwnd = pcb->ssthresh;
    }
  
    pcb->lastack = seg->ackno;    
    
    
    /* update rcv */
    if(TCP_SEQ_GT(seg->ackno, pcb->rcv)) {
      pcb->rcv = seg->ackno;
    }

    /* Remove segment from the unacknowledged list of the other host. */  
    while(otherpcb->buffer != NULL &&
	  TCP_SEQ_LT(otherpcb->buffer->seqno + seg->len, seg->ackno)) {    
      DEBUGF(TCP_PROXY_DEBUG, ("tcp_receive_ack: removing %lu:%lu\n",
			       otherpcb->buffer->seqno, 
			       otherpcb->buffer->seqno +
			       otherpcb->buffer->len));

      rseg = otherpcb->buffer->next;      
      tcp_seg_free(otherpcb->buffer);    
      otherpcb->buffer = rseg;
    }

    if(rtt) {
      DEBUGF(TCP_PROXY_RTO_DEBUG, ("tcp_receive: pcb->rttest %d rtseq %lu ackno %lu\n",
				   pcb->rttest, pcb->rtseq, seg->ackno));
      
      /* RTT estimation calculations */
      if(pcb->rttest && TCP_SEQ_LT(pcb->rtseq, seg->ackno)) {
	m = tcp_ticks - pcb->rttest;
	
	DEBUGF(TCP_PROXY_RTO_DEBUG, ("tcp_receive: experienced rtt %d ticks (%d msec).\n",
				     m, m * TCP_COARSE_TIMEOUT));
	
	/* This is taken directly from VJs original code in his paper */
	m -= (pcb->sa >> 3);
	pcb->sa += m;
	if(m < 0) {
	  m = -m;
	}
	m -= (pcb->sv >> 2);
	pcb->sv += m;
	pcb->rto = (pcb->sa >> 3) + pcb->sv;
      
	DEBUGF(TCP_PROXY_RTO_DEBUG, ("tcp_receive: RTO %d (%d miliseconds)\n",
				     pcb->rto, pcb->rto * TCP_COARSE_TIMEOUT));
	pcb->rttest = 0;
      }
    }  


  }
}
/*-----------------------------------------------------------------------------------*/
int
tcp_receive_seg(struct tcp_seg *seg, struct tcp_pcb_host *pcb,
                int buffer, int ooseq)
{
  struct tcp_seg *rseg, *prev;
  unsigned long seqno;

  seqno = seg->seqno;
  
  /* Segment must atlest be above next expected seqno (pcb->snd)
     in order to be further processed. */
  if(TCP_SEQ_GT(seqno + seg->len, pcb->snd)) {
    
    /* Update the receiver's (our) window. */
    /*      if(pcb->wnd < seg->len) {
            pcb->wnd = 0;
            } else {
            pcb->wnd -= seg->len;
            }*/
      
    if(seqno == pcb->snd) {
      /* This segment is the next in-sequence segment expected. */
      
      if(buffer) {          
        pbuf_ref(seg->p);
      }
      seg->next = NULL;
      if(pcb->buffer == NULL) {
        if(buffer) {
          pcb->buffer = seg;
        }
        pcb->snd = seqno + seg->len;
        DEBUGF(TCP_PROXY_DEBUG, ("tcp_receive_seg: 1, pcb->snd %lu\n",
                                 pcb->snd));
      } else {
        for(rseg = pcb->buffer; rseg != NULL; rseg = rseg->next) {
          if(TCP_SEQ_LT(rseg->seqno, seqno) &&
             rseg->next == NULL) {
            if(buffer) {
              rseg->next = seg;
            }
            pcb->snd = seqno + seg->len;
            DEBUGF(TCP_PROXY_DEBUG, ("tcp_receive_seg: 2, pcb->snd %lu\n",
                                     pcb->snd));
            break;
          } else if(TCP_SEQ_LT(rseg->seqno, seqno) &&
                    TCP_SEQ_GT(rseg->next->seqno, seqno)) {
            if(buffer) {
              seg->next = rseg->next;
              rseg->next = seg;
            }
            if(pcb->snd == seqno) {
              pcb->snd += seg->len;
              DEBUGF(TCP_PROXY_DEBUG, ("tcp_receive_seg: 3, pcb->snd %lu\n",
                                       pcb->snd));

            }
            break;
          }
        }                    
      }
    } else {
      if(ooseq) {
        /* This is an out of order segment and should be buffered */
        pbuf_ref(seg->p);
        if(pcb->ooseq == NULL) {
          pcb->ooseq = seg;
        } else {
          prev = pcb->ooseq;
          while(prev->next != NULL &&
                TCP_SEQ_LT(prev->seqno, seqno)) {
            prev = prev->next;
          }
          seg->next = prev->next;
          prev->next = seg;
        }
      }
      return 1;
    }
   
  }
  return 0;


  /*  if(buffer) {
      pbuf_ref(seg->p);
      }
      seg->next = NULL;
      if(pcb->buffer == NULL) {
      if(buffer) {
      pcb->buffer = seg;
      }
      pcb->snd = seg->seqno + seg->len;
      } else {
      for(rseg = pcb->buffer; rseg != NULL; rseg = rseg->next) {
      if(TCP_SEQ_LT(rseg->seqno, seg->seqno) &&
      rseg->next == NULL) {
      if(buffer) {
      rseg->next = seg;
      }
      pcb->snd = seg->seqno + seg->len;
      break;
      } else if(TCP_SEQ_LT(rseg->seqno, seg->seqno) &&
      TCP_SEQ_GT(rseg->next->seqno, seg->seqno)) {
      seg->next = rseg->next;
      if(pcb->snd == seg->seqno) {
      pcb->snd += seg->len;
      }
      break;
      }
      }
      }
      return 0;*/
}
/*-----------------------------------------------------------------------------------*/
/* tcp_time_wait_kill():
 *
 * Kills the connection in the wireless client by sending it an RST segment. Used
 * when the connection has gone into TIME-WAIT in the client.
 */
/*-----------------------------------------------------------------------------------*/
void
tcp_time_wait_kill(struct tcp_pcb *pcb)
{
  DEBUGF(TCP_PROXY_DEBUG, ("tcp_time_wait_kill: Killing TIME-WAIT in client.\n"));
  tcp_rst(pcb->net.snd, pcb->net.rcv, &(pcb->net.ip), &(pcb->wl.ip),
          pcb->net.port, pcb->wl.port);
}
/*-----------------------------------------------------------------------------------*/
void
tcp_segs_free(struct tcp_seg *seg)
{
  if(seg != NULL) {
    tcp_segs_free(seg->next);
    tcp_seg_free(seg);
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_seg_free(struct tcp_seg *seg)
{
  if(seg != NULL) {
    if(pbuf_free(seg->p) != 0) {
      mem_free(seg);
    }
  }
}
/*-----------------------------------------------------------------------------------*/
void
tcp_pcb_purge(struct tcp_pcb *pcb)
{
  tcp_segs_free(pcb->net.buffer);
  tcp_segs_free(pcb->wl.buffer);  
  pcb->wl.buffer = pcb->net.buffer = NULL;
}
/*-----------------------------------------------------------------------------------*/
struct tcp_pcb *
tcp_pcb_new(void)
{
  struct tcp_pcb *pcb;
  pcb = mem_malloc(sizeof(struct tcp_pcb));
  bzero(pcb, sizeof(struct tcp_pcb));
#if TCP_PROXY_DEBUG
  pcb->deadbeef[0] = 'p';
  pcb->deadbeef[1] = 'c';
  pcb->deadbeef[2] = 'b';
#endif /* TCP_PROXY_DEBUG */

  pcb->next = tcp_pcbs;
  tcp_pcbs = pcb;
  pcb->net.cwnd = 1;
  pcb->wl.cwnd = 1;
  pcb->wl.rto = 3000 / TCP_COARSE_TIMEOUT;
  pcb->wl.sa = 0;
  pcb->wl.sv = 3000 / TCP_COARSE_TIMEOUT;
  pcb->net.rto = 3000 / TCP_COARSE_TIMEOUT;
  pcb->net.sa = 0;
  pcb->net.sv = 3000 / TCP_COARSE_TIMEOUT;
  pcb->net.buffer = pcb->wl.buffer = NULL;
  
  return pcb;
}
/*-----------------------------------------------------------------------------------*/
static void
tcp_timer_coarse(void *data)
{
  struct tcp_pcb *pcb, *pcb2, *prev;
  struct tcp_seg *seg;
  int pcb_remove;      /* flag if a PCB was removed */

  tcp_ticks++;
    
  prev = NULL;
  /* Steps through all of the PCBs. */
  pcb = tcp_pcbs;
  while(pcb != NULL) {

#if TCP_PROXY_DEBUG
    ASSERT("tcp_timer_coarse: pcb deadbeef",
	   pcb->deadbeef[0] == 'p' &&
	   pcb->deadbeef[1] == 'c' &&
	   pcb->deadbeef[2] == 'b');
#endif /* TCP_PROXY_DEBUG */
    
    /* check if we need to do any retransmissions */
    for(seg = pcb->wl.buffer; seg != NULL; seg = seg->next) {
      seg->rtime++;
      if(seg->rtime >= pcb->net.rto) {
	DEBUGF(TCP_PROXY_DEBUG, ("rexmit wl.buffer\n"));

	tcp_rexmit_seg(&(pcb->wl), seg);
	/* Double retransmission time-out. */
	pcb->net.rto <<= 1;
      }
    }
    for(seg = pcb->net.buffer; seg != NULL; seg = seg->next) {
      seg->rtime++;
      if(seg->rtime >= pcb->wl.rto) {
	DEBUGF(TCP_PROXY_DEBUG, ("rexmit net.buffer\n"));

	tcp_rexmit_seg(&(pcb->net), seg);
	/* Double retransmission time-out. */
	pcb->wl.rto <<= 1;

      }
    }

    pcb_remove = 0;

    /* Check if this PCB has stayed long enough in TIME-WAIT */
    if(pcb->timer_tw) {
      pcb->timer_tw++;
      if((pcb->timer_tw - 1) > 2 * TCP_MSL / TCP_COARSE_TIMEOUT) {
        pcb_remove++;
      }
    }    

    if(pcb->timer_inactive < 65535) {
      pcb->timer_inactive++;
    }

    /* If the PCB should be removed, do it. */
    if(pcb_remove) {
      tcp_pcb_purge(pcb);
      
      /* Remove PCB from tcp_pcbs list. */
      if(prev != NULL) {
        prev->next = pcb->next;
      } else {
        /* This PCB was the first. */
        tcp_pcbs = pcb->next;
      }
      pcb_remove = 1;
      pcb2 = pcb->next;
      mem_free(pcb);
      pcb = pcb2;
    } else {
      prev = pcb;
      pcb = pcb->next;
    }
  }
    
  sys_timeout(TCP_COARSE_TIMEOUT, tcp_timer_coarse, NULL);
}
/*-----------------------------------------------------------------------------------*/
static void
tcp_timer_fine(void *data)
{
  struct tcp_pcb *pcb;
  struct pbuf *p;
  
  /*  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {
    if(pcb->wl.flags & TCP_ACK_NEXT) {
      pcb->wl.flags &= ~TCP_ACK_NEXT;
      p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
      DEBUGF(TCP_PROXY_DEBUG, ("tcp_ack_wl: delayed ACK ackno %lu\n", pcb->wl.snd));
      tcp_output_packet(p, &(pcb->net.ip), &(pcb->wl.ip),
                        pcb->net.port, pcb->wl.port,
                        TCP_ACK, pcb->net.snd, pcb->wl.snd,
                        pcb->net.wnd, 0);      
    }
    }*/
  

  sys_timeout(TCP_FINE_TIMEOUT, tcp_timer_fine, NULL);
}
/*-----------------------------------------------------------------------------------*/
void
tcp_init(void)
{
  /* initialize timers */
  sys_timeout(TCP_FINE_TIMEOUT, tcp_timer_fine, NULL);
  sys_timeout(TCP_COARSE_TIMEOUT, tcp_timer_coarse, NULL);
  
}
/*-----------------------------------------------------------------------------------*/
void
tcp_rexmit_seg(struct tcp_pcb_host *pcb, struct tcp_seg *seg)
{
  unsigned long wnd;
  struct netif *netif;
  
  wnd = MIN(pcb->wnd, pcb->cwnd);

  DEBUGF(TCP_PROXY_DEBUG, ("tcp_rexmit: seqno %lu:%lu to 0x%lx\n",
			   seg->seqno, seg->seqno + seg->len,
			   seg->iphdr->dest.addr));
  
  /*  if(seg->seqno - pcb->rcv + seg->len <= wnd) { */
  {    /*    tcp_output_segment(seg, pcb); */
    seg->p->payload = seg->tcphdr;
    seg->p->len = seg->plen;
    seg->p->tot_len = seg->ptot_len;
    
    if((netif = ip_route(&(seg->iphdr->dest))) == NULL) {
      
      DEBUGF(TCP_PROXY_DEBUG, ("tcp_rexmit_segment: No route\n"));

      return;
    }

    ip_output_if(seg->p, NULL, IP_HDRINCL,
                 seg->iphdr->ttl, seg->iphdr->proto, netif);
               
    /* Don't take any rtt measurements after retransmitting. */
    pcb->rttest = 0;
  }
  seg->rtime = 0;
}
/*-----------------------------------------------------------------------------------*/
void
tcp_output_packet(struct pbuf *p, struct ip_addr *src_ip, struct ip_addr *dest_ip,
		  unsigned short local_port, unsigned short dest_port,
		  unsigned char flags,
		  unsigned long seqno, unsigned long ackno,
		  unsigned long rcv_wnd, unsigned short snd_up)
{
  struct tcp_hdr *tcphdr;
  void *payload;
  int len;

  payload = p->payload;
  len = p->len;
  if(pbuf_header(p, TCP_HLEN)) {
    DEBUGF(TCP_PROXY_DEBUG, ("tcp_send_data: no room for TCP header in pbuf.\n"));
    return;
  }  
  tcphdr = p->payload;
  /*  p->dest.addr = dest_ip->addr;
      p->src.addr = src_ip->addr;*/
  tcphdr->src = htons(local_port);
  tcphdr->dest = htons(dest_port);
  tcphdr->seqno = htonl(seqno);
  tcphdr->ackno = htonl(ackno);
  tcphdr->flags = flags;
  tcphdr->wnd = htons(rcv_wnd);
  tcphdr->urgp = htons(snd_up);
  tcphdr->offset = 5;


  tcphdr->chksum = 0;
  tcphdr->chksum = inet_chksum_pseudo(p, 
				      src_ip, dest_ip,
				      IP_PROTO_TCP, p->len);

#ifdef TCP_STATS
  stats.tcp.xmit++;
#endif /* TCP_STATS */
 
  ip_output(p, src_ip, dest_ip, TCP_TTL, IP_PROTO_TCP);

  /* reset messed up pointers in pbuf */
  p->payload = payload;
  p->len = len;
  /*  DEBUGF("tcp_output_packet: '%.*s'\n", (int)p->len, (char *)p->payload);*/
  
}
/*-----------------------------------------------------------------------------------*/
void
tcp_rst(unsigned long seqno, unsigned long ackno, struct ip_addr *src_ip,
        struct ip_addr *dest_ip, unsigned short src_port, unsigned short dest_port)
{
  struct pbuf *p;

  p = pbuf_alloc(PBUF_TRANSPORT, 0, PBUF_RAM);
  
  tcp_output_packet(p, src_ip, dest_ip, src_port, dest_port,
		    TCP_RST | TCP_ACK, seqno, ackno,
		    0, 0);
  pbuf_free(p);
}
/*-----------------------------------------------------------------------------------*/
void
tcp_pcb_remove(struct tcp_pcb *pcb)
{
  struct tcp_pcb *pcb2;

#if TCP_PROXY_DEBUG
    ASSERT("tcp_pcb_remove: pcb deadbeef",
	   pcb->deadbeef[0] == 'p' &&
	   pcb->deadbeef[1] == 'c' &&
	   pcb->deadbeef[2] == 'b');
#endif /* TCP_PROXY_DEBUG */

  if(tcp_pcbs == pcb) {
    tcp_pcbs = tcp_pcbs->next;
  } else for(pcb2 = tcp_pcbs; pcb2 != NULL; pcb2 = pcb2->next) {
    if(pcb2->next != NULL && pcb2->next == pcb) {
      pcb2->next = pcb->next;
    }
  }
  tcp_segs_free(pcb->net.buffer);
  tcp_segs_free(pcb->wl.buffer);  
  pcb->net.buffer = pcb->wl.buffer =
    NULL;
  mem_free(pcb);
}
/*-----------------------------------------------------------------------------------*/
#ifdef TCP_PROXY_DEBUG
void
tcp_debug_print_pcbs()
{
  struct tcp_pcb *pcb;
  
  DEBUGF(TCP_PROXY_DEBUG, ("PCB states:\n"));
  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {
    tcp_debug_print_pcb(pcb);
  }    
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_pcbs_state()
{
  struct tcp_pcb *pcb;
  
  DEBUGF(TCP_PROXY_DEBUG, ("PCB states:\n"));
  for(pcb = tcp_pcbs; pcb != NULL; pcb = pcb->next) {
    DEBUGF(TCP_PROXY_DEBUG, ("PCB wl %d net %d ", pcb->wl.port, pcb->net.port));
    tcp_debug_print_state(pcb->state);
  }    
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_pcb(struct tcp_pcb *pcb)
{
  struct tcp_seg *seg;
  int i;

  if(pcb == NULL) {
    return;
  }
  
  DEBUGF(TCP_PROXY_DEBUG, ("wl port %d, net port %d\n", pcb->wl.port, pcb->net.port));
  tcp_debug_print_state(pcb->state);
  DEBUGF(TCP_PROXY_DEBUG, ("net.snd %lu net.rcv %lu wl.snd %lu wl.rcv %lu\n",
			   pcb->net.snd, pcb->net.rcv, pcb->wl.snd, pcb->wl.rcv));
  i = 0;
  for(seg = pcb->net.buffer; seg != NULL; seg = seg->next) {
    i++;
  }
  DEBUGF(TCP_PROXY_DEBUG, ("pcb->net.buffer %d ", i));
  i = 0;
  for(seg = pcb->wl.buffer; seg != NULL; seg = seg->next) {
    i++;
  }
  DEBUGF(TCP_PROXY_DEBUG, ("pcb->wl.buffer %d ", i));
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print(struct tcp_hdr *tcphdr)
{
  DEBUGF(TCP_PROXY_DEBUG, ("TCP header:\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("|     %5d     |     %5d     | (src port, dest port)\n",
			   ntohs(tcphdr->src), ntohs(tcphdr->dest)));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("|           0x%08lx          | (seq no)\n",
			   ntohl(tcphdr->seqno)));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("|           0x%08lx          | (ack no)\n",
			   ntohl(tcphdr->ackno)));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("| %2d |    |%d%d%d%d%d|    %5d      | (offset, flags (",
			   tcphdr->offset,
			   tcphdr->flags >> 4 & 1,
			   tcphdr->flags >> 3 & 1,
			   tcphdr->flags >> 2 & 1,
			   tcphdr->flags >> 1 & 1,
			   tcphdr->flags & 1,
			   ntohs(tcphdr->wnd)));
  tcp_debug_print_flags(tcphdr->flags);
  DEBUGF(TCP_PROXY_DEBUG, ("), win)\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(TCP_PROXY_DEBUG, ("|    0x%04x     |     %5d     | (chksum, urgp)\n",
			   ntohs(tcphdr->chksum), ntohs(tcphdr->urgp)));
  DEBUGF(TCP_PROXY_DEBUG, ("+-------------------------------+\n"));
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_state(enum tcp_state s)
{
  ASSERT("tcp_debug_print_state: sane state", s >= CLOSED && s <= TIME_WAIT);
  DEBUGF(TCP_PROXY_DEBUG, ("State: %s\n", tcp_states[s]));
}
/*-----------------------------------------------------------------------------------*/
void
tcp_debug_print_flags(char flags)
{
  if(flags & TCP_FIN) {
    DEBUGF(TCP_PROXY_DEBUG, ("FIN "));
  }
  if(flags & TCP_SYN) {
    DEBUGF(TCP_PROXY_DEBUG, ("SYN "));
  }
  if(flags & TCP_RST) {
    DEBUGF(TCP_PROXY_DEBUG, ("RST "));
  }
  if(flags & TCP_PSH) {
    DEBUGF(TCP_PROXY_DEBUG, ("PSH "));
  }
  if(flags & TCP_ACK) {
    DEBUGF(TCP_PROXY_DEBUG, ("ACK "));
  }
  if(flags & TCP_URG) {
    DEBUGF(TCP_PROXY_DEBUG, ("URG "));
  }
}
#endif /* TCP_PROXY_DEBUG */
/*-----------------------------------------------------------------------------------*/










