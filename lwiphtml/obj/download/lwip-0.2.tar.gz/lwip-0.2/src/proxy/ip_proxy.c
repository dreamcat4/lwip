/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: ip_proxy.c,v 1.5 2001/01/31 09:12:20 adam Exp $
 */


#include "debug.h"

#include "mem.h"
#include "icmp.h"
#include "ip_proxy.h"
#include "inet.h"
#include "tcp_proxy.h"


#include "netif.h"

#include "stats.h"


#define IP_PROXY
#define TCP_PROXY 

/* Forward declarations */
static void ip_forward(struct pbuf *p, struct ip_hdr *iphdr);
struct netif *ip_route(struct ip_addr *dest);
static void ip_remove_options(struct pbuf *p);



/*-----------------------------------------------------------------------------------*/
void
ip_init()
{
}
/*-----------------------------------------------------------------------------------*/
void
ip_input(struct pbuf *p, struct netif *inp)
{
  struct netif *netif;
  struct ip_hdr *iphdr;
  unsigned short chksum;
  int fwflag;

#ifdef IP_STATS
  stats.ip.recv++;
#endif /* IP_STATS */

  /*  DEBUGF("ip_input: got packet len %d tot %d\n", p->len, p->tot_len);*/
  
  /* identify the IP header */
  iphdr = p->payload;
  if(iphdr->v != 4) {
#if IP_PROXY_DEBUG
    DEBUGF(IP_PROXY_DEBUG, ("IP packet dropped due to bad version number\n"));
    ip_debug_print(p);
#endif /* IP_PROXY_DEBUG */
    pbuf_free(p);
    return;
  }
  
  if(iphdr->hl*4 > p->len) {
    DEBUGF(IP_PROXY_DEBUG, ("IP packet dropped due to too short packet %d\n", p->len));
    pbuf_free(p);
    return;
  }
  

  /* verify checksum */
  if((chksum = inet_chksum(iphdr, iphdr->hl * 4)) != 0) {
#if IP_PROXY_DEBUG
    DEBUGF(IP_PROXY_DEBUG, ("IP packet dropped due to failing checksum 0x%x\n", chksum));
    ip_debug_print(p);
#endif /* IP_PROXY_DEBUG */
    pbuf_free(p);
    return;
  }

#ifdef IP_PROXY
  /* Remove IP options. */
  ip_remove_options(p);
#endif /* IP_PROXY */
  
  iphdr = p->payload;

  /* is this packet for us? */
  for(netif = netif_list; netif != NULL; netif = netif->next) {    
    if(ip_addr_cmp(&(iphdr->dest), &(netif->ip_addr))) {
      break;
    }
  }

  pbuf_header(p, -(iphdr->hl * 4));
  
  if(netif != NULL) {
    /* send to upper layers */
    if(iphdr->proto == IP_PROTO_ICMP) {
      icmp_input(p, inp);
    }
  } else {
    /* forward packet */
    switch(iphdr->proto) {
#ifdef TCP_PROXY
    case IP_PROTO_TCP:
      tcp_input(p, inp);
      break;
#endif /* TCP_PROXY */
    default:
      pbuf_header(p, iphdr->hl * 4);
      ip_forward(p, iphdr);
      break;
    }
  }
  pbuf_free(p);
}

/*-----------------------------------------------------------------------------------*/
static void
ip_forward(struct pbuf *p, struct ip_hdr *iphdr)
{
  struct netif *netif;
  
  if((netif = ip_route((struct ip_addr *)&(iphdr->dest))) == NULL) {
    icmp_dest_unreach(p, ICMP_DUR_HOST);
    DEBUGF(IP_PROXY_DEBUG, ("ip_input: no forwarding route for 0x%lx found\n", iphdr->dest.addr));

    pbuf_free(p);
    return;
  }
  /* Decrement TTL and send ICMP if ttl == 0. */
  if(--iphdr->ttl == 0) {
    icmp_time_exceeded(p, ICMP_TE_TTL);
    return;       
  }

  /* Incremental update of the IP checksum. */
  if (iphdr->chksum >= htons(0xffff - 0x100)) {
    iphdr->chksum += htons(0x100) + 1;
  } else {
    iphdr->chksum += htons(0x100);
  }

  netif->output(netif, p, (struct ip_addr *)&(iphdr->dest));
}
/*-----------------------------------------------------------------------------------*/
struct netif *
ip_route(struct ip_addr *dest)
{
  struct netif *netif;

  for(netif = netif_list; netif != NULL; netif = netif->next) {
    if((dest->addr & netif->netmask.addr) == (netif->ip_addr.addr & netif->netmask.addr)) {
      return netif;
    }
  }  
  return NULL;
}

/*-----------------------------------------------------------------------------------*/
static void
ip_remove_options(struct pbuf *p)
{
  int i, offlen;
  struct ip_hdr *iphdr, *newhdr;
  char *pl;
    
  iphdr = p->payload;
  pl = (char *)iphdr + iphdr->hl * 4;
  
	 
  offlen = iphdr->hl * 4 - IP_HLEN;

  if(offlen != 0) {
      
    newhdr = (struct ip_hdr *)((char *)iphdr + offlen);

    for(i = IP_HLEN - 1; i >= 0; i--) {
      ((char *)newhdr)[i] = ((char *)iphdr)[i];
    }
    newhdr->hl = IP_HLEN / 4;
    newhdr->len = htons(ntohs(newhdr->len) - offlen);
    newhdr->chksum = 0;
    newhdr->chksum = inet_chksum(newhdr, IP_HLEN);

    pl = (char *)newhdr + newhdr->hl * 4;

    p->payload = newhdr;
    
    DEBUGF(IP_PROXY_DEBUG, ("ip_remove_options: offlen %d\n", offlen));
  }
}
/*-----------------------------------------------------------------------------------*/
void
ip_output_if(struct pbuf *p, struct ip_addr *src, struct ip_addr *dest,
	     unsigned char ttl, unsigned char proto,
	     struct netif *netif)
{
  struct ip_hdr *iphdr;
  static unsigned short ip_id = 0;

  if(pbuf_header(p, IP_HLEN)) {
    DEBUGF(IP_PROXY_DEBUG, ("ip_output: not enough room for IP header in pbuf\n"));

    return;
  }
  
  iphdr = p->payload;


  if(dest != IP_HDRINCL) {
    iphdr->ttl = ttl;
    iphdr->proto = proto;

    iphdr->dest.addr = dest->addr;
    
    iphdr->hl = IP_HLEN/4;
    iphdr->v = 4;
    iphdr->tos = 0;
    iphdr->len = htons(p->len);
    iphdr->offset = htons(0);
    iphdr->id = htons(ip_id++);
    
    
    if(src == IP_ADDR_ANY || src->addr == IP_ADDR_ANY) {
      iphdr->src.addr = netif->ip_addr.addr;
    } else {
      iphdr->src.addr = src->addr;
    }
  
    iphdr->chksum = 0;
    iphdr->chksum = inet_chksum(iphdr, IP_HLEN);
  } else {
    dest = &(iphdr->dest);
  }
#ifdef IP_STATS
  stats.tcp.xmit++;
#endif /* IP_STATS */

  /*  ip_debug_print(p);*/

  DEBUGF(IP_PROXY_DEBUG, ("Sending on interface %c%c%d\n", netif->name[0], netif->name[1], netif->num));

  netif->output(netif, p, (struct ip_addr *)&(iphdr->dest));  
}
/*-----------------------------------------------------------------------------------*/
void
ip_output(struct pbuf *p, struct ip_addr *src, struct ip_addr *dest,
	  unsigned char ttl, unsigned char proto)
{
  struct netif *netif;
  if((netif = ip_route(dest)) == NULL) {
    DEBUGF(IP_PROXY_DEBUG, ("ip_output: No route to 0x%lx\n", dest->addr));
    return;
  }

  ip_output_if(p, src, dest, ttl, proto, netif);
}
/*-----------------------------------------------------------------------------------*/
#if IP_PROXY_DEBUG
void
ip_debug_print(struct pbuf *p)
{
  struct ip_hdr *iphdr = p->payload;

  DEBUGF(IP_PROXY_DEBUG, ("IP header:\n"));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(IP_PROXY_DEBUG, ("|%2d |%2d |   %2d  |      %4d     | (v, hl, tos, len)\n",
                          iphdr->v,
                          iphdr->hl,
                          iphdr->tos,
                          ntohs(iphdr->len)));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(IP_PROXY_DEBUG, ("|    %5d      |%d%d%d|    %4d   | (id, flags, offset)\n",
                          ntohs(iphdr->id),
                          ntohs(iphdr->offset) >> 15 & 1,
                          ntohs(iphdr->offset) >> 14 & 1,
                          ntohs(iphdr->offset) >> 13 & 1,
                          ntohs(iphdr->offset) & IP_OFFMASK));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(IP_PROXY_DEBUG, ("|   %2d  |   %2d  |    0x%04x     | (ttl, proto, chksum)\n",
                          iphdr->ttl,
                          iphdr->proto,
                          ntohs(iphdr->chksum)));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(IP_PROXY_DEBUG, ("|  %3ld  |  %3ld  |  %3ld  |  %3ld  | (src)\n",
                          ntohl(iphdr->src.addr) >> 24 & 0xff,
                          ntohl(iphdr->src.addr) >> 16 & 0xff,
                          ntohl(iphdr->src.addr) >> 8 & 0xff,
                          ntohl(iphdr->src.addr) & 0xff));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  DEBUGF(IP_PROXY_DEBUG, ("|  %3ld  |  %3ld  |  %3ld  |  %3ld  | (dest)\n",
                          ntohl(iphdr->dest.addr) >> 24 & 0xff,
                          ntohl(iphdr->dest.addr) >> 16 & 0xff,
                          ntohl(iphdr->dest.addr) >> 8 & 0xff,
                          ntohl(iphdr->dest.addr) & 0xff));
  DEBUGF(IP_PROXY_DEBUG, ("+-------------------------------+\n"));
  
}
#endif /* IP_PROXY_DEBUG */
/*-----------------------------------------------------------------------------------*/
