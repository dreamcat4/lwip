/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: tcp_proxy.h,v 1.6 2001/01/31 09:12:22 adam Exp $
 */
#ifndef __TCP_PROXY_H__
#define __TCP_PROXY_H__

#include "debug.h"
#include "pbuf.h"
#include "ip_proxy.h"

#define TCP_ACK_NEXT_WL  0x01
#define TCP_ACK_NEXT_NET 0x02

#define TCP_SEQ_LT(a,b)     ((int)((a)-(b)) < 0)
#define TCP_SEQ_LEQ(a,b)    ((int)((a)-(b)) <= 0)
#define TCP_SEQ_GT(a,b)     ((int)((a)-(b)) > 0)
#define TCP_SEQ_GEQ(a,b)    ((int)((a)-(b)) >= 0)


#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

#define TCP_HLEN 20

#define TCP_MSS 200

#define TCP_FINE_TIMEOUT 200   /* the fine grained timeout in microseconds */
#define TCP_COARSE_TIMEOUT 500   /* the coarse grained timeout in microseconds */

#define TCP_MSL 30000  /* The maximum segment lifetime in microseconds */

struct tcp_hdr {
  unsigned short src, dest;
  unsigned long seqno, ackno;
#if BYTE_ORDER == LITTLE_ENDIAN
  unsigned char unused:4,
    offset:4;
#else
  unsigned char offset:4,
    unused:4.
#endif
  unsigned char flags;
  unsigned short wnd;
  unsigned short chksum;
  unsigned short urgp;
  char options[0];
};

enum tcp_state {
  CLOSED,      /* No connection exists. */
  SYN_RCVD_1,  /* Net has sent SYN, but wl has not responded. */
  SYN_RCVD_2,  /* Wl responded with SYNACK to SYN. */
  SYN_RCVD_3,  /* Net has sent ACK for wl's SYNACK. */
  SYN_SENT_1,  /* Wl has sent SYN. */
  SYN_SENT_2,  /* Net has sent SYNACK to wl. */
  ESTABLISHED, /* Wl in ESTABLISHED state. */
  FIN_WAIT_1,  /* Wl has sent FIN. */
  FIN_WAIT_2,  /* Net has ACKed wl's FIN. */
  FIN_WAIT_3,  /* Net has sent FIN after wl has sent FIN. */
  CLOSE_WAIT,  /* Net has sent FIN but not wl. */
  CLOSING_1,   /* Net has sent FIN after wl has sent FIN. */
  CLOSING_2,   /* Wl is in CLOSING. */
  TIME_WAIT    /* Wl is in TIME-WAIT. */
};

struct tcp_pcb_host {
  struct ip_addr ip;
  unsigned short port;

  unsigned long mss;   /* maximum segment size */
  
  /* congestion avoidance/control variables */
  unsigned long cwnd;  
  unsigned long ssthresh;

  unsigned long lastack;
  unsigned char dupacks;

  unsigned char flags;
#define TCP_ACK_NEXT 0x01   /* Delayed ACK */
#define TCP_INFR     0x02   /* In fast recovery */
 
  
  unsigned long snd;    /* next seqno expected from host */
  unsigned long rcv;    /* highest seqno acknowledged by host */
  unsigned long wnd;    /* host advertised window */
  unsigned long iss;
  char received;        /* Non-zero indicates that a segment has
			   been received from the host. */

  /* RTT estimation variables. */
  unsigned char rttest; /* RTT estimate in 500ms ticks */
  unsigned long rtseq;  /* sequence number being timed */
  int sa, sv, rto;

  /* These are ordered by sequence number. */
  struct tcp_seg *ooseq;      /* Out of sequence segments.
				 This is only used for data coming from
				 the Internet host. */
  struct tcp_seg *buffer;     /* Buffered segments that has not been
				 acknowledged by the other host. */
};


/* the TCP protocol control block */
struct tcp_pcb {
  struct tcp_pcb *next;

#if TCP_PROXY_DEBUG
  char deadbeef[3];
#endif /* TCP_PROXY_DEBUG */
  
  enum tcp_state state;
  /* Timers. */
  unsigned int timer_tw, timer_inactive;

  struct tcp_pcb_host wl;
  struct tcp_pcb_host net;
};



struct tcp_seg {
  struct tcp_seg *next;    /* used when putting segements on a list */

  unsigned long seqno, ackno;
  unsigned char flags;
  unsigned short wnd, urgp;
  unsigned int len;

  struct ip_hdr *iphdr;
  struct tcp_hdr *tcphdr;
  unsigned short plen;
  unsigned short ptot_len;
  struct pbuf *p;   /* buffer containing data + TCP header */

  
  unsigned long rtime;  /* last retransmission time */
  unsigned long rleft;  /* time left until retransmission */
};

void tcp_init(void);

void tcp_input(struct pbuf *p, struct netif *inp);

void tcp_input_from_wl(struct pbuf *p);
void tcp_input_from_net(struct pbuf *p);


void tcp_receive_ack(struct tcp_seg *seg, struct tcp_pcb_host *pcb,
                     struct tcp_pcb_host *otherpcb, int rtt);
int tcp_receive_seg(struct tcp_seg *seg, struct tcp_pcb_host *pcb,
                int buffer, int ooseq);

void tcp_time_wait_kill(struct tcp_pcb *pcb);

struct tcp_pcb *tcp_pcb_new(void);
void tcp_pcb_remove(struct tcp_pcb *pcb);
void tcp_pcb_purge(struct tcp_pcb *pcb);

void tcp_rexmit_seg(struct tcp_pcb_host *pcb, struct tcp_seg *seg);

void tcp_output_packet(struct pbuf *p, struct ip_addr *src_ip,
                       struct ip_addr *dest_ip,
                       unsigned short local_port, 
                       unsigned short dest_port,
                       unsigned char flags,
                       unsigned long seqno, unsigned long ackno,
                       unsigned long rcv_wnd, unsigned short snd_up);

void tcp_segs_free(struct tcp_seg *seg);
void tcp_seg_free(struct tcp_seg *seg);

void tcp_rst(unsigned long seqno, unsigned long ackno,
             struct ip_addr *src_ip, struct ip_addr *dest_ip,
             unsigned short local_port, unsigned short dest_port);

extern struct tcp_pcb *tcp_pcbs;
extern unsigned long tcp_ticks;

#ifdef TCP_PROXY_DEBUG
extern char *tcp_states[];
void tcp_debug_print(struct tcp_hdr *tcphdr);
void tcp_debug_print_flags(char flags);
void tcp_debug_print_state(enum tcp_state s);
void tcp_debug_print_pcbs(void);
void tcp_debug_print_pcbs_state(void);
void tcp_debug_print_pcb(struct tcp_pcb *pcb);
#endif /* TCP_PROXY_DEBUG */


#endif /* __TCP_PROXY_H__ */



