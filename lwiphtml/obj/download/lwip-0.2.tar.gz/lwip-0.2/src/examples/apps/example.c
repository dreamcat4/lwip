/*
 * Copyright (c) 2001, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 *
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 * $Id: example.c,v 1.5 2001/01/31 09:12:05 adam Exp $
 */


#include "opt.h"
#include "debug.h"
#include "mem.h"
#include "fs.h"

#include "ip.h"
/* A simple HTTP/1.0 server using the minimal API. */

#include "api.h"

/* This is the data for the actual web page.
   Most compilers would place this in ROM. */
static char indexdata[] =
"HTTP/1.0 200 OK\r\n\
Content-type: text/html\r\n\
\r\n\
<html> \
<head><title>A test page</title></head> \
<body> \
This is a small test page. \
</body> \
</html>";

/* This function processes an incomming connection. */
static void
process_connection(struct netconn *conn)
{
  struct netbuf *inbuf;
  char *rq;
  int len;

  /* Read data from the connection into the netbuf.
     We assume that the full request is in the netbuf. */
  inbuf = netconn_recv(conn);
  
  /* Get the pointer to the data in the netbuf
     which contains the request. */
  netbuf_data(inbuf, (void *)&rq, &len);
  
  /* Check if the request atleast was an HTTP "GET /". */
  if(rq[0] == 'G' && rq[1] == 'E' &&
     rq[2] == 'T' && rq[3] == ' ' &&
     rq[4] == '/') {
    
    /* Send the web page. */
    netconn_write(conn, indexdata, sizeof(indexdata), NETCONN_NOCOPY);
    
  }

  /* Close the connection. */
  netconn_close(conn);
    
  /* Free the memory previously allocated to the
     header netbuf. */
  netbuf_free(inbuf);
  
  /* Deallocate the netbuf. */
  netbuf_delete(inbuf);
  
}


/* The main() function. */
void *
example_thread(void *arg)
{
  struct netconn *conn, *newconn, *newconn2;
  struct ip_addr ipaddr;
  struct netbuf *buf;
  char data[1000];
  char rq[] = "GET /index.html\r\n";

  newconn = netconn_new(NETCONN_TCP);
  netconn_bind(newconn, NULL, 8080);
  netconn_listen(newconn);
  /*  while(1) {
      newconn2 = netconn_accept(newconn);*/
    /*    aaa = mem_malloc(700);
    for(i = 0; i < 700; i++) {
      aaa[i] = 'a';
    }
    netconn_write(newconn2, aaa, 700, NETCONN_COPY);
    for(i = 0; i < 100; i++) {
      netconn_write(newconn2, aaa, 10, NETCONN_COPY);
    }
    mem_free(aaa);*/
  /*    netconn_close(newconn2);
	netconn_delete(newconn2);*/
    
    /*  }
	return NULL;*/

  while(newconn2 = netconn_accept(newconn)) {
#ifdef IPv4    
    conn = netconn_new(NETCONN_TCP);
    ipaddr.addr = htonl(0x0a000101);
    netconn_connect(conn, &ipaddr, 80);
    netconn_write(conn, rq, sizeof(rq), NETCONN_NOCOPY);
    while((buf = netconn_recv(conn)) != NULL) {
      netbuf_copy(buf, data, 1000);
      data[netbuf_len(buf)] = 0;
#ifdef DEBUG
      DEBUGF(1, ("%s", data));
#endif /* DEBUG */
      netbuf_free(buf);
      netbuf_delete(buf);
    }
    netconn_close(conn);
    netconn_delete(conn);
#endif /* IPv4 */
    netconn_delete(newconn2);
  }
  return NULL;
  
  /* Create a new TCP connection handle. */
  conn = netconn_new(NETCONN_TCP);

  /* Bind the connection to port 80 on any
     local IP address. */
  netconn_bind(conn, NULL, 8080);

  /* Put the connection into LISTEN state. */
  netconn_listen(conn);

  /*  DEBUGF("example: after listen\n");*/
  /* Loop forever. */
  while(1) {
    /* Accept a new connection. */
    newconn = netconn_accept(conn);
    /*    DEBUGF("example: after accept\n");*/
    
    /* Process the incomming connection. */
    process_connection(newconn);

    /* Deallocate connection handle. */
    netconn_delete(newconn);
  }
}


